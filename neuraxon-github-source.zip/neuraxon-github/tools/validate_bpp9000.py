#!/usr/bin/env python3
"""Structural and random-baseline check for the bundled autonomous BPP-9000 genome."""
import json
import random
from collections import Counter
from pathlib import Path

BRAIN = Path(__file__).resolve().parents[1] / "app/src/main/assets/brains/bpp9000-e240.json"
TICKS = 20_000


def run_sequence(brain, ticks):
    nodes = brain["nodes"]
    state = [n["initialState"] for n in nodes]
    calls = []
    for _ in range(ticks):
        nxt = [n["lut"][state[n["sources"][0]] + 3 * state[n["sources"][1]] + 9 * state[n["sources"][2]]]
               for n in nodes]
        state = nxt
        if state[brain["control"]] != 2:
            calls.append(None if state[brain["output"]] == 2 else (1 if state[brain["output"]] == 1 else -1))
    return calls


def main():
    brain = json.loads(BRAIN.read_text(encoding="utf-8"))
    assert brain["format"] == "qc-bpp9000-brain-v1"
    assert len(brain["nodes"]) == 1024
    for i, node in enumerate(brain["nodes"]):
        assert node["id"] == i and len(node["sources"]) == 3 and len(node["lut"]) == 27
        assert all(0 <= x < 1024 for x in node["sources"])
        assert node["initialState"] in (0, 1, 2) and all(x in (0, 1, 2) for x in node["lut"])

    calls = run_sequence(brain, TICKS)
    known = [x for x in calls if x is not None]
    counts = Counter(known)
    rng = random.Random(20261123)
    random_labels = [1 if rng.random() >= 0.5 else -1 for _ in known]
    random_accuracy = 100.0 * sum(a == b for a, b in zip(known, random_labels)) / max(1, len(known))
    up_accuracy = 100.0 * sum(x == 1 for x in known) / max(1, len(known))
    down_accuracy = 100.0 * sum(x == -1 for x in known) / max(1, len(known))

    print(f"Genome: {brain['hash']}")
    print(f"Neurons: {len(brain['nodes'])}; control={brain['control']}; output={brain['output']}")
    print(f"Clocked calls: {len(calls)}; known calls: {len(known)}; trit counts: {dict(counts)}")
    print(f"Seeded random-market baseline: {random_accuracy:.2f}% (expected near 50%)")
    print(f"All-up planted direction: {up_accuracy:.2f}% | all-down: {down_accuracy:.2f}%")
    print("NOTE: BPP-9000 is autonomous and has no candle input; planted-pattern recognition belongs to the separate analytical strategy engine.")
    if not 47.0 <= random_accuracy <= 53.0:
        raise SystemExit("Random baseline outside the expected 47–53% sanity band")


if __name__ == "__main__":
    main()
