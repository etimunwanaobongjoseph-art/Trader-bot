# Neuraxon Android — GitHub APK Build

This is a GitHub-ready Android Studio/Gradle source project reconstructed from the supplied `neuraxon-debug-apk (1).zip` and upgraded around the supplied BPP-9000 E240 brain JSON.

## What is included

- Native Android Java app (`com.neuraxon.app`), min SDK 23, JDK 17, Android Gradle Plugin 8.6.1.
- Bundled BPP-9000 E240 brain JSON (1,024 neurons; control neuron 368; output neuron 443).
- BPP-9000 ternary LUT runtime: each tick reads the previous state and applies `lut[s0 + 3*s1 + 9*s2]`.
- Legacy Reservoir brain fallback, ported from the `neuraxon-mini-bot.ts` asset packaged inside the supplied APK. The exact original Java source was not included in the APK, so this is a source-based port of the packaged reference engine, not a byte-for-byte decompilation of the old compiled `NeuraxonEngine`.
- Selectable strategies: Brain Only, Trend + Brain, Breakout, Mean Reversion.
- Independent market analysis and a hard disagreement block.
- Two-consecutive-closed-candle brain confirmation.
- Common risk controls: max trades/day, daily loss halt, optional daily profit stop, ATR stop-loss, optional trailing stop, quiet-market filter and loss cooldown.
- Binance public 1-hour closed-candle history for BTCUSDT, ETHUSDT, BNBUSDT, SOLUSDT and XRPUSDT.
- Backtest fee model (default 0.10% per side) and chronological 70/30 training/test split. The test segment is run with training candles used only for indicator/brain warm-up.
- GitHub Actions workflow to run unit tests, build the APK and publish it as an Actions artifact.

## Important BPP-9000 interpretation

The BPP-9000 genome is an autonomous recurrent network. It has no market-input neurons: it emits a time-ordered sequence from its fixed initial state. The uploaded file's `65.19%` is the score recorded in the file for its historical task; it is not evidence of profitable trading or out-of-sample trading accuracy.

The BPP-9000 Brain Watch documentation says the network's clock neuron controls when its output speaks and describes the historical score as homework, separate from unseen-hour exam performance. It also states that the live-call rule/prediction mode has not yet been published in the referenced documentation. Therefore this app treats the brain output as an experimental signal candidate, compares it with independent market analysis, and keeps live order execution disabled. Do not enable real-money trading on the strength of the 65.19% metadata score.

The task start timestamp is used to align the autonomous network with the candle timeline. Before relying on live predictions, verify the timestamp convention against the official Qubic `run_brain.py` scorer and compare the Java runtime's emitted sequence against that reference. A one-hour offset can change every comparison.

## Using the app

1. Leave **BPP-9000 E240** selected for BTCUSDT, or select **Legacy Reservoir** when testing ETHUSDT, BNBUSDT, SOLUSDT or XRPUSDT.
2. Download the latest fully closed 1-hour candles.
3. Run **Compare Strategies (Training Only)** to compare the four strategies on the first 70% of the downloaded history.
4. Choose a strategy using the training results only.
5. Run **Evaluate Selected on Unseen Holdout** once. The later 30% is used only for evaluation, with earlier candles used to warm up indicators and the brain.
6. Adjust risk limits under **Risk Settings**. Settings are saved on the device.

Do not repeatedly change strategy settings after viewing holdout results; doing so turns the holdout into training data.

## Build the APK in GitHub

1. Create a new GitHub repository.
2. Upload the contents of this folder to the repository root (the `.github` folder must be included).
3. Push to the `main` branch, or open **Actions → Build Neuraxon APK → Run workflow**.
4. Open the completed workflow run.
5. Under **Artifacts**, download `neuraxon-debug-apk`.
6. Extract the artifact ZIP; it contains `app-debug.apk`.

GitHub Actions uses JDK 17 and Gradle 8.7. No local Android SDK is needed to produce the APK.

## Project layout

```text
.
├── .github/workflows/android.yml
├── app/
│   ├── build.gradle
│   └── src/
│       ├── main/
│       │   ├── AndroidManifest.xml
│       │   ├── assets/brains/bpp9000-e240.json
│       │   └── java/com/neuraxon/app/
│       │       ├── MainActivity.java
│       │       ├── BinanceMarketData.java
│       │       └── core/
│       └── test/java/com/neuraxon/app/core/
├── legacy-engine-reference/neuraxon-mini-bot.ts
├── build.gradle
├── gradle.properties
└── settings.gradle
```

## Current implementation boundary

This reconstruction currently provides public market-data download, strategy selection, core decision logic, risk-checked historical simulation/backtesting and a native dashboard shell. It does not yet provide a continuously running paper account or exchange order placement. The old APK contained compiled Java classes for Binance trading, paper positions, OCO orders, and its previous UI, but did not contain the original Gradle project or Java source. Those components cannot be restored exactly from the two supplied files. For safety, real-money order placement is intentionally not enabled in this source reconstruction. The exchange execution layer must be rebuilt and separately tested before it is connected to live Binance credentials.

## Validation checklist before any live use

- [ ] Build succeeds on GitHub Actions.
- [ ] BPP-9000 Java output sequence matches the official reference script tick-for-tick, including start-time alignment.
- [ ] Random-market baseline is approximately 50% over a sufficiently large seeded sample; no artificial edge is claimed.
- [ ] Planted trend and breakout patterns are detected by the analytical strategy engine.
- [ ] No future candle data is used to make a decision for an earlier candle.
- [ ] Fees are applied on both entry and exit.
- [ ] Strategy settings are chosen on the training segment only; final report is on the unseen later segment.
- [ ] Paper trading is stable over an extended period before exchange execution is considered.

## Risk defaults

- Maximum trades/day: 3
- Daily loss halt: 3%
- Daily profit stop: disabled by default; set to 1% when enabled
- Risk per trade: 1% of equity
- Stop distance: 1.5 ATR
- Reward/risk: 2.0
- Trailing stop: disabled by default
- Cooldown after a loss: 3 candles
- Fee: 0.10% per side (adjust to the actual exchange fee tier)

## External technical references

- [Qubic BPP-9000 Brain Watch](https://qubic.church/bpp9000/brains) — explains the 1,024-neuron file, trit states, clock/output neurons, homework versus unseen-hour exam, and notes that the official live-call/prediction mode has not yet been published in that documentation.
- [Qubic Qiner repository](https://github.com/qubic/Qiner) — documents the autonomous recurrent ternary-LUT network and scoring model.
- [Qubic core releases](https://github.com/qubic/core/releases) — epoch and core release history.
