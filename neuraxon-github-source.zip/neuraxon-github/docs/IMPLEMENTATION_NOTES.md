# Implementation notes and known limitations

## Supplied APK inspection

The ZIP contained `app-debug.apk` only, not an Android Studio project. Its DEX strings identify native Java classes including `MainActivity`, `NeuraxonEngine`, `Backtester` and `BinanceTrader`. The APK also contains `assets/neuraxon-mini-bot.ts`, which describes the legacy reservoir architecture (1,024 total nodes partitioned as 164 input / 90 control / 770 output) with randomly initialized recurrent weights and a learned readout. This is not the uploaded BPP-9000 ternary-LUT genome.

The old APK's visible feature strings show Binance hourly candle processing, BTC/ETH/BNB/SOL/XRP markets, paper and live modes, exchange-side OCO stop/target orders, settings and historical backtesting. Since original Java source and build files were not supplied, this repository is a reconstruction, not an exact source restoration. The legacy TypeScript asset is retained in `legacy-engine-reference/` and the Java fallback is ported from it.

## BPP-9000 genome

- Format: `qc-bpp9000-brain-v1`
- Hash: `pjjwuehmmydgmbjcvenisyseyfragxcpvrcopcvkagjuooqlmelcpucfvvyn`
- Epoch: 240
- Neurons: 1,024
- Control neuron: 368
- Output neuron: 443
- LUT size: 27 entries per neuron
- Trits: 0 down, 1 up/flat, 2 not sure
- Control trit 2 suppresses the call

The engine is autonomous; there are no market input neurons. The market-analysis engine is separate and supplies the market-aware filter. The BPP output must not be described as learning new market features in real time.

## Backtest cautions

The simulator assumes stop-first when stop and target are both touched within one candle. This is conservative but cannot reconstruct the intrabar path. Funding, spread, slippage, exchange-specific lot sizes and market impact are not included yet. The fee rate is configurable and charged on both sides. Use more than a few hundred candles for any meaningful evaluation; one-hour BTC history is not proof that the same rules transfer to other symbols.

## Live execution

The source reconstruction does not run a continuous paper account or send live orders. The original compiled app had Binance API/order/OCO code, but without source code it cannot safely be merged or assumed compatible with the new strategy and risk gates. Keep API keys out of source control. A future live adapter must reconcile open orders and positions, validate lot/tick/notional filters, handle partial fills and unknown order status, and confirm exchange-side protective orders before any position is considered protected.

## Public BPP-9000 reference notes

The public Brain Watch documentation describes the network as autonomous, with a clock neuron and output neuron, and separates the historical homework score from unseen-hour exam performance. It also says the official live-call/prediction mode has not yet been published in the referenced material. Qiner's public README likewise describes an autonomous recurrent ternary network with no market-input neurons. Accordingly, the BPP-9000 model is restricted to BTCUSDT in this app and remains experimental/paper-only.

References:
- https://qubic.church/bpp9000/brains
- https://github.com/qubic/Qiner
- https://github.com/qubic/core


## Local genome sanity-check result

`python3 tools/validate_bpp9000.py` checks the 1,024-neuron structure and runs 20,000 autonomous ticks. On this deterministic run it produced 9,456 clocked known calls (4,494 up and 4,962 down). Against a seeded random direction sequence, accuracy was 50.29%; against an all-up sequence, 47.53%; against all-down, 52.47%. This is a sanity check showing no artificial random-market edge in the sequence. It is not a profitability test.

The Java strategy smoke checks confirmed that a first brain call is held until a second consecutive call, disagreement blocks a trade, and a planted high-volume breakout is recognized after brain confirmation. JUnit tests for these cases and future-leakage behavior are included for GitHub Actions.
