package com.neuraxon.app.core;

import org.junit.Test;
import static org.junit.Assert.*;
import java.util.ArrayList;
import java.util.List;

public class StrategyEngineTest {
    @Test public void brainMustConfirmSameCallOnTwoConsecutiveCandles(){
        Brain brain=new SequenceBrain(54,Signal.BUY);
        EngineConfig cfg=new EngineConfig();StrategyEngine engine=new StrategyEngine(brain,cfg);engine.setStrategy(Strategy.BRAIN_ONLY);
        Decision first=null,second=null;
        for(int i=0;i<56;i++){Decision d=engine.onClosedCandle(upCandle(i));if(i==54)first=d;if(i==55)second=d;}
        assertEquals(Signal.HOLD,first.signal);
        assertTrue(first.reason.contains("two closed candles"));
        assertEquals(Signal.BUY,second.signal);
    }


    @Test public void plantedUptrendIsAcceptedOnlyWhenBrainAgrees(){
        StrategyEngine engine=new StrategyEngine(new SequenceBrain(54,Signal.BUY),new EngineConfig());
        engine.setStrategy(Strategy.TREND_BRAIN);Decision first=null,last=null;
        for(int i=0;i<56;i++){Decision d=engine.onClosedCandle(upCandle(i));if(i==54)first=d;if(i==55)last=d;}
        assertEquals(Signal.HOLD,first.signal);
        assertEquals(Signal.BUY,last.signal);
        assertTrue(last.reason.contains("TREND_BRAIN"));
    }

    @Test public void strategyAndBrainDisagreementBlocksEntry(){
        Brain brain=new SequenceBrain(0,Signal.SELL);EngineConfig cfg=new EngineConfig();StrategyEngine engine=new StrategyEngine(brain,cfg);engine.setStrategy(Strategy.TREND_BRAIN);
        Decision last=null;for(int i=0;i<60;i++)last=engine.onClosedCandle(upCandle(i));
        assertEquals(Signal.HOLD,last.signal);assertTrue(last.reason.contains("disagree"));assertTrue(last.blocked);
    }

    @Test public void plantedBreakoutRequiresVolumeAndBrainConfirmation(){
        Brain brain=new SequenceBrain(54,Signal.BUY);EngineConfig cfg=new EngineConfig();cfg.breakoutLookback=20;StrategyEngine engine=new StrategyEngine(brain,cfg);engine.setStrategy(Strategy.BREAKOUT);
        Decision d=null;
        for(int i=0;i<55;i++){double p=100+(i%2==0?0.05:-0.05);d=engine.onClosedCandle(new Candle(i*3600000L,p,p+0.2,p-0.2,p,100));}
        d=engine.onClosedCandle(new Candle(55*3600000L,102,102.2,101.8,102,300));
        assertEquals(Signal.HOLD,d.signal); // first matching brain call only
        d=engine.onClosedCandle(new Candle(56*3600000L,102.5,102.7,102.3,102.5,320));
        assertEquals(Signal.BUY,d.signal);
    }

    @Test public void splitIsChronologicalAndNeverEmpty(){
        assertEquals(700,Backtester.chronologicalSplitIndex(1000,0.70));
        assertEquals(1,Backtester.chronologicalSplitIndex(2,0.70));
    }


    @Test public void futureCandlesCannotChangeEarlierDecision(){
        List<Candle> prefix=new ArrayList<>();for(int i=0;i<70;i++)prefix.add(upCandle(i));
        StrategyEngine a=new StrategyEngine(new SequenceBrain(0,Signal.BUY),new EngineConfig());
        StrategyEngine b=new StrategyEngine(new SequenceBrain(0,Signal.BUY),new EngineConfig());
        for(int i=0;i<prefix.size();i++){
            Decision da=a.onClosedCandle(prefix.get(i));
            Decision db=b.onClosedCandle(prefix.get(i));
            assertEquals("decision changed at index "+i,da.signal,db.signal);
            assertEquals(da.reason,db.reason);
        }
        // Only after the shared prefix do we reveal an extreme future move to engine B.
        for(int i=70;i<90;i++)b.onClosedCandle(new Candle(i*3600000L,500,510,490,505,10000));
        assertEquals(70,a.candles().size());
    }

    private static Candle upCandle(int i){double p=100+i*0.5;return new Candle(i*3600000L,p,p+0.8,p-0.8,p,100+i);}
    private static final class SequenceBrain implements Brain{
        final int firstSignalAt;final Signal signal;int n;
        SequenceBrain(int firstSignalAt,Signal signal){this.firstSignalAt=firstSignalAt;this.signal=signal;}
        public BrainDecision onClosedCandle(Candle c){Signal s=n++>=firstSignalAt?signal:Signal.HOLD;return new BrainDecision(s,1,s==Signal.BUY?1:s==Signal.SELL?0:2,name());}
        public String name(){return "test brain";}public void reset(){n=0;}
    }
}
