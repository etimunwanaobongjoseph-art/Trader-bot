package com.neuraxon.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import com.neuraxon.app.core.*;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Native dashboard. Live order execution remains deliberately disabled pending validation. */
public final class MainActivity extends Activity {
    private final Handler main=new Handler(Looper.getMainLooper());
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private TextView status,report,brainInfo;
    private Spinner brainPicker,strategyPicker,marketPicker;
    private EngineConfig config;
    private List<Candle> loadedCandles=new ArrayList<>();
    private String loadedSymbol="BTCUSDT";

    @Override public void onCreate(Bundle state){super.onCreate(state);getWindow().setStatusBarColor(Color.rgb(18,25,34));getWindow().setNavigationBarColor(Color.rgb(18,25,34));
        config=new EngineConfig();loadConfig();try(java.io.InputStream in=getAssets().open("brains/bpp9000-e240.json")){Bpp9000Brain.load(in);}catch(Exception e){throw new IllegalStateException("Could not load bundled BPP-9000 brain",e);}
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(22,24,22,24);root.setBackgroundColor(Color.rgb(15,21,29));
        ScrollView scroll=new ScrollView(this);scroll.addView(root);setContentView(scroll);
        root.addView(label("NEURAXON",26,true));root.addView(label("MULTI-STRATEGY TRADING SYSTEM",11,false));
        root.addView(label("ACTIVE BRAIN",12,true));brainPicker=new Spinner(this);brainPicker.setAdapter(adapter("BPP-9000 E240 (DEFAULT)","Legacy Reservoir (legacy TS fallback)"));root.addView(brainPicker);
        brainInfo=label("BPP-9000 | 1,024 neurons | control 368 | output 443 | reported historical accuracy 65.19%",14,false);root.addView(brainInfo);
        brainPicker.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> p){}public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){brainInfo.setText(pos==0?"BPP-9000 E240 · 1,024 neurons · control 368 · output 443 · genome hash recorded":"Legacy Reservoir · reconstructed from the TypeScript engine packaged in the supplied APK");}});
        root.addView(label("STRATEGY",12,true));strategyPicker=new Spinner(this);strategyPicker.setAdapter(adapter("Brain Only","Trend + Brain","Breakout","Mean Reversion"));strategyPicker.setSelection(1);root.addView(strategyPicker);
        root.addView(label("MARKET",12,true));marketPicker=new Spinner(this);marketPicker.setAdapter(adapter("BTCUSDT","ETHUSDT","BNBUSDT","SOLUSDT","XRPUSDT"));root.addView(marketPicker);
        addButton(root,"DOWNLOAD CLOSED 1H CANDLES",v->downloadCandles());
        addButton(root,"COMPARE STRATEGIES (TRAINING ONLY)",v->compareTraining());
        addButton(root,"EVALUATE SELECTED ON UNSEEN HOLDOUT",v->runBacktest());
        addButton(root,"RISK SETTINGS",v->showSettings());
        root.addView(label("ENGINE STATUS",12,true));status=label("BACKTEST / PAPER SIMULATION READY · Download market history to begin.\nLive exchange orders are disabled until validation is complete.",14,false);root.addView(status);
        root.addView(label("BACKTEST REPORT",12,true));report=label("No backtest run yet.",13,false);root.addView(report);
        root.addView(label("FIXED RISK CONTROLS",12,true));root.addView(label("Max 3 trades/day · 3% daily loss halt · optional 1% profit stop · stop-loss on every trade · optional trailing stop · quiet-market filter · cooldown after loss",13,false));
        root.addView(label("DECISION PIPELINE",12,true));root.addView(label("Market analysis → selected strategy → brain agreement → same brain call for two consecutive closed candles → risk validation → paper execution",13,false));
        root.addView(label("BRAIN NOTE",12,true));root.addView(label("BPP-9000 is an autonomous time-sequence network with no market-input neurons. Its 65.19% is a historical homework score, not out-of-sample trading accuracy. The public Brain Watch documentation says the official live-call/prediction mode is not yet published. This app uses the genome experimentally for paper/backtesting only. Use BPP-9000 only with BTCUSDT; it was trained against Bitcoin hourly directions.",13,false));
    }

    private void downloadCandles(){String symbol=marketPicker.getSelectedItem().toString();status.setText("Downloading fully closed 1-hour candles for "+symbol+"…");
        worker.execute(()->{try{List<Candle> result=BinanceMarketData.fetchHourly(symbol,500);main.post(()->{loadedCandles=result;loadedSymbol=symbol;status.setText("Loaded "+result.size()+" fully closed hourly candles for "+symbol+". Paper/backtest mode only.");});}catch(Exception e){main.post(()->status.setText("Market data error: "+e.getMessage()));}});
    }
    private void compareTraining(){if(loadedCandles.size()<120){status.setText("Download at least 120 closed hourly candles before comparing strategies.");return;}
        int brainMode=brainPicker.getSelectedItemPosition();if(brainMode==0&&!loadedSymbol.equals("BTCUSDT")){status.setText("BPP-9000 is a Bitcoin-hourly brain. Select BTCUSDT or switch to the Legacy Reservoir for this market.");return;}
        status.setText("Comparing all four strategies on training data only…");List<Candle> all=new ArrayList<>(loadedCandles);String symbol=loadedSymbol;EngineConfig cfg=config;
        worker.execute(()->{try{int split=Backtester.chronologicalSplitIndex(all.size(),0.70);List<Candle> train=new ArrayList<>(all.subList(0,split));StringBuilder out=new StringBuilder("TRAINING ONLY · "+symbol+" · "+train.size()+" candles\nUse this segment to choose a strategy. Do not select based on the holdout.");
            for(Strategy s:Strategy.values()){BacktestResult r=Backtester.run(train,brainMode==0?newBpp():new LegacyReservoirBrain(),s,cfg);out.append("\n\n").append(s).append("\nTrades: ").append(r.trades).append(" · Net after fees: ").append(fmt(r.netReturnPct)).append("% · Win rate: ").append(fmt(r.winRatePct)).append("% · Drawdown: ").append(fmt(r.maxDrawdownPct)).append("%");}
            main.post(()->{report.setText(out.toString());status.setText("Training comparison complete. Select one strategy, then evaluate it once on the unseen holdout.");});
        }catch(Exception e){main.post(()->status.setText("Training comparison error: "+e.getMessage()));}});
    }
    private void runBacktest(){if(loadedCandles.size()<120){status.setText("Download at least 120 closed hourly candles before holdout evaluation.");return;}
        int brainMode=brainPicker.getSelectedItemPosition();if(brainMode==0&&!loadedSymbol.equals("BTCUSDT")){status.setText("BPP-9000 is a Bitcoin-hourly brain. Select BTCUSDT or switch to the Legacy Reservoir for this market.");return;}
        status.setText("Evaluating selected strategy on the unseen later segment…");String symbol=loadedSymbol;Strategy strategy=Strategy.values()[strategyPicker.getSelectedItemPosition()];List<Candle> all=new ArrayList<>(loadedCandles);EngineConfig cfg=config;
        worker.execute(()->{try{int split=Backtester.chronologicalSplitIndex(all.size(),0.70);List<Candle> train=new ArrayList<>(all.subList(0,split));List<Candle> test=new ArrayList<>(all.subList(split,all.size()));
            BacktestResult result=Backtester.runWithWarmup(train,test,brainMode==0?newBpp():new LegacyReservoirBrain(),strategy,cfg);
            String text="UNSEEN HOLDOUT · "+symbol+" · "+strategy+"\nTraining candles used only to warm up indicators and brain: "+train.size()+"\nUnseen evaluation candles: "+test.size()+"\n\nTrades: "+result.trades+" · Net after fees: "+fmt(result.netReturnPct)+"% · Win rate: "+fmt(result.winRatePct)+"%\nMax drawdown: "+fmt(result.maxDrawdownPct)+"% · Fees paid: "+fmt(result.feesPaid)+" · Profit factor: "+fmt(result.profitFactor)+"\n\nFee assumption: "+(cfg.feeRatePerSide*100)+"% per side. A small or zero trade count is inconclusive. Do not repeatedly change strategies based on this holdout.";
            main.post(()->{report.setText(text);status.setText("Holdout evaluation complete. This later segment must remain unseen during strategy selection.");});
        }catch(Exception e){main.post(()->status.setText("Holdout evaluation error: "+e.getMessage()));}});
    }
    private void showSettings(){
        LinearLayout panel=new LinearLayout(this);panel.setOrientation(LinearLayout.VERTICAL);panel.setPadding(28,12,28,12);
        EditText maxTrades=settingField(panel,"Maximum trades per day",String.valueOf(config.maxTradesPerDay));
        EditText dailyLoss=settingField(panel,"Daily loss limit (%)",fmt(config.dailyLossLimitPct*100));
        EditText dailyProfit=settingField(panel,"Daily profit stop (%)",fmt(config.dailyProfitStopPct*100));
        EditText risk=settingField(panel,"Risk per trade (%)",fmt(config.riskPerTradePct*100));
        EditText atr=settingField(panel,"Stop distance (ATR multiple)",fmt(config.stopAtrMultiple));
        EditText rr=settingField(panel,"Reward / risk",fmt(config.rewardRisk));
        EditText fee=settingField(panel,"Fee per side (%)",fmt(config.feeRatePerSide*100));
        EditText cooldown=settingField(panel,"Cooldown candles after loss",String.valueOf(config.cooldownCandlesAfterLoss));
        EditText lookback=settingField(panel,"Breakout lookback candles",String.valueOf(config.breakoutLookback));
        CheckBox profitToggle=new CheckBox(this);profitToggle.setText("Enable daily profit stop");profitToggle.setTextColor(Color.rgb(232,236,240));profitToggle.setChecked(config.useDailyProfitStop);panel.addView(profitToggle);
        CheckBox trailingToggle=new CheckBox(this);trailingToggle.setText("Enable trailing stop");trailingToggle.setTextColor(Color.rgb(232,236,240));trailingToggle.setChecked(config.trailingStopEnabled);panel.addView(trailingToggle);
        CheckBox shortToggle=new CheckBox(this);shortToggle.setText("Allow short trades");shortToggle.setTextColor(Color.rgb(232,236,240));shortToggle.setChecked(config.allowShort);panel.addView(shortToggle);
        ScrollView sc=new ScrollView(this);sc.addView(panel);
        new AlertDialog.Builder(this).setTitle("Risk and strategy settings").setView(sc).setNegativeButton("Cancel",null).setPositiveButton("Save",(dialog,which)->{
            try{int mt=Integer.parseInt(maxTrades.getText().toString());int cd=Integer.parseInt(cooldown.getText().toString());int lb=Integer.parseInt(lookback.getText().toString());double dl=Double.parseDouble(dailyLoss.getText().toString())/100.0;double dp=Double.parseDouble(dailyProfit.getText().toString())/100.0;double rp=Double.parseDouble(risk.getText().toString())/100.0;double sm=Double.parseDouble(atr.getText().toString());double rw=Double.parseDouble(rr.getText().toString());double fr=Double.parseDouble(fee.getText().toString())/100.0;
                if(mt<1||cd<0||lb<2||dl<=0||dl>=1||dp<=0||dp>=1||rp<=0||rp>0.05||sm<=0||rw<=0||fr<0||fr>0.02)throw new IllegalArgumentException("One or more settings are outside safe ranges.");
                config.maxTradesPerDay=mt;config.cooldownCandlesAfterLoss=cd;config.breakoutLookback=lb;config.dailyLossLimitPct=dl;config.dailyProfitStopPct=dp;config.riskPerTradePct=rp;config.stopAtrMultiple=sm;config.rewardRisk=rw;config.feeRatePerSide=fr;config.useDailyProfitStop=profitToggle.isChecked();config.trailingStopEnabled=trailingToggle.isChecked();config.allowShort=shortToggle.isChecked();saveConfig();Toast.makeText(this,"Settings saved",Toast.LENGTH_SHORT).show();
            }catch(Exception e){Toast.makeText(this,"Settings not saved: "+e.getMessage(),Toast.LENGTH_LONG).show();}
        }).show();
    }

    private void loadConfig(){android.content.SharedPreferences p=getSharedPreferences("neuraxon_settings",MODE_PRIVATE);try{
        config.maxTradesPerDay=p.getInt("maxTrades",config.maxTradesPerDay);config.cooldownCandlesAfterLoss=p.getInt("cooldown",config.cooldownCandlesAfterLoss);config.breakoutLookback=p.getInt("lookback",config.breakoutLookback);
        config.dailyLossLimitPct=Double.parseDouble(p.getString("dailyLoss",String.valueOf(config.dailyLossLimitPct)));config.dailyProfitStopPct=Double.parseDouble(p.getString("dailyProfit",String.valueOf(config.dailyProfitStopPct)));config.riskPerTradePct=Double.parseDouble(p.getString("risk",String.valueOf(config.riskPerTradePct)));config.stopAtrMultiple=Double.parseDouble(p.getString("atr",String.valueOf(config.stopAtrMultiple)));config.rewardRisk=Double.parseDouble(p.getString("rr",String.valueOf(config.rewardRisk)));config.feeRatePerSide=Double.parseDouble(p.getString("fee",String.valueOf(config.feeRatePerSide)));
        config.useDailyProfitStop=p.getBoolean("profitStop",config.useDailyProfitStop);config.trailingStopEnabled=p.getBoolean("trailing",config.trailingStopEnabled);config.allowShort=p.getBoolean("allowShort",config.allowShort);
    }catch(Exception ignored){config=new EngineConfig();}}
    private void saveConfig(){getSharedPreferences("neuraxon_settings",MODE_PRIVATE).edit().putInt("maxTrades",config.maxTradesPerDay).putInt("cooldown",config.cooldownCandlesAfterLoss).putInt("lookback",config.breakoutLookback)
        .putString("dailyLoss",String.valueOf(config.dailyLossLimitPct)).putString("dailyProfit",String.valueOf(config.dailyProfitStopPct)).putString("risk",String.valueOf(config.riskPerTradePct)).putString("atr",String.valueOf(config.stopAtrMultiple)).putString("rr",String.valueOf(config.rewardRisk)).putString("fee",String.valueOf(config.feeRatePerSide))
        .putBoolean("profitStop",config.useDailyProfitStop).putBoolean("trailing",config.trailingStopEnabled).putBoolean("allowShort",config.allowShort).apply();}

    private EditText settingField(LinearLayout panel,String title,String value){TextView l=label(title,12,false);panel.addView(l);EditText e=new EditText(this);e.setSingleLine(true);e.setInputType(android.text.InputType.TYPE_CLASS_NUMBER|android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL|android.text.InputType.TYPE_NUMBER_FLAG_SIGNED);e.setText(value);panel.addView(e);return e;}

    private Bpp9000Brain newBpp(){try(java.io.InputStream in=getAssets().open("brains/bpp9000-e240.json")){return Bpp9000Brain.load(in);}catch(Exception e){throw new IllegalStateException(e);}}
    private static String fmt(double d){return String.format(java.util.Locale.US,"%.2f",d);}
    private ArrayAdapter<String> adapter(String...items){ArrayAdapter<String>a=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,items);a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);return a;}
    private void addButton(LinearLayout root,String text,View.OnClickListener click){Button b=new Button(this);b.setText(text);b.setOnClickListener(click);root.addView(b);}
    private TextView label(String text,int size,boolean bold){TextView v=new TextView(this);v.setText(text);v.setTextColor(Color.rgb(232,236,240));v.setTextSize(size);v.setPadding(0,12,0,12);if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return v;}
    @Override protected void onDestroy(){super.onDestroy();worker.shutdownNow();}
}
