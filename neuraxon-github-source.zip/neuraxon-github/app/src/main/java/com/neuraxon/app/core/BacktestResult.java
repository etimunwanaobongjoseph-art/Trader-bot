package com.neuraxon.app.core;

public final class BacktestResult {
    public final int trades,wins,losses;
    public final double startingEquity,endingEquity,netReturnPct,maxDrawdownPct,feesPaid,profitFactor,winRatePct;
    public BacktestResult(int trades,int wins,int losses,double start,double end,double dd,double fees,double grossWin,double grossLoss){
        this.trades=trades;this.wins=wins;this.losses=losses;startingEquity=start;endingEquity=end;
        netReturnPct=(end/start-1)*100;maxDrawdownPct=dd;feesPaid=fees;profitFactor=grossLoss==0?(grossWin>0?Double.POSITIVE_INFINITY:0):grossWin/grossLoss;winRatePct=trades==0?0:wins*100.0/trades;
    }
}
