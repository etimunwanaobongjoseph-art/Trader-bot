package com.neuraxon.app;

import com.neuraxon.app.core.Candle;
import org.json.JSONArray;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

final class BinanceMarketData {
    private static final String[] HOSTS={"https://api.binance.com","https://api-gcp.binance.com","https://data-api.binance.vision"};
    static List<Candle> fetchHourly(String symbol,int limit)throws Exception{
        Exception last=null;
        for(String host:HOSTS){HttpURLConnection c=null;try{
            URL u=new URL(host+"/api/v3/klines?symbol="+symbol+"&interval=1h&limit="+Math.min(1000,Math.max(100,limit)));
            c=(HttpURLConnection)u.openConnection();c.setConnectTimeout(10000);c.setReadTimeout(15000);c.setRequestProperty("User-Agent","Neuraxon-Android/3.0");
            int code=c.getResponseCode();if(code<200||code>=300)throw new IllegalStateException("Binance HTTP "+code);
            StringBuilder body=new StringBuilder();try(BufferedReader r=new BufferedReader(new InputStreamReader(c.getInputStream(),StandardCharsets.UTF_8))){String line;while((line=r.readLine())!=null)body.append(line);}
            JSONArray rows=new JSONArray(body.toString());List<Candle> out=new ArrayList<>();long now=System.currentTimeMillis();
            for(int i=0;i<rows.length();i++){JSONArray x=rows.getJSONArray(i);long openTime=x.getLong(0),closeTime=x.getLong(6);if(closeTime>=now)continue;out.add(new Candle(openTime,x.getDouble(1),x.getDouble(2),x.getDouble(3),x.getDouble(4),x.getDouble(5)));}
            if(out.size()<60)throw new IllegalStateException("Not enough fully closed candles from Binance");return out;
        }catch(Exception e){last=e;}finally{if(c!=null)c.disconnect();}}
        throw new IllegalStateException("All public Binance market-data hosts failed",last);
    }
    private BinanceMarketData(){}
}
