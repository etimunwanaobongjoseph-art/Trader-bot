package com.neuraxon.app.core;

public final class Decision {
    public final Signal signal;
    public final String reason;
    public final MarketAnalysis analysis;
    public final BrainDecision brain;
    public final boolean blocked;
    public Decision(Signal s,String r,MarketAnalysis a,BrainDecision b,boolean blocked){signal=s;reason=r;analysis=a;brain=b;this.blocked=blocked;}
}
