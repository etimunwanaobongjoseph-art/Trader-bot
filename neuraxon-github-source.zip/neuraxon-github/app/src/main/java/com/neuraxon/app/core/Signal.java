package com.neuraxon.app.core;

public enum Signal {
    SELL(-1), HOLD(0), BUY(1);
    public final int direction;
    Signal(int direction) { this.direction = direction; }
    public static Signal fromDirection(int direction) {
        return direction > 0 ? BUY : direction < 0 ? SELL : HOLD;
    }
}
