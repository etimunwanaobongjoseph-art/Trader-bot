package com.neuraxon.app.core;

public final class Candle {
    public final long timeMs;
    public final double open, high, low, close, volume;
    private static boolean finite(double v){return !Double.isNaN(v) && !Double.isInfinite(v);}
    public Candle(long timeMs, double open, double high, double low, double close, double volume) {
        if (!(finite(open) && finite(high) && finite(low) && finite(close)
                && finite(volume)) || high < low || volume < 0) throw new IllegalArgumentException("Invalid candle");
        this.timeMs=timeMs; this.open=open; this.high=high; this.low=low; this.close=close; this.volume=volume;
    }
}
