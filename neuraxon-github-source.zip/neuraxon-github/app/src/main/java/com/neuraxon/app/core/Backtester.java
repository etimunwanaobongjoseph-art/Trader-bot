package com.neuraxon.app.core;

import java.util.List;

/** Closed-candle chronological simulator. Fees are charged on both entry and exit. */
public final class Backtester {
    private Backtester(){}
    public static BacktestResult run(List<Candle> candles, Brain brain, Strategy strategy, EngineConfig cfg){
        return runWithWarmup(java.util.Collections.emptyList(), candles, brain, strategy, cfg);
    }
    /** Warmup candles build indicators/brain state but are never traded. Evaluation candles are unseen. */
    public static BacktestResult runWithWarmup(List<Candle> warmup, List<Candle> evaluation, Brain brain, Strategy strategy, EngineConfig cfg){
        StrategyEngine engine=new StrategyEngine(brain,cfg);engine.setStrategy(strategy);
        for(Candle c:warmup) engine.onClosedCandle(c);
        double equity=cfg.startingEquity,peak=equity,maxDd=0,fees=0,grossWin=0,grossLoss=0;
        int trades=0,wins=0,losses=0,tradesToday=0,cooldown=0;long day=-1;double dayStart=equity,dayNet=0;
        Position pos=null;
        for(int candleIndex=0;candleIndex<evaluation.size();candleIndex++){
            Candle c=evaluation.get(candleIndex);
            boolean lossClosedThisCandle=false;
            long d=(c.timeMs/86_400_000L);
            if(d!=day){day=d;dayStart=equity;dayNet=0;tradesToday=0;}
            // Stops/targets use the stop levels established before this candle. If both touch, assume stop first.
            if(pos!=null){
                boolean stop=pos.longSide?c.low<=pos.stop:c.high>=pos.stop;
                boolean target=pos.longSide?c.high>=pos.target:c.low<=pos.target;
                if(stop||target){double px=stop?pos.stop:pos.target;double pnl=pos.longSide?(px-pos.entry)*pos.qty:(pos.entry-px)*pos.qty;
                    double fee=pos.qty*px*cfg.feeRatePerSide;fees+=fee;double cashChange=pnl-fee;double tradeNet=cashChange-pos.entryFee;equity+=cashChange;dayNet+=cashChange;trades++;if(tradeNet>=0){wins++;grossWin+=tradeNet;}else{losses++;grossLoss+=-tradeNet;cooldown=cfg.cooldownCandlesAfterLoss;lossClosedThisCandle=true;}pos=null;}
                else if(cfg.trailingStopEnabled){double trail=cfg.trailingAtrMultiple*pos.atr;if(pos.longSide)pos.stop=Math.max(pos.stop,c.close-trail);else pos.stop=Math.min(pos.stop,c.close+trail);}
            }
            Decision decision=engine.onClosedCandle(c);
            double openPnl=pos==null?0:(pos.longSide?(c.close-pos.entry):(pos.entry-c.close))*pos.qty;
            double dailyNetIncludingOpen=dayNet+openPnl;
            boolean dailyHalt=dailyNetIncludingOpen<=-dayStart*cfg.dailyLossLimitPct || (cfg.useDailyProfitStop&&dailyNetIncludingOpen>=dayStart*cfg.dailyProfitStopPct);
            if(candleIndex<evaluation.size()-1 && pos==null&&!dailyHalt&&tradesToday<cfg.maxTradesPerDay&&cooldown==0&&decision.signal!=Signal.HOLD){
                double stopDist=decision.analysis.atr*cfg.stopAtrMultiple;
                if(stopDist>0&&!Double.isNaN(stopDist)&&!Double.isInfinite(stopDist)){double qty=Math.min((equity*cfg.riskPerTradePct)/stopDist,equity/c.close);if(qty>0&&!Double.isNaN(qty)&&!Double.isInfinite(qty)){
                    double entryFee=qty*c.close*cfg.feeRatePerSide;fees+=entryFee;equity-=entryFee;dayNet-=entryFee;
                    boolean isLong=decision.signal==Signal.BUY;double stop=c.close+(isLong?-stopDist:stopDist),target=c.close+(isLong?1:-1)*stopDist*cfg.rewardRisk;
                    pos=new Position(isLong,c.close,qty,stop,target,decision.analysis.atr,entryFee);tradesToday++;
                }}
            }
            if(cooldown>0 && !lossClosedThisCandle) cooldown--;
            double markedEquity=equity+(pos==null?0:(pos.longSide?(c.close-pos.entry):(pos.entry-c.close))*pos.qty);
            peak=Math.max(peak,markedEquity);if(peak>0)maxDd=Math.max(maxDd,(peak-markedEquity)/peak*100);
        }
        // Close any open position at final close to report realized equity, charging exit fee.
        if(pos!=null&&!evaluation.isEmpty()){double px=evaluation.get(evaluation.size()-1).close;double pnl=pos.longSide?(px-pos.entry)*pos.qty:(pos.entry-px)*pos.qty;double fee=pos.qty*px*cfg.feeRatePerSide;fees+=fee;double cashChange=pnl-fee;double tradeNet=cashChange-pos.entryFee;equity+=cashChange;trades++;if(tradeNet>=0){wins++;grossWin+=tradeNet;}else{losses++;grossLoss+=-tradeNet;}}
        return new BacktestResult(trades,wins,losses,cfg.startingEquity,equity,maxDd,fees,grossWin,grossLoss);
    }
    public static int chronologicalSplitIndex(int totalCandles,double trainingFraction){if(totalCandles<2)throw new IllegalArgumentException("Need at least two candles");if(trainingFraction<=0||trainingFraction>=1)throw new IllegalArgumentException("Training fraction must be between 0 and 1");return Math.max(1,Math.min(totalCandles-1,(int)Math.floor(totalCandles*trainingFraction)));}
    private static final class Position{final boolean longSide;final double entry,qty,target,atr,entryFee;double stop;Position(boolean l,double e,double q,double s,double t,double a,double fee){longSide=l;entry=e;qty=q;stop=s;target=t;atr=a;entryFee=fee;}}
}
