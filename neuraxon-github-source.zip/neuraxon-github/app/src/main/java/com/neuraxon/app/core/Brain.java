package com.neuraxon.app.core;

public interface Brain {
    BrainDecision onClosedCandle(Candle candle);
    String name();
    void reset();
}
