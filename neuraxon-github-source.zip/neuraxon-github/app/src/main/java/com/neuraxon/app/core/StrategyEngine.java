package com.neuraxon.app.core;

import java.util.ArrayList;
import java.util.List;

/** Strategy candidates are independent from brain inference; disagreement always blocks an entry. */
public final class StrategyEngine {
    private final Brain brain;
    private final EngineConfig cfg;
    private final List<Candle> candles=new ArrayList<>();
    private Signal previousBrainCall=Signal.HOLD;
    private int consecutiveBrainCalls;
    private Strategy strategy=Strategy.TREND_BRAIN;
    public StrategyEngine(Brain brain,EngineConfig cfg){this.brain=brain;this.cfg=cfg;}
    public void setStrategy(Strategy s){strategy=s;}
    public Strategy strategy(){return strategy;}
    public Decision onClosedCandle(Candle candle){
        candles.add(candle);if(candles.size()>1000)candles.remove(0);
        BrainDecision bd=brain.onClosedCandle(candle);
        if(bd.signal!=Signal.HOLD&&bd.signal==previousBrainCall)consecutiveBrainCalls++;else consecutiveBrainCalls=bd.signal==Signal.HOLD?0:1;
        previousBrainCall=bd.signal;
        MarketAnalysis a=MarketAnalysis.calculate(candles);
        if(candles.size()<55)return new Decision(Signal.HOLD,"Warm-up: waiting for at least 55 closed candles",a,bd,true);
        if(a.atrPct<cfg.quietAtrPctFloor)return new Decision(Signal.HOLD,"Blocked: quiet-market filter",a,bd,true);
        Signal candidate=candidateSignal(a,bd);
        if(candidate==Signal.HOLD)return new Decision(Signal.HOLD,"No valid setup for selected strategy",a,bd,false);
        if(candidate!=bd.signal)return new Decision(Signal.HOLD,"Blocked: analytical strategy and brain disagree",a,bd,true);
        if(consecutiveBrainCalls<2)return new Decision(Signal.HOLD,"Blocked: brain call has not repeated for two closed candles",a,bd,true);
        if(candidate==Signal.BUY && candle.close<=a.emaSlow)return new Decision(Signal.HOLD,"Blocked: long entries require price above long moving average",a,bd,true);
        if(candidate==Signal.SELL && candle.close>=a.emaSlow)return new Decision(Signal.HOLD,"Blocked: short entries require price below long moving average",a,bd,true);
        if(candidate==Signal.SELL&&!cfg.allowShort)return new Decision(Signal.HOLD,"Blocked: short selling is disabled",a,bd,true);
        return new Decision(candidate,reason(candidate,a),a,bd,false);
    }
    private Signal candidateSignal(MarketAnalysis a,BrainDecision b){
        Candle last=candles.get(candles.size()-1);
        switch(strategy){
            case BRAIN_ONLY: return b.signal;
            case TREND_BRAIN: return a.trendDirection>0?Signal.BUY:a.trendDirection<0?Signal.SELL:Signal.HOLD;
            case BREAKOUT:
                if(candles.size()<cfg.breakoutLookback+2||!a.volumeAboveAverage)return Signal.HOLD;
                double hh=Double.NEGATIVE_INFINITY,ll=Double.POSITIVE_INFINITY;
                for(int i=candles.size()-cfg.breakoutLookback-1;i<candles.size()-1;i++){hh=Math.max(hh,candles.get(i).high);ll=Math.min(ll,candles.get(i).low);}
                return last.close>hh?Signal.BUY:last.close<ll?Signal.SELL:Signal.HOLD;
            case MEAN_REVERSION:
                if(a.regime!=MarketAnalysis.Regime.RANGING)return Signal.HOLD;
                return a.rsi<30?Signal.BUY:a.rsi>70?Signal.SELL:Signal.HOLD;
            default:return Signal.HOLD;
        }
    }
    private String reason(Signal s,MarketAnalysis a){return strategy+": "+(s==Signal.BUY?"LONG":"SHORT")+" candidate; trend="+a.regime+", RSI="+String.format(java.util.Locale.US,"%.1f",a.rsi)+"; brain confirmed twice";}
    public void reset(){candles.clear();previousBrainCall=Signal.HOLD;consecutiveBrainCalls=0;brain.reset();}
    public List<Candle> candles(){return new ArrayList<>(candles);}
}
