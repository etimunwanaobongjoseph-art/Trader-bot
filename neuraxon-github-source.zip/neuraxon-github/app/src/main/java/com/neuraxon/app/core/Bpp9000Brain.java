package com.neuraxon.app.core;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

/** Exact BPP-9000 trit network runtime. Each tick reads only the previous state snapshot. */
public final class Bpp9000Brain implements Brain {
    public static final int NEURONS = 1024;
    private final int[][] sources = new int[NEURONS][3];
    private final byte[][] lut = new byte[NEURONS][27];
    private final byte[] initial = new byte[NEURONS];
    private byte[] state = new byte[NEURONS];
    private final int controlIndex, outputIndex;
    private final String hash;
    private final double reportedAccuracy;
    private final long taskStartMs;
    private final long taskHours;
    private long ticks;
    private long lastCandleOpenMs = -1L;
    private static final long HOUR_MS = 3_600_000L;

    public static Bpp9000Brain load(InputStream in) throws Exception {
        java.io.ByteArrayOutputStream buffer = new java.io.ByteArrayOutputStream();
        byte[] chunk = new byte[8192]; int count;
        while ((count = in.read(chunk)) != -1) buffer.write(chunk, 0, count);
        byte[] bytes = buffer.toByteArray();
        JSONObject root = new JSONObject(new String(bytes, StandardCharsets.UTF_8));
        if (!"qc-bpp9000-brain-v1".equals(root.getString("format"))) throw new IllegalArgumentException("Unsupported brain format");
        JSONArray nodes = root.getJSONArray("nodes");
        if (nodes.length() != NEURONS) throw new IllegalArgumentException("Expected exactly 1024 neurons");
        JSONObject task = root.getJSONObject("task");
        Bpp9000Brain brain = new Bpp9000Brain(root.getInt("control"), root.getInt("output"), root.getString("hash"),
                root.getJSONObject("score").optDouble("accuracy", Double.NaN), task.getLong("start") * 1000L, task.getLong("hours"));
        for (int i=0;i<NEURONS;i++) {
            JSONObject node=nodes.getJSONObject(i);
            if (node.getInt("id") != i) throw new IllegalArgumentException("Neuron IDs must be contiguous and ordered");
            int init=node.getInt("initialState");
            if (init<0 || init>2) throw new IllegalArgumentException("Invalid initial trit at neuron "+i);
            brain.initial[i]=(byte)init;
            JSONArray src=node.getJSONArray("sources"), table=node.getJSONArray("lut");
            if(src.length()!=3 || table.length()!=27) throw new IllegalArgumentException("Invalid source/LUT dimensions at neuron "+i);
            for(int j=0;j<3;j++){ int v=src.getInt(j); if(v<0||v>=NEURONS) throw new IllegalArgumentException("Invalid source index"); brain.sources[i][j]=v; }
            for(int j=0;j<27;j++){ int v=table.getInt(j); if(v<0||v>2) throw new IllegalArgumentException("Invalid LUT trit"); brain.lut[i][j]=(byte)v; }
        }
        brain.reset();
        return brain;
    }

    private Bpp9000Brain(int control, int output, String hash, double accuracy, long taskStartMs, long taskHours) {
        if(control<0||control>=NEURONS||output<0||output>=NEURONS) throw new IllegalArgumentException("Invalid control/output neuron");
        this.controlIndex=control; this.outputIndex=output; this.hash=hash; this.reportedAccuracy=accuracy;
        this.taskStartMs=taskStartMs; this.taskHours=taskHours;
    }

    @Override public synchronized BrainDecision onClosedCandle(Candle candle) {
        if(lastCandleOpenMs<0){
            // Alignment assumption: task.start is treated as the open-time of the first target candle.
            // Verify this convention against the Qubic reference runner before using live predictions.
            long elapsed=candle.timeMs-taskStartMs;
            if(elapsed<0 || elapsed%HOUR_MS!=0) throw new IllegalArgumentException("Candle time is before or misaligned with the BPP-9000 task start");
            fastForward(elapsed/HOUR_MS);
        } else {
            long elapsed=candle.timeMs-lastCandleOpenMs;
            if(elapsed<=0 || elapsed%HOUR_MS!=0) throw new IllegalArgumentException("BPP-9000 candles must be strictly increasing hourly opens");
            long missing=elapsed/HOUR_MS-1;
            if(missing>0) fastForward(missing);
        }
        lastCandleOpenMs=candle.timeMs;
        tickOnce();
        int control=state[controlIndex], output=state[outputIndex];
        // Qubic mapping: 0=down, 1=up/flat, 2=not sure. Control=2 means no call.
        Signal signal=(control==2 || output==2) ? Signal.HOLD : (output==0 ? Signal.SELL : Signal.BUY);
        return new BrainDecision(signal, control, output, name());
    }

    private void fastForward(long hours){ for(long i=0;i<hours;i++) tickOnce(); }
    private void tickOnce(){
        byte[] previous=state; byte[] next=new byte[NEURONS];
        for(int i=0;i<NEURONS;i++){
            int s0=previous[sources[i][0]],s1=previous[sources[i][1]],s2=previous[sources[i][2]];
            next[i]=lut[i][s0+3*s1+9*s2];
        }
        state=next; ticks++;
    }
    @Override public synchronized void reset(){ System.arraycopy(initial,0,state,0,NEURONS); ticks=0; lastCandleOpenMs=-1L; }
    @Override public String name(){ return "BPP-9000 E240"; }
    public String hash(){ return hash; }
    public long taskHours(){ return taskHours; }
    public long taskStartMs(){ return taskStartMs; }
    public double reportedAccuracy(){ return reportedAccuracy; }
    public long ticks(){ return ticks; }
    public int controlIndex(){ return controlIndex; }
    public int outputIndex(){ return outputIndex; }
}
