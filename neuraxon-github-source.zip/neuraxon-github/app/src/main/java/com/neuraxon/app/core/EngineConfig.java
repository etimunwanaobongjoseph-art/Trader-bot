package com.neuraxon.app.core;

public final class EngineConfig {
    public int maxTradesPerDay=3;
    public double dailyLossLimitPct=0.03;
    public double dailyProfitStopPct=0.01;
    public boolean useDailyProfitStop=false;
    public double riskPerTradePct=0.01;
    public double stopAtrMultiple=1.5;
    public double rewardRisk=2.0;
    public boolean trailingStopEnabled=false;
    public double trailingAtrMultiple=1.0;
    public int cooldownCandlesAfterLoss=3;
    public int breakoutLookback=20;
    public double quietAtrPctFloor=0.00025;
    public double feeRatePerSide=0.001; // 0.10% each side, overridable per venue
    public double startingEquity=10000;
    public boolean allowShort=true;
}
