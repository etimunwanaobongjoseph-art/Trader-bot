package com.neuraxon.app.core;

import java.util.ArrayList;
import java.util.List;

/** Java port of the legacy reservoir/readout brain embedded in the supplied APK asset. */
public final class LegacyReservoirBrain implements Brain {
    private static final int N=1024, INPUT=164, CONTROL=90, OUTPUT=770, K=16, FEATURES=8;
    private final int[] links=new int[N*K];
    private final float[] weights=new float[N*K], inputWeights=new float[INPUT], readout=new float[OUTPUT];
    private float[] state=new float[N], lastSnapshot;
    private float lastPred;
    private final List<Candle> candles=new ArrayList<>();
    private double previousClose=Double.NaN, previousVol=1e-3;
    private final double threshold;

    public LegacyReservoirBrain(){this(0.25);}
    public LegacyReservoirBrain(double threshold){this.threshold=threshold; LegacyRng r=new LegacyRng(1337);
        for(int i=0;i<N;i++) for(int k=0;k<K;k++){links[i*K+k]=(int)Math.floor(r.next()*N);weights[i*K+k]=(float)(r.signed()*0.45);}
        for(int i=0;i<INPUT;i++) inputWeights[i]=(float)r.signed();
    }
    /** Exact unsigned-32-bit LCG used by the TypeScript asset. */
    private static final class LegacyRng {
        private long state;
        LegacyRng(long seed){state=seed&0xffffffffL;}
        double next(){state=(state*1664525L+1013904223L)&0xffffffffL;return state/4294967296.0;}
        double signed(){return next()*2.0-1.0;}
    }
    @Override public synchronized BrainDecision onClosedCandle(Candle c){
        candles.add(c); if(candles.size()>500)candles.remove(0);
        if(!Double.isNaN(previousClose) && !Double.isInfinite(previousClose)&&candles.size()>1){double r=(c.close-previousClose)/previousClose/Math.max(previousVol,1e-9); learn((float)Math.max(-1,Math.min(1,r/2)));}
        previousClose=c.close;
        if(candles.size()<50)return new BrainDecision(Signal.HOLD,2,2,name());
        Features f=features(); previousVol=f.vol;
        float[] next=new float[N];
        for(int i=0;i<N;i++){double sum=0;for(int k=0;k<K;k++)sum+=weights[i*K+k]*state[links[i*K+k]];if(i<INPUT)sum+=inputWeights[i]*f.values[i%FEATURES];next[i]=(float)(0.7*state[i]+0.3*Math.tanh(sum));}
        state=next; double out=0;for(int j=0;j<OUTPUT;j++)out+=readout[j]*state[INPUT+CONTROL+j];
        double pred=Math.tanh(out), gate=0;for(int j=0;j<CONTROL;j++)gate+=Math.abs(state[INPUT+j]);gate=Math.min(1,gate/CONTROL*2);
        double confidence=Math.abs(pred)*(0.5+0.5*gate); lastSnapshot=new float[OUTPUT];System.arraycopy(state,INPUT+CONTROL,lastSnapshot,0,OUTPUT);lastPred=(float)pred;
        Signal s=confidence<threshold?Signal.HOLD:(pred>0?Signal.BUY:Signal.SELL);
        return new BrainDecision(s,1,s==Signal.BUY?1:s==Signal.SELL?0:2,name());
    }
    private void learn(float target){if(lastSnapshot==null)return;double norm=1e-6;for(float v:lastSnapshot)norm+=v*v;double err=target-lastPred;for(int j=0;j<OUTPUT;j++)readout[j]+=(float)(0.05*err*lastSnapshot[j]/norm);}
    private static double ema(double[] v,int p){double a=2.0/(p+1),e=v[0];for(int i=1;i<v.length;i++)e=a*v[i]+(1-a)*e;return e;}
    private Features features(){int n=candles.size();double[] closes=new double[n];for(int i=0;i<n;i++)closes[i]=candles.get(i).close;double last=closes[n-1];
        double[] rets=new double[20];double mean=0;for(int i=0;i<20;i++){rets[i]=(closes[n-20+i]-closes[n-21+i])/closes[n-21+i];mean+=rets[i];}mean/=20;
        double variance=0;for(double x:rets)variance+=(x-mean)*(x-mean);double vol=Math.sqrt(variance/20);if(vol==0)vol=1e-6;
        double avgVol=0;for(int i=n-20;i<n;i++)avgVol+=candles.get(i).volume;avgVol/=20;if(avgVol==0)avgVol=1;
        double gain=0,loss=0;for(int i=n-14;i<n;i++){double d=closes[i]-closes[i-1];if(d>=0)gain+=d;else loss-=d;}double rsi=loss==0?100:100-100/(1+gain/loss);
        double[] shortTail=new double[12],longTail=new double[26];System.arraycopy(closes,n-12,shortTail,0,12);System.arraycopy(closes,n-26,longTail,0,26);
        double[] v={clip((last-closes[n-2])/closes[n-2]/vol),clip((last-closes[n-6])/closes[n-6]/(vol*Math.sqrt(5))),clip((last-closes[n-21])/closes[n-21]/(vol*Math.sqrt(20))), (rsi-50)/25,clip((ema(shortTail,12)-ema(longTail,26))/last/vol),clip(vol*100),clip(candles.get(n-1).volume/avgVol-1),1};
        return new Features(v,vol);
    }
    private static double clip(double v){return Math.max(-3,Math.min(3,v));}
    @Override public synchronized void reset(){state=new float[N];candles.clear();previousClose=Double.NaN;previousVol=1e-3;lastSnapshot=null;lastPred=0;}
    @Override public String name(){return "Legacy Reservoir (APK)";}
    private static final class Features{final double[] values;final double vol;Features(double[] v,double vol){values=v;this.vol=vol;}}
}
