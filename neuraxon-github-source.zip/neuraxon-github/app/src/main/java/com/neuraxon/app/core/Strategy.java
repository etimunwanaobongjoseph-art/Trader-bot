package com.neuraxon.app.core;
public enum Strategy { BRAIN_ONLY, TREND_BRAIN, BREAKOUT, MEAN_REVERSION }
