package com.neuraxon.app.core;

import java.util.List;

public final class MarketAnalysis {
    public enum Regime { TRENDING_UP, TRENDING_DOWN, RANGING, QUIET, UNKNOWN }
    public final Regime regime;
    public final int trendDirection;
    public final double emaFast, emaSlow, atr, atrPct, rsi, averageVolume;
    public final boolean volumeAboveAverage;
    private MarketAnalysis(Regime r,int d,double ef,double es,double atr,double atrPct,double rsi,double av,boolean va){this.regime=r;trendDirection=d;emaFast=ef;emaSlow=es;this.atr=atr;this.atrPct=atrPct;this.rsi=rsi;averageVolume=av;volumeAboveAverage=va;}
    public static MarketAnalysis calculate(List<Candle> c){
        if(c.size()<55)return new MarketAnalysis(Regime.UNKNOWN,0,0,0,0,0,50,0,false);
        double fast=ema(c,20),slow=ema(c,50),atr=atr(c,14),last=c.get(c.size()-1).close;
        double rsi=rsi(c,14),av=0;for(int i=c.size()-20;i<c.size();i++)av+=c.get(i).volume;av/=20;
        boolean vol=c.get(c.size()-1).volume>av;
        int dir=(fast>slow&&last>slow)?1:(fast<slow&&last<slow)?-1:0;
        double atrPct=last==0?0:atr/last;
        Regime regime=atrPct<0.00025?Regime.QUIET:dir>0?Regime.TRENDING_UP:dir<0?Regime.TRENDING_DOWN:Regime.RANGING;
        return new MarketAnalysis(regime,dir,fast,slow,atr,atrPct,rsi,av,vol);
    }
    public static double ema(List<Candle> c,int p){double a=2.0/(p+1),e=c.get(c.size()-p).close;for(int i=c.size()-p+1;i<c.size();i++)e=a*c.get(i).close+(1-a)*e;return e;}
    public static double atr(List<Candle> c,int p){double sum=0;for(int i=c.size()-p;i<c.size();i++){Candle x=c.get(i),prev=c.get(i-1);sum+=Math.max(x.high-x.low,Math.max(Math.abs(x.high-prev.close),Math.abs(x.low-prev.close)));}return sum/p;}
    public static double rsi(List<Candle> c,int p){double g=0,l=0;for(int i=c.size()-p;i<c.size();i++){double d=c.get(i).close-c.get(i-1).close;if(d>=0)g+=d;else l-=d;}return l==0?100:100-100/(1+g/l);}
}
