package com.neuraxon.app.core;

public final class BrainDecision {
    public final Signal signal;
    public final int controlTrit;
    public final int outputTrit;
    public final String brainName;
    public BrainDecision(Signal signal, int controlTrit, int outputTrit, String brainName) {
        this.signal=signal; this.controlTrit=controlTrit; this.outputTrit=outputTrit; this.brainName=brainName;
    }
    public boolean isValidCall() { return controlTrit != 2 && outputTrit != 2; }
}
