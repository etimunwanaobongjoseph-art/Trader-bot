package com.neuraxon.app;

import java.nio.file.*;
import java.util.*;

/** Self-contained checks, no Android needed. Run with core-tests/run.sh */
public class CoreTests {
    static int fails = 0;
    static void check(String name, boolean ok, String detail) {
        System.out.println((ok ? "PASS " : "FAIL ") + name + (detail.isEmpty() ? "" : "  [" + detail + "]"));
        if (!ok) fails++;
    }

    static final long T0 = 1_780_000_000_000L; // arbitrary start, hour aligned below
    static List<NeuraxonEngine.Candle> randomWalk(long seed, int n, long t0) {
        Random r = new Random(seed);
        List<NeuraxonEngine.Candle> out = new ArrayList<>();
        double px = 100;
        for (int i = 0; i < n; i++) {
            double ret = r.nextGaussian() * 0.005;
            double o = px, c = px * (1 + ret);
            double hi = Math.max(o, c) * (1 + Math.abs(r.nextGaussian()) * 0.002);
            double lo = Math.min(o, c) * (1 - Math.abs(r.nextGaussian()) * 0.002);
            out.add(new NeuraxonEngine.Candle(t0 + i * 3600000L, o, hi, lo, c, 1000 * (0.5 + r.nextDouble())));
            px = c;
        }
        return out;
    }

    static List<Backtester.Series> randomSeries(long seed, int n) {
        List<Backtester.Series> in = new ArrayList<>();
        String[] syms = {"AAAUSDT", "BBBUSDT", "CCCUSDT", "DDDUSDT", "EEEUSDT"};
        long t0 = (T0 / 3600000L) * 3600000L;
        for (int i = 0; i < syms.length; i++) {
            Backtester.Series s = new Backtester.Series();
            s.sym = syms[i]; s.candles = randomWalk(seed * 10 + i, n, t0);
            in.add(s);
        }
        return Backtester.align(in);
    }

    public static void main(String[] args) throws Exception {
        String brainTxt = new String(Files.readAllBytes(Paths.get(args[0])));
        Bpp9000Brain bpp = Bpp9000Brain.parse(brainTxt);

        // 1. brain file parses and steps like the reference simulation
        int[] exp = {2, 1, 0, 0, 0, 0};
        boolean ok = true; StringBuilder got = new StringBuilder();
        for (int i = 0; i < 6; i++) { int v = bpp.stickyCall(i); got.append(v).append(' '); ok &= v == exp[i]; }
        check("BPP brain steps like reference simulation", ok, got.toString().trim());

        // 2. random data: original brain accuracy near 50%, strategies do not invent an edge
        double accSum = 0; int accN = 0; double[] netSum = new double[4]; int[] tr = new int[4]; int runs = 6;
        for (int seed = 1; seed <= runs; seed++) {
            List<Backtester.Series> data = randomSeries(seed, 3000);
            int hit = 0, cnt = 0, n = data.get(0).candles.size();
            for (Backtester.Series s : data) for (int i = 0; i < n - 1; i++) {
                if (!"BUY".equals(s.raw[i].signal) && !"SELL".equals(s.raw[i].signal)) continue;
                cnt++; if (("BUY".equals(s.raw[i].signal)) == (s.candles.get(i + 1).close >= s.candles.get(i).close)) hit++;
            }
            accSum += hit; accN += cnt;
            for (Backtester.Row r : Backtester.runAll(new Params(), data, null, null)) {
                netSum[r.strategy.ordinal()] += r.judge.net; tr[r.strategy.ordinal()] += r.judge.trades;
            }
        }
        double acc = accSum * 100 / accN;
        check("random data: original brain accuracy ~50%", Math.abs(acc - 50) < 1.5, String.format("%.2f%% over %d calls", acc, accN));
        StringBuilder sb = new StringBuilder();
        boolean noEdge = true;
        for (Strategy s : Strategy.values()) {
            double avg = netSum[s.ordinal()] / runs; sb.append(String.format("%s avg %+.2f%% (%d trades) | ", s.label, avg, tr[s.ordinal()]));
            noEdge &= avg < 0.5;
        }
        check("random data: no strategy shows a profit after costs", noEdge, sb.toString());

        // 3. BPP calibration: pure noise must NOT verify; a planted alignment MUST verify
        int falseVerifies = 0;
        for (int seed = 1; seed <= 30; seed++) {
            Bpp9000Brain.Calibration c = bpp.calibrate(randomWalk(1000 + seed, 1000, bpp.startMs + 500 * 3600000L));
            if (c.verified) falseVerifies++;
        }
        check("BPP calibration: 30 noise series, none verified", falseVerifies == 0, falseVerifies + " false verifies");
        Random pr = new Random(7);
        List<NeuraxonEngine.Candle> planted = new ArrayList<>();
        double px = 100; int plantShift = 37; long pt0 = bpp.startMs + 800 * 3600000L;
        planted.add(new NeuraxonEngine.Candle(pt0, px, px, px, px, 1));
        for (int i = 1; i < 1000; i++) {
            long k = bpp.hourIndex(pt0 + i * 3600000L);
            boolean callUp = bpp.stickyCall((int) (k + plantShift)) == 1;
            boolean up = pr.nextDouble() < 0.65 ? callUp : !callUp;
            double c = px * (1 + (up ? 1 : -1) * 0.004 * (0.5 + pr.nextDouble()));
            planted.add(new NeuraxonEngine.Candle(pt0 + i * 3600000L, px, Math.max(px, c), Math.min(px, c), c, 1));
            px = c;
        }
        Bpp9000Brain.Calibration pc = bpp.calibrate(planted);
        check("BPP calibration: planted 65% alignment is found", pc.verified && pc.shift == plantShift,
                "verified=" + pc.verified + " shift=" + pc.shift + String.format(" hit=%.1f%% z=%.1f", pc.hitPct, pc.z));

        // 4. planted pattern for the original (learning) brain
        List<NeuraxonEngine.Candle> pat = new ArrayList<>();
        Random q = new Random(3); double pp = 100;
        for (int i = 0; i < 3000; i++) {
            boolean up = (i % 2) == 0; double c = pp * (1 + (up ? 1 : -1) * 0.004 * (0.7 + 0.6 * q.nextDouble()));
            pat.add(new NeuraxonEngine.Candle(T0 + i * 3600000L, pp, Math.max(pp, c), Math.min(pp, c), c, 1000)); pp = c;
        }
        NeuraxonEngine.Result[] pr2 = Backtester.precompute(pat, 1337);
        int h = 0, cnt = 0;
        for (int i = 2000; i < 2999; i++) {
            if (!"BUY".equals(pr2[i].signal) && !"SELL".equals(pr2[i].signal)) continue;
            cnt++; if (("BUY".equals(pr2[i].signal)) == (pat.get(i + 1).close >= pat.get(i).close)) h++;
        }
        System.out.println("INFO planted alternating up/down pattern (a learner should reach 90%+): original brain hit rate on candles 2000-3000 = " + String.format("%.1f%% over %d calls", h * 100.0 / cnt, cnt));

        // 5. no peeking: decisions before a cut are identical whether or not the future exists
        List<Backtester.Series> full = randomSeries(42, 1500);
        Map<String, Bpp9000Brain.Calibration> fake = new HashMap<>();
        for (Backtester.Series s : full) { Bpp9000Brain.Calibration c = new Bpp9000Brain.Calibration(); c.verified = true; c.shift = 118; fake.put(s.sym, c); }
        boolean same = true; String why = "";
        for (BrainMode m : BrainMode.values()) for (Strategy s : Strategy.values()) {
            Params p = new Params(); p.minConfidence = 0.05; p.quietAtrPct = 0.0;
            int cut = 1000;
            PortfolioSim a = new PortfolioSim(s, m, p, bpp, fake, 10000, true), b = new PortfolioSim(s, m, p, bpp, fake, 10000, true);
            Random fr = new Random(9);
            for (int i = 0; i < 1500; i++) for (Backtester.Series se : full) {
                NeuraxonEngine.Candle c = se.candles.get(i);
                a.onCandle(se.sym, c, Backtester.withMin(se.raw[i], p.minConfidence));
                if (i < cut) b.onCandle(se.sym, c, Backtester.withMin(se.raw[i], p.minConfidence));
            }
            List<PortfolioSim.Trade> ta = new ArrayList<>();
            for (PortfolioSim.Trade t : a.trades) if (t.exitT < full.get(0).candles.get(cut).time) ta.add(t);
            if (ta.size() != b.trades.size()) { same = false; why = m + "/" + s + " " + ta.size() + " vs " + b.trades.size(); break; }
            for (int i = 0; i < ta.size(); i++) if (Math.abs(ta.get(i).pnl - b.trades.get(i).pnl) > 1e-9 || ta.get(i).exitT != b.trades.get(i).exitT) { same = false; why = m + "/" + s + " trade " + i; }
        }
        check("no future peeking: same trades with and without later candles (12 combos)", same, why);

        // 6. rules on a volatile, trending-ish series with loose settings
        List<Backtester.Series> d = randomSeries(5, 4000);
        Params p = new Params(); p.minConfidence = 0.0; p.quietAtrPct = 0.0; p.confirmCandles = 1; p.trendLen = 20; p.maxTradesPerDay = 3; p.dayLossPct = 3; p.cooldownCandles = 3;
        PortfolioSim sim = Backtester.simulate(Strategy.BRAIN_ONLY, BrainMode.ORIGINAL, p, d, null, null, true);
        Map<Long, Integer> perDay = new HashMap<>(); int maxDay = 0;
        for (PortfolioSim.Trade t : sim.trades) { int v = perDay.merge(Math.floorDiv(t.entryT, 86400000L), 1, Integer::sum); maxDay = Math.max(maxDay, v); }
        check("rule 3: never more than 3 entries in a UTC day", maxDay <= 3 && sim.trades.size() > 30, "max/day " + maxDay + ", trades " + sim.trades.size());
        double worst = 0; for (PortfolioSim.Trade t : sim.trades) worst = Math.min(worst, t.pnl);
        check("rule 5: worst single trade loss under 1.6% of start equity", -worst < 160, String.format("worst %.2f", worst));
        // cooldown: after a losing exit, no entry on the same pair within 3 candles
        boolean cdOk = true;
        Map<String, Long> lastLoss = new HashMap<>();
        List<PortfolioSim.Trade> sorted = new ArrayList<>(sim.trades);
        for (PortfolioSim.Trade t : sorted) {
            Long ll = lastLoss.get(t.sym);
            if (ll != null && t.entryT < ll + 3 * 3600000L && t.entryT >= ll) cdOk = false;
            if (t.pnl < 0) lastLoss.put(t.sym, t.exitT);
        }
        check("rule 6: pause after a loss respected", cdOk, "");
        // rule 1: unit check of confirmation
        Params p1 = new Params(); p1.confirmCandles = 2; p1.quietAtrPct = 0; p1.trendLen = 5; p1.breakoutN = 5; p1.erLen = 5; p1.volLen = 5;
        SignalGate g = new SignalGate(Strategy.BRAIN_ONLY, BrainMode.ORIGINAL, p1, null, null);
        List<NeuraxonEngine.Candle> cs = randomWalk(1, 60, T0);
        int entriesAfterOne = 0, firstConf = -1; String prev = "";
        for (int i = 0; i < 60; i++) {
            String sig = (i % 7 < 3) ? "BUY" : "HOLD";
            SignalGate.Decision dd = g.onCandle(cs.get(i), new NeuraxonEngine.Result(sig, 1.0, 1.0));
            if (dd.entry != null && !(sig.equals("BUY") && prev.equals("BUY"))) entriesAfterOne++;
            prev = sig;
        }
        check("rule 1: no entry unless the same call came twice in a row", entriesAfterOne == 0, "bad entries " + entriesAfterOne);

        System.out.println(fails == 0 ? "ALL CHECKS PASSED" : (fails + " CHECK(S) FAILED"));
        System.exit(fails == 0 ? 0 : 1);
    }
}
