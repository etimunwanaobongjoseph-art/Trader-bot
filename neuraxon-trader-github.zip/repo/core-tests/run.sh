#!/bin/sh
# Compiles the core (no Android needed) and runs the checks. Needs JDK 17+.
set -e
cd "$(dirname "$0")/.."
mkdir -p core-tests/out
JAVAC="javac"; command -v javac >/dev/null 2>&1 || JAVAC="java -m jdk.compiler/com.sun.tools.javac.Main"
$JAVAC -d core-tests/out $(ls app/src/main/java/com/neuraxon/app/*.java | grep -v -e MainActivity -e BinanceTrader -e '/R.java') core-tests/CoreTests.java
java -cp core-tests/out com.neuraxon.app.CoreTests app/src/main/assets/bpp9000-brain.txt
