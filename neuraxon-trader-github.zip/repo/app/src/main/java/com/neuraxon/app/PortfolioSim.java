package com.neuraxon.app;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * One paper account trading several pairs with the strategy, both brains and rules 1 to 6.
 * Used by the live paper mode AND the backtester, so what you test is what runs.
 * Costs: fee per side and slippage per side on every fill. No leverage (open notional <= equity).
 */
final class PortfolioSim {
    static final class Pos {
        boolean lng;
        double entry, qty, stop, target, stopDist, extreme;
        long openT;
    }

    static final class Trade {
        String sym;
        boolean lng;
        long entryT, exitT;
        double pnl;
        String exit;
    }

    final Map<String, Pos> positions = new LinkedHashMap<>();
    final List<Trade> trades = new ArrayList<>();
    final double startEquity;
    double equity;
    String lastBlock = "";

    private final Strategy strategy;
    private final BrainMode mode;
    private final Params p;
    private final Bpp9000Brain bpp;
    private final Map<String, Bpp9000Brain.Calibration> cals;
    private final boolean longOnly;
    private final RiskState risk;
    private final Map<String, SignalGate> gates = new HashMap<>();

    PortfolioSim(Strategy strategy, BrainMode mode, Params p, Bpp9000Brain bpp,
                 Map<String, Bpp9000Brain.Calibration> cals, double startEquity, boolean longOnly) {
        this.strategy = strategy; this.mode = mode; this.p = p; this.bpp = bpp; this.cals = cals;
        this.startEquity = startEquity; this.equity = startEquity; this.longOnly = longOnly;
        this.risk = new RiskState(p);
    }

    private SignalGate gateFor(String sym) {
        SignalGate gate = gates.get(sym);
        if (gate == null) {
            gate = new SignalGate(strategy, mode, p, bpp, cals == null ? null : cals.get(sym));
            gates.put(sym, gate);
        }
        return gate;
    }

    /** Feed a candle for history only (warm-up). No trade is opened or closed. */
    SignalGate.Decision observe(String sym, NeuraxonEngine.Candle c, NeuraxonEngine.Result r) {
        return gateFor(sym).onCandle(c, r);
    }

    SignalGate.Decision onCandle(String sym, NeuraxonEngine.Candle c, NeuraxonEngine.Result r) {
        SignalGate.Decision d = gateFor(sym).onCandle(c, r);

        Pos pos = positions.get(sym);
        if (pos != null && pos.openT < c.time) {
            double exit = Double.NaN;
            String why = null;
            if (pos.lng) {
                if (c.low <= pos.stop) { exit = Math.min(pos.stop, c.open); why = "stop"; }
                else if (c.high >= pos.target) { exit = pos.target; why = "target"; }
                else if (d.exitLong) { exit = c.close; why = "brain flipped"; }
            } else {
                if (c.high >= pos.stop) { exit = Math.max(pos.stop, c.open); why = "stop"; }
                else if (c.low <= pos.target) { exit = pos.target; why = "target"; }
                else if (d.exitShort) { exit = c.close; why = "brain flipped"; }
            }
            if (why != null) {
                close(sym, pos, exit, why, c.time);
                pos = null;
            } else if (p.trailing) {
                // trail behind the best price seen so far; the stop only ever moves in the trade's favour
                if (pos.lng) {
                    pos.extreme = Math.max(pos.extreme, c.high);
                    pos.stop = Math.max(pos.stop, pos.extreme - pos.stopDist);
                } else {
                    pos.extreme = Math.min(pos.extreme, c.low);
                    pos.stop = Math.min(pos.stop, pos.extreme + pos.stopDist);
                }
            }
        }

        lastBlock = "";
        if (pos == null && d.entry != null) {
            boolean lng = "BUY".equals(d.entry);
            if (!lng && longOnly) { lastBlock = "long-only"; return d; }
            String block = risk.blockReason(sym, c.time, equity);
            if (block != null) { lastBlock = block; d.why = block; return d; }
            double stopDist = r.atr * p.stopAtr;
            if (stopDist <= 0 || equity <= 0) return d;
            double dir = lng ? 1 : -1;
            double entry = c.close * (1 + dir * p.slippage);
            double qty = Math.min(equity * p.riskPerTrade / stopDist, equity / Math.max(entry, 1e-9));
            double notional = 0;
            for (Pos q : positions.values()) notional += q.qty * q.entry;
            if (qty <= 0 || !Double.isFinite(qty) || entry * qty + notional > equity) { lastBlock = "no free capital"; d.why = lastBlock; return d; }
            Pos np = new Pos();
            np.lng = lng; np.entry = entry; np.qty = qty; np.stopDist = stopDist; np.openT = c.time;
            np.stop = entry - dir * stopDist;
            np.target = entry + dir * stopDist * p.rewardRisk;
            np.extreme = lng ? c.high : c.low;
            positions.put(sym, np);
            risk.onEntry(c.time, equity);
        }
        return d;
    }

    private void close(String sym, Pos pos, double rawExit, String why, long t) {
        double dir = pos.lng ? 1 : -1;
        double exit = rawExit * (1 - dir * p.slippage);
        double pnl = dir * (exit - pos.entry) * pos.qty - p.feePerSide * (pos.entry + exit) * pos.qty;
        equity += pnl;
        positions.remove(sym);
        Trade tr = new Trade();
        tr.sym = sym; tr.lng = pos.lng; tr.entryT = pos.openT; tr.exitT = t; tr.pnl = pnl; tr.exit = why;
        trades.add(tr);
        risk.onClose(sym, pnl, t, equity);
    }
}
