package com.neuraxon.app;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;

/**
 * Walk-forward backtest of the four strategies x three brain modes, with fees and slippage.
 * Settings are tuned ONLY on the first part of the history; results that count are from the last part.
 * The original brain is run once per pair (it learns candle by candle, like live) and its outputs are
 * reused for every setting, so only the strategy rules change between runs.
 */
final class Backtester {
    private Backtester() {}

    static final double TUNE_FRACTION = 0.60;
    static final int MIN_TRADES_TO_TUNE = 8;
    static final int MIN_TRADES_TO_TRUST = 30;

    static final class Series {
        String sym;
        List<NeuraxonEngine.Candle> candles;
        NeuraxonEngine.Result[] raw;   // original brain output with minConfidence 0
    }

    static final class Stats {
        int trades, wins;
        double net, grossWin, grossLoss, maxDd;   // net and maxDd in % of window-start equity
        double winRate() { return trades == 0 ? 0 : wins * 100.0 / trades; }
        double pf() { return grossLoss == 0 ? (grossWin > 0 ? Double.POSITIVE_INFINITY : 0) : grossWin / grossLoss; }
    }

    static final class Row {
        Strategy strategy;
        BrainMode mode;
        Params chosen;
        Stats tune, judge;
        boolean inSample;
    }

    static NeuraxonEngine.Result[] precompute(List<NeuraxonEngine.Candle> candles, int seed) {
        NeuraxonEngine eng = new NeuraxonEngine(seed);
        eng.minConfidence = 0.0;
        NeuraxonEngine.Result[] out = new NeuraxonEngine.Result[candles.size()];
        for (int i = 0; i < out.length; i++) out[i] = eng.onClosedCandle(candles.get(i));
        return out;
    }

    static NeuraxonEngine.Result withMin(NeuraxonEngine.Result raw, double min) {
        if (!"BUY".equals(raw.signal) && !"SELL".equals(raw.signal)) return raw;
        return raw.confidence < min ? new NeuraxonEngine.Result("HOLD", raw.confidence, raw.atr) : raw;
    }

    /** Keep only candles whose open time exists in every series, so pairs move in lockstep. */
    static List<Series> align(List<Series> in) {
        java.util.TreeSet<Long> common = null;
        for (Series s : in) {
            java.util.TreeSet<Long> t = new java.util.TreeSet<>();
            for (NeuraxonEngine.Candle c : s.candles) t.add(c.time);
            if (common == null) common = t; else common.retainAll(t);
        }
        List<Series> out = new ArrayList<>();
        for (Series s : in) {
            Series n = new Series();
            n.sym = s.sym;
            n.candles = new ArrayList<>();
            for (NeuraxonEngine.Candle c : s.candles) if (common.contains(c.time)) n.candles.add(c);
            n.raw = precompute(n.candles, (out.size() * 97) + 1337);
            out.add(n);
        }
        return out;
    }

    static PortfolioSim simulate(Strategy st, BrainMode mode, Params p, List<Series> data,
                                 Bpp9000Brain bpp, Map<String, Bpp9000Brain.Calibration> cals, boolean longOnly) {
        PortfolioSim sim = new PortfolioSim(st, mode, p, bpp, cals, 10000.0, longOnly);
        int n = data.get(0).candles.size();
        for (int i = 0; i < n; i++)
            for (Series s : data)
                sim.onCandle(s.sym, s.candles.get(i), withMin(s.raw[i], p.minConfidence));
        return sim;
    }

    static Stats window(PortfolioSim sim, long fromT, long toT) {
        double eq = sim.startEquity;
        for (PortfolioSim.Trade t : sim.trades) if (t.exitT < fromT) eq += t.pnl;
        double start = eq, peak = eq;
        Stats s = new Stats();
        for (PortfolioSim.Trade t : sim.trades) {
            if (t.exitT < fromT || t.exitT >= toT) continue;
            s.trades++;
            if (t.pnl > 0) { s.wins++; s.grossWin += t.pnl; } else s.grossLoss -= t.pnl;
            eq += t.pnl;
            peak = Math.max(peak, eq);
            s.maxDd = Math.max(s.maxDd, (peak - eq) / peak * 100.0);
        }
        s.net = (eq - start) / start * 100.0;
        return s;
    }

    static List<Params> grid(Strategy st, BrainMode mode, Params base) {
        List<Params> out = new ArrayList<>();
        double[] confs = mode == BrainMode.BPP9000 ? new double[]{base.minConfidence} : new double[]{0.05, 0.15, 0.25};
        for (double conf : confs) {
            switch (st) {
                case BRAIN_ONLY: {
                    Params p = base.copy(); p.minConfidence = conf; out.add(p);
                    break;
                }
                case TREND_BRAIN:
                    for (int f : new int[]{10, 20, 40}) {
                        Params p = base.copy(); p.minConfidence = conf; p.trendFast = f; out.add(p);
                    }
                    break;
                case BREAKOUT:
                    for (int n : new int[]{10, 20, 40}) for (double v : new double[]{1.0, 1.5}) {
                        Params p = base.copy(); p.minConfidence = conf; p.breakoutN = n; p.volMult = v; out.add(p);
                    }
                    break;
                default:
                    for (double[] r : new double[][]{{30, 70}, {25, 75}}) for (double er : new double[]{0.25, 0.35}) {
                        Params p = base.copy(); p.minConfidence = conf; p.rsiLow = r[0]; p.rsiHigh = r[1]; p.rangeER = er; out.add(p);
                    }
            }
        }
        return out;
    }

    static Row tuneAndJudge(Strategy st, BrainMode mode, Params base, List<Series> data,
                            Bpp9000Brain bpp, Map<String, Bpp9000Brain.Calibration> cals, long t0, long splitT, long tEnd) {
        Row row = new Row();
        row.strategy = st; row.mode = mode;
        double bestScore = -1e18;
        for (Params p : grid(st, mode, base)) {
            PortfolioSim sim = simulate(st, mode, p, data, bpp, cals, true);
            Stats tune = window(sim, t0, splitT);
            double score = tune.net - (tune.trades >= MIN_TRADES_TO_TUNE ? 0 : 1000);
            if (score > bestScore) {
                bestScore = score; row.chosen = p; row.tune = tune; row.judge = window(sim, splitT, tEnd);
            }
        }
        return row;
    }

    private static String date(long ms) {
        SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US);
        f.setTimeZone(TimeZone.getTimeZone("UTC"));
        return f.format(new Date(ms)) + " UTC";
    }

    private static String num(double v) {
        if (Double.isInfinite(v)) return "inf";
        return String.format(Locale.US, "%.2f", v);
    }

    private static String pct(double v) { return String.format(Locale.US, "%+.2f%%", v); }

    static List<Row> runAll(Params base, List<Series> data, Bpp9000Brain bpp, Map<String, Bpp9000Brain.Calibration> cals) {
        int n = data.get(0).candles.size();
        long t0 = data.get(0).candles.get(0).time;
        long splitT = data.get(0).candles.get((int) (n * TUNE_FRACTION)).time;
        long tEnd = data.get(0).candles.get(n - 1).time + 1;
        boolean bppAny = false;
        if (cals != null) for (Bpp9000Brain.Calibration c : cals.values()) if (c != null && c.verified) bppAny = true;
        long trainEnd = bpp == null ? 0 : bpp.startMs + bpp.hours * 3600000L;
        List<Row> rows = new ArrayList<>();
        for (BrainMode m : BrainMode.values()) {
            if (m != BrainMode.ORIGINAL && !bppAny) continue;
            for (Strategy s : Strategy.values()) {
                Row r = tuneAndJudge(s, m, base, data, bpp, cals, t0, splitT, tEnd);
                r.inSample = m != BrainMode.ORIGINAL && splitT < trainEnd;
                rows.add(r);
            }
        }
        return rows;
    }

    static String report(Params base, List<Series> data, Bpp9000Brain bpp, Map<String, Bpp9000Brain.Calibration> cals) {
        int n = data.get(0).candles.size();
        long t0 = data.get(0).candles.get(0).time;
        long splitT = data.get(0).candles.get((int) (n * TUNE_FRACTION)).time;
        long tEnd = data.get(0).candles.get(n - 1).time;
        StringBuilder o = new StringBuilder();
        o.append("WALK-FORWARD BACKTEST\n");
        o.append(n).append(" hourly candles per pair (about ").append(n / 24).append(" days), ").append(data.size()).append(" pairs, long-only like live trading.\n");
        o.append("Settings tuned only on ").append(date(t0)).append(" to ").append(date(splitT)).append(".\n");
        o.append("Judged only on ").append(date(splitT)).append(" to ").append(date(tEnd)).append(" (never seen by the tuning).\n");
        o.append("Costs: ").append(num(base.feePerSide * 100)).append("% fee + ").append(num(base.slippage * 100)).append("% slippage per side.\n\n");
        o.append("RULES, the same for all four strategies:\n");
        o.append("1 brain confirms ").append(base.confirmCandles).append(" candles in a row\n");
        o.append("2 long only above / short only below SMA ").append(base.trendLen).append("\n");
        o.append("3 max ").append(base.maxTradesPerDay).append(" trades per day\n");
        o.append("4 stop trading the day at -").append(num(base.dayLossPct)).append("%");
        if (base.dayProfitStopPct > 0) o.append(" or +").append(num(base.dayProfitStopPct)).append("%");
        o.append("\n5 stop ").append(num(base.stopAtr)).append("x ATR, reward:risk ").append(num(base.rewardRisk)).append(base.trailing ? ", trailing on" : ", no trailing").append("\n");
        o.append("6 skip ATR below ").append(num(base.quietAtrPct)).append("% of price, pause ").append(base.cooldownCandles).append(" candles after a loss\n\n");

        // buy and hold over the judge window
        double bh = 0;
        for (Series s : data) {
            double a = 0, b = s.candles.get(n - 1).close;
            for (NeuraxonEngine.Candle c : s.candles) if (c.time >= splitT) { a = c.close; break; }
            bh += (b / a - 1) * 100;
        }
        o.append("Buy & hold average on the judged part: ").append(pct(bh / data.size())).append("\n");

        // brain raw direction accuracy on the judged part
        int hit = 0, cnt = 0;
        for (Series s : data) for (int i = 0; i < n - 1; i++) {
            if (s.candles.get(i).time < splitT) continue;
            if (!"BUY".equals(s.raw[i].signal) && !"SELL".equals(s.raw[i].signal)) continue;
            boolean up = s.candles.get(i + 1).close >= s.candles.get(i).close;
            cnt++;
            if ("BUY".equals(s.raw[i].signal) == up) hit++;
        }
        o.append("Original brain next-hour direction accuracy there: ").append(cnt == 0 ? "n/a" : String.format(Locale.US, "%.1f%% over %d calls (about 50%% means no edge)", hit * 100.0 / cnt, cnt)).append("\n");
        if (cals != null && bpp != null) {
            o.append("\nBPP-9000 alignment check (does the file reproduce its own score on real candles?):\n");
            for (Series s : data) {
                Bpp9000Brain.Calibration c = cals.get(s.sym);
                if (c == null) continue;
                o.append(s.sym.replace("USDT", "")).append(": best ").append(String.format(Locale.US, "%.1f%%", c.hitPct))
                        .append(" over ").append(c.n).append(" hours (claimed ").append(num(bpp.claimedPct)).append("%), ")
                        .append(c.verified ? "VERIFIED" : "not verified").append("\n");
            }
        }
        o.append("\n");

        List<Row> rows = runAll(base, data, bpp, cals);
        BrainMode cur = null;
        Row bestValid = null;
        for (Row r : rows) {
            if (r.mode != cur) { cur = r.mode; o.append("== ").append(cur.label).append(" ==\n"); }
            o.append(r.strategy.label).append("\n  judged: ").append(r.judge.trades).append(" trades, win ")
                    .append(String.format(Locale.US, "%.0f%%", r.judge.winRate())).append(", net ").append(pct(r.judge.net))
                    .append(", PF ").append(num(r.judge.pf())).append(", max drawdown ").append(num(r.judge.maxDd)).append("%\n");
            o.append("  tuning part: ").append(r.tune.trades).append(" trades, net ").append(pct(r.tune.net)).append("\n");
            if (r.inSample) o.append("  IN-SAMPLE for BPP-9000: this period is inside its training window, so this row proves nothing.\n");
            else if (r.judge.trades < MIN_TRADES_TO_TRUST) o.append("  too few trades to conclude anything.\n");
            if (!r.inSample && r.judge.trades >= MIN_TRADES_TO_TRUST && (bestValid == null || r.judge.net > bestValid.judge.net)) bestValid = r;
        }
        o.append("\nSUMMARY\n");
        if (bestValid == null) o.append("No row has enough trades (").append(MIN_TRADES_TO_TRUST).append("+) on valid data to judge. Treat every strategy as unproven.\n");
        else if (bestValid.judge.net <= 0) o.append("Best valid row (").append(bestValid.mode.label).append(", ").append(bestValid.strategy.label).append(") still lost ").append(pct(bestValid.judge.net)).append(" after costs. Do not trade real money with this.\n");
        else o.append("Best valid row: ").append(bestValid.mode.label).append(", ").append(bestValid.strategy.label).append(", ").append(pct(bestValid.judge.net)).append(" on the judged part. One window can be luck; keep it on paper and re-run on new data.\n");
        o.append("Do not just pick the best row: with 12 rows, one will look good by chance.\n");
        o.append("Totals use equity-based sizing (1% risk per trade). Past results do not predict future results.");
        return o.toString();
    }
}
