package com.neuraxon.app;

/** All tunable numbers in one place. Rules 1-6 values are shared by every strategy. */
final class Params {
    // Rule 1: brain must repeat the same call this many closed candles in a row
    int confirmCandles = 2;
    // Rule 2: trend filter, long only above / short only below this SMA
    int trendLen = 100;
    // Rule 3: max new trades per UTC day (whole portfolio)
    int maxTradesPerDay = 3;
    // Rule 4: no new trades after losing this % of day-start equity; optional profit stop (0 = off)
    double dayLossPct = 3.0;
    double dayProfitStopPct = 0.0;
    // Rule 5: stop on every trade (ATR multiple), reward:risk target, optional trailing stop
    double stopAtr = 1.5;
    double rewardRisk = 2.0;
    boolean trailing = false;
    // Rule 6: skip dead markets (ATR below this % of price) and pause after a loss (candles)
    double quietAtrPct = 0.20;
    int cooldownCandles = 3;

    // Original brain confidence threshold
    double minConfidence = 0.25;

    // Strategy 2
    int trendFast = 20;
    // Strategy 3
    int breakoutN = 20;
    double volMult = 1.0;
    int volLen = 20;
    // Strategy 4
    int rsiLen = 14;
    double rsiLow = 30, rsiHigh = 70;
    int erLen = 30;
    double rangeER = 0.30;

    // Costs and sizing
    double feePerSide = 0.001;
    double slippage = 0.0002;
    double riskPerTrade = 0.01;

    Params copy() {
        Params p = new Params();
        p.confirmCandles = confirmCandles; p.trendLen = trendLen; p.maxTradesPerDay = maxTradesPerDay;
        p.dayLossPct = dayLossPct; p.dayProfitStopPct = dayProfitStopPct; p.stopAtr = stopAtr;
        p.rewardRisk = rewardRisk; p.trailing = trailing; p.quietAtrPct = quietAtrPct;
        p.cooldownCandles = cooldownCandles; p.minConfidence = minConfidence; p.trendFast = trendFast;
        p.breakoutN = breakoutN; p.volMult = volMult; p.volLen = volLen; p.rsiLen = rsiLen;
        p.rsiLow = rsiLow; p.rsiHigh = rsiHigh; p.erLen = erLen; p.rangeER = rangeER;
        p.feePerSide = feePerSide; p.slippage = slippage; p.riskPerTrade = riskPerTrade;
        return p;
    }
}
