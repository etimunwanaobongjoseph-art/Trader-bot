package com.neuraxon.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import com.neuraxon.app.BinanceTrader;
import com.neuraxon.app.NeuraxonEngine;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.json.JSONArray;

/* loaded from: classes2.dex */
public class MainActivity extends Activity {
    private static final String[] DATA_HOSTS = {"https://data-api.binance.vision", "https://api.binance.com", "https://api1.binance.com", "https://api2.binance.com", "https://api3.binance.com", "https://api4.binance.com", "https://api-gcp.binance.com"};
    private static final long MAX_CANDLE_AGE_MS = 900000;
    private static final int MAX_OPEN_LIVE = 3;
    private static final String TESTNET_DATA_HOST = "https://testnet.binance.vision";
    private TextView activityText;
    private TextView botStatus;
    private TextView connectionText;
    private TextView equityText;
    private TextView liveText;
    private TextView marketText;
    private TextView modeChip;
    private TextView pnlText;
    private TextView positionText;
    private TextView signalText;
    private volatile BinanceTrader trader;
    private final int BG = Color.rgb(8, 17, 31);
    private final int PANEL = Color.rgb(17, 29, 47);
    private final int MUTED = Color.rgb(150, 166, 188);
    private final int WHITE = -1;
    private final int GREEN = Color.rgb(32, 201, 151);
    private final int RED = Color.rgb(255, 99, 110);
    private final int BLUE = Color.rgb(72, 135, 220);
    private final String[] symbols = {"BTCUSDT", "ETHUSDT", "BNBUSDT", "SOLUSDT", "XRPUSDT"};
    private final Map<String, NeuraxonEngine> engines = new ConcurrentHashMap();
    private final Map<String, Long> lastProcessed = new ConcurrentHashMap();
    private final Map<String, String> signals = new ConcurrentHashMap();
    private final Map<String, Double> prices = new ConcurrentHashMap();
    private final Map<String, Integer> candleCounts = new ConcurrentHashMap();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private volatile boolean running = false;
    private volatile boolean fetching = false;
    private String mode = "PAPER";
    private volatile int processed = 0;
    private long lastUpdate = 0;
    private final Map<String, LivePos> livePositions = new ConcurrentHashMap();
    private volatile boolean liveArmed = false;
    private volatile boolean liveHalted = false;
    private volatile boolean liveReal = false;
    private volatile double liveRealized = 0.0d;
    private volatile String liveLastEvent = "none yet";
    private volatile String apiKey = "";
    private volatile String apiSecret = "";
    private volatile double maxTradeUsdt = 15.0d;
    private volatile double lossHaltUsdt = 5.0d;
    private volatile double stopAtr = 1.5d;
    private volatile double rewardRisk = 2.0d;
    private volatile double minConfidence = 0.25d;
    private volatile Strategy strategy = Strategy.TREND_BRAIN;
    private volatile BrainMode brainMode = BrainMode.BOTH;
    private final Params rp = new Params();
    private volatile Bpp9000Brain bpp;
    private final Map<String, Bpp9000Brain.Calibration> bppCal = new ConcurrentHashMap<>();
    private volatile String bppStatus = "BPP-9000: not checked yet";
    private volatile boolean bppChecked = false;
    private volatile int bppOosHits = 0;
    private volatile int bppOosN = 0;
    private volatile PortfolioSim paperSim;
    private volatile RiskState liveRisk;
    private final Map<String, List<Seen>> seen = new ConcurrentHashMap<>();
    private final Map<String, String> whyNot = new ConcurrentHashMap<>();
    private final Map<String, Double> confidences = new ConcurrentHashMap();
    private final DecimalFormat priceFmt = new DecimalFormat("#,##0.00");
    private final Runnable poller = new Runnable() { // from class: com.neuraxon.app.MainActivity.1
        @Override // java.lang.Runnable
        public void run() {
            if (MainActivity.this.running) {
                MainActivity.this.fetchMarkets();
            }
            MainActivity.this.handler.postDelayed(this, 60000L);
        }
    };
    private volatile int hostIdx = 0;
    private volatile boolean mainnetOk = false;
    private volatile String dataSource = "none yet";

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes2.dex */
    public static final class LivePos {
        final double cost;
        final double entry;
        final long listId;
        final List<Long> orderIds;
        final BigDecimal qty;
        final double stop;
        final String symbol;
        final double target;

        LivePos(String sy, BigDecimal q, double c, double e, double s, double t, long id, List<Long> ids) {
            this.symbol = sy;
            this.qty = q;
            this.cost = c;
            this.entry = e;
            this.stop = s;
            this.target = t;
            this.listId = id;
            this.orderIds = ids;
        }
    }

    @Override // android.app.Activity
    public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(this.BG);
        getWindow().setNavigationBarColor(this.BG);
        for (int i = 0; i < this.symbols.length; i++) {
            this.engines.put(this.symbols[i], new NeuraxonEngine((i * 97) + 1337));
            this.signals.put(this.symbols[i], "WAITING");
            this.candleCounts.put(this.symbols[i], 0);
        }
        loadPrefs();
        for (NeuraxonEngine en : this.engines.values()) {
            en.minConfidence = 0.0d;
        }
        buildUi();
    }

    private GradientDrawable shape(int c, int r) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(c);
        d.setCornerRadius(r);
        return d;
    }

    private TextView text(String s, int z, int c, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(z);
        t.setTextColor(c);
        if (bold) {
            t.setTypeface(Typeface.DEFAULT, 1);
        }
        return t;
    }

    private LinearLayout col() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(1);
        return l;
    }

    private LinearLayout row() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(0);
        l.setGravity(16);
        return l;
    }

    private void gap(LinearLayout l, int h) {
        l.addView(new View(this), lp(1, h));
    }

    private LinearLayout.LayoutParams lp(int w, int h) {
        return new LinearLayout.LayoutParams(w, h);
    }

    private TextView button(String s, int c) {
        TextView t = text(s, 14, -1, true);
        t.setGravity(17);
        t.setPadding(12, 15, 12, 15);
        t.setBackground(shape(c, 18));
        return t;
    }

    private LinearLayout card() {
        LinearLayout c = col();
        c.setPadding(16, 15, 16, 15);
        c.setBackground(shape(this.PANEL, 20));
        return c;
    }

    private void buildUi() {
        ScrollView scrollView = new ScrollView(this);
        scrollView.setFillViewport(true);
        LinearLayout col = col();
        col.setPadding(18, 18, 18, 24);
        col.setBackgroundColor(this.BG);
        scrollView.addView(col);
        setContentView(scrollView);
        LinearLayout h = row();
        LinearLayout brand = col();
        brand.addView(text("NEURAXON", 22, -1, true));
        brand.addView(text("MULTI-MARKET MINI TRADING SYSTEM", 10, this.MUTED, true));
        h.addView(brand, new LinearLayout.LayoutParams(0, -2, 1.0f));
        TextView m = text("PAPER MODE  ▾", 12, this.GREEN, true);
        this.modeChip = m;
        m.setPadding(13, 10, 13, 10);
        m.setBackground(shape(Color.rgb(15, 55, 52), 30));
        m.setOnClickListener(new View.OnClickListener() { // from class: com.neuraxon.app.MainActivity$$ExternalSyntheticLambda15
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                MainActivity.this.m5lambda$buildUi$0$comneuraxonappMainActivity(view);
            }
        });
        h.addView(m);
        col.addView(h);
        gap(col, 18);
        this.connectionText = text("●  MARKET DATA: DISCONNECTED", 12, this.RED, true);
        col.addView(this.connectionText);
        gap(col, 12);
        LinearLayout eq = card();
        eq.addView(text("PAPER ACCOUNT EQUITY", 11, this.MUTED, true));
        gap(eq, 7);
        this.equityText = text("$10,000.00", 29, -1, true);
        eq.addView(this.equityText);
        eq.addView(text("Simulated balance · no real funds", 11, this.MUTED, false));
        col.addView(eq);
        gap(col, 10);
        LinearLayout s = row();
        this.botStatus = metric("STOPPED", this.RED);
        this.signalText = metric("WAITING", -1);
        s.addView(metricCard("BOT STATUS", this.botStatus), new LinearLayout.LayoutParams(0, -2, 1.0f));
        s.addView(new View(this), lp(10, 1));
        s.addView(metricCard("LATEST SIGNAL", this.signalText), new LinearLayout.LayoutParams(0, -2, 1.0f));
        col.addView(s);
        gap(col, 10);
        LinearLayout s2 = row();
        this.positionText = metric("0 open", -1);
        this.pnlText = metric("$0.00", -1);
        s2.addView(metricCard("OPEN POSITIONS", this.positionText), new LinearLayout.LayoutParams(0, -2, 1.0f));
        s2.addView(new View(this), lp(10, 1));
        s2.addView(metricCard("TODAY'S REALIZED P/L", this.pnlText), new LinearLayout.LayoutParams(0, -2, 1.0f));
        col.addView(s2);
        gap(col, 20);
        col.addView(text("LIVE TRADING", 12, this.MUTED, true));
        gap(col, 9);
        LinearLayout lc = card();
        this.liveText = text("", 12, -1, false);
        lc.addView(this.liveText);
        col.addView(lc);
        gap(col, 20);
        refreshLiveViews();
        col.addView(text("MAIN OPERATIONS", 12, this.MUTED, true));
        gap(col, 9);
        LinearLayout ops = row();
        TextView start = button("▶  START BOT", Color.rgb(15, 125, 92));
        TextView stop = button("■  STOP BOT", Color.rgb(150, 49, 61));
        ops.addView(start, new LinearLayout.LayoutParams(0, -2, 1.0f));
        ops.addView(new View(this), lp(10, 1));
        ops.addView(stop, new LinearLayout.LayoutParams(0, -2, 1.0f));
        col.addView(ops);
        gap(col, 10);
        TextView settings = button("⚙  SETTINGS", Color.rgb(47, 62, 82));
        col.addView(settings);
        gap(col, 10);
        TextView bt = button("📊  BACKTEST ON RECENT HISTORY", Color.rgb(47, 62, 82));
        col.addView(bt);
        bt.setOnClickListener(new View.OnClickListener() { // from class: com.neuraxon.app.MainActivity$$ExternalSyntheticLambda16
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                MainActivity.this.m6lambda$buildUi$1$comneuraxonappMainActivity(view);
            }
        });
        gap(col, 10);
        TextView flat = button("⛔  FLATTEN LIVE POSITIONS", Color.rgb(120, 40, 50));
        col.addView(flat);
        flat.setOnClickListener(new View.OnClickListener() { // from class: com.neuraxon.app.MainActivity$$ExternalSyntheticLambda17
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                MainActivity.this.m7lambda$buildUi$2$comneuraxonappMainActivity(view);
            }
        });
        start.setOnClickListener(new View.OnClickListener() { // from class: com.neuraxon.app.MainActivity$$ExternalSyntheticLambda18
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                MainActivity.this.m8lambda$buildUi$3$comneuraxonappMainActivity(view);
            }
        });
        stop.setOnClickListener(new View.OnClickListener() { // from class: com.neuraxon.app.MainActivity$$ExternalSyntheticLambda19
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                MainActivity.this.m9lambda$buildUi$4$comneuraxonappMainActivity(view);
            }
        });
        settings.setOnClickListener(new View.OnClickListener() { // from class: com.neuraxon.app.MainActivity$$ExternalSyntheticLambda20
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                MainActivity.this.m10lambda$buildUi$5$comneuraxonappMainActivity(view);
            }
        });
        gap(col, 20);
        col.addView(text("LIVE MARKET WATCH · 1H CANDLES", 12, this.MUTED, true));
        gap(col, 9);
        LinearLayout markets = card();
        this.marketText = text("Waiting for Binance public market data…", 12, -1, false);
        markets.addView(this.marketText);
        col.addView(markets);
        gap(col, 18);
        col.addView(text("ENGINE ACTIVITY", 12, this.MUTED, true));
        gap(col, 9);
        LinearLayout log = card();
        this.activityText = text("Start the bot to download recent 1-hour candles for BTC, ETH, BNB, SOL and XRP. The engine processes only fully closed candles and simulates paper trades locally.", 12, this.MUTED, false);
        log.addView(this.activityText);
        col.addView(log);
        gap(col, 16);
        TextView warning = text("PAPER TRADING ONLY  •  LIVE ORDERS DISABLED", 10, this.RED, true);
        warning.setGravity(17);
        col.addView(warning);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: lambda$buildUi$0$com-neuraxon-app-MainActivity, reason: not valid java name */
    public /* synthetic */ void m5lambda$buildUi$0$comneuraxonappMainActivity(View v) {
        chooseMode();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: lambda$buildUi$1$com-neuraxon-app-MainActivity, reason: not valid java name */
    public /* synthetic */ void m6lambda$buildUi$1$comneuraxonappMainActivity(View v) {
        runBacktest();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: lambda$buildUi$2$com-neuraxon-app-MainActivity, reason: not valid java name */
    public /* synthetic */ void m7lambda$buildUi$2$comneuraxonappMainActivity(View v) {
        confirmFlatten();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: lambda$buildUi$3$com-neuraxon-app-MainActivity, reason: not valid java name */
    public /* synthetic */ void m8lambda$buildUi$3$comneuraxonappMainActivity(View v) {
        startBot();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: lambda$buildUi$4$com-neuraxon-app-MainActivity, reason: not valid java name */
    public /* synthetic */ void m9lambda$buildUi$4$comneuraxonappMainActivity(View v) {
        stopBot();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: lambda$buildUi$5$com-neuraxon-app-MainActivity, reason: not valid java name */
    public /* synthetic */ void m10lambda$buildUi$5$comneuraxonappMainActivity(View v) {
        showSettings();
    }

    private TextView metric(String s, int c) {
        return text(s, 17, c, true);
    }

    private LinearLayout metricCard(String title, TextView v) {
        LinearLayout c = card();
        c.addView(text(title, 10, this.MUTED, true));
        gap(c, 8);
        c.addView(v);
        return c;
    }

    private void startBot() {
        if (this.running) {
            return;
        }
        this.running = true;
        this.botStatus.setText("CONNECTING");
        this.botStatus.setTextColor(this.BLUE);
        this.activityText.setText("Connecting to Binance public market data. Downloading 1-hour history for five markets…");
        fetchMarkets();
        this.handler.removeCallbacks(this.poller);
        this.handler.postDelayed(this.poller, 60000L);
    }

    private void stopBot() {
        this.running = false;
        this.handler.removeCallbacks(this.poller);
        this.botStatus.setText("STOPPED");
        this.botStatus.setTextColor(this.RED);
        this.connectionText.setText("●  MARKET DATA: PAUSED");
        this.connectionText.setTextColor(this.MUTED);
        this.activityText.setText("Bot stopped. No further market candles will be processed.");
        Toast.makeText(this, "Neuraxon stopped.", 0).show();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void fetchMarkets() {
        if (this.fetching) {
            return;
        }
        this.fetching = true;
        this.io.execute(new Runnable() { // from class: com.neuraxon.app.MainActivity$$ExternalSyntheticLambda1
            @Override // java.lang.Runnable
            public final void run() {
                MainActivity.this.fetchMarketsWork();
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: lambda$fetchMarkets$6$com-neuraxon-app-MainActivity, reason: not valid java name */
    public /* synthetic */ void m14lambda$fetchMarkets$6$comneuraxonappMainActivity(boolean ok, String rendered, String err) {
        this.fetching = false;
        refreshLiveViews();
        if (!ok) {
            this.connectionText.setText("●  MARKET DATA: CONNECTION FAILED");
            this.connectionText.setTextColor(this.RED);
            this.botStatus.setText("NO DATA");
            this.botStatus.setTextColor(this.RED);
            this.activityText.setText("Could not reach Binance public market-data endpoint. Check internet access and try again.\n" + err);
            this.marketText.setText(rendered);
            return;
        }
        this.lastUpdate = System.currentTimeMillis();
        this.connectionText.setText("●  BINANCE PUBLIC DATA: CONNECTED");
        this.connectionText.setTextColor(this.GREEN);
        this.botStatus.setText(this.running ? "RUNNING" : "STOPPED");
        this.botStatus.setTextColor(this.running ? this.GREEN : this.RED);
        this.marketText.setText(rendered);
        this.signalText.setText(overallSignal());
        this.signalText.setTextColor(signalColor(overallSignal()));
        this.equityText.setText("$" + this.priceFmt.format(paperEquityNow()));
        this.pnlText.setText((paperPnlNow() >= 0.0d ? "+$" : "-$") + this.priceFmt.format(Math.abs(paperPnlNow())));
        this.positionText.setText(paperOpenCount() + " open");
        this.activityText.setText("Connected (source: " + this.dataSource + "). Five USDT pairs · 1-hour candles · closed candles only.\n\n" + describeSetup() + "\nThe bot only acts when an hourly candle CLOSES (next close in about " + (60 - ((System.currentTimeMillis() / 60000) % 60)) + " min) and every rule passes. Until then it just watches; that is normal.\n\nLast refresh: " + new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date()) + "\nClosed candles processed this session: " + this.processed + "\nPaper trades are simulated locally with 0.10% fee and 0.02% slippage per side, long only. Real orders are only sent when a live mode is armed.");
    }

    private int engineCount(String s) {
        if (this.candleCounts.containsKey(s)) {
            return this.candleCounts.get(s).intValue();
        }
        return 0;
    }

    private String join(Map<String, String> m) {
        StringBuilder b = new StringBuilder();
        for (String s : this.symbols) {
            if (b.length() > 0) {
                b.append("\n\n");
            }
            b.append(m.containsKey(s) ? m.get(s) : s + "   waiting");
        }
        return b.toString();
    }

    private String overallSignal() {
        StringBuilder append;
        int buy = 0;
        int sell = 0;
        for (String s : this.symbols) {
            String v = this.signals.get(s);
            if ("BUY".equals(v)) {
                buy++;
            }
            if ("SELL".equals(v)) {
                sell++;
            }
        }
        if (buy > sell && buy > 0) {
            append = new StringBuilder().append("BUY ").append(buy);
        } else {
            if (sell <= buy || sell <= 0) {
                return "HOLD";
            }
            append = new StringBuilder().append("SELL ").append(sell);
        }
        return append.append("/5").toString();
    }

    private int signalColor(String s) {
        if (s.startsWith("BUY")) {
            return this.GREEN;
        }
        if (s.startsWith("SELL")) {
            return this.RED;
        }
        return -1;
    }

    private void chooseMode() {
        new AlertDialog.Builder(this).setTitle("Trading mode").setItems(new String[]{"Paper trading (simulated)", "Live: Binance Testnet (fake funds)", "Live: REAL MONEY"}, new DialogInterface.OnClickListener() { // from class: com.neuraxon.app.MainActivity$$ExternalSyntheticLambda14
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i) {
                MainActivity.this.m11lambda$chooseMode$8$comneuraxonappMainActivity(dialogInterface, i);
            }
        }).show();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: lambda$chooseMode$8$com-neuraxon-app-MainActivity, reason: not valid java name */
    public /* synthetic */ void m11lambda$chooseMode$8$comneuraxonappMainActivity(DialogInterface d, int w) {
        if (!this.livePositions.isEmpty()) {
            Toast.makeText(this, "Close live positions first (use FLATTEN) before changing mode.", 1).show();
            return;
        }
        if (w == 0) {
            this.liveArmed = false;
            this.liveReal = false;
            this.trader = null;
            liveLog("Live trading off. Paper mode.");
            return;
        }
        if (this.apiKey.isEmpty() || this.apiSecret.isEmpty()) {
            Toast.makeText(this, "Add your API key and secret in Settings first.", 1).show();
        } else {
            armLive(w == 2);
        }
    }

    private void armLive(final boolean real) {
        final String k = this.apiKey;
        final String sec = this.apiSecret;
        final double cap = this.maxTradeUsdt;
        this.io.execute(new Runnable() { // from class: com.neuraxon.app.MainActivity$$ExternalSyntheticLambda4
            @Override // java.lang.Runnable
            public final void run() {
                MainActivity.this.m3lambda$armLive$12$comneuraxonappMainActivity(real, k, sec, cap);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: lambda$armLive$12$com-neuraxon-app-MainActivity, reason: not valid java name */
    public /* synthetic */ void m3lambda$armLive$12$comneuraxonappMainActivity(final boolean real, String k, String sec, double cap) {
        try {
            final BinanceTrader t = new BinanceTrader(real ? "https://api.binance.com" : TESTNET_DATA_HOST, k, sec);
            t.syncTime();
            final String info = t.verify("BTCUSDT", cap);
            for (String s : this.symbols) {
                t.rules(s);
            }
            runOnUiThread(new Runnable() { // from class: com.neuraxon.app.MainActivity$$ExternalSyntheticLambda11
                @Override // java.lang.Runnable
                public final void run() {
                    MainActivity.this.m1lambda$armLive$10$comneuraxonappMainActivity(real, t, info);
                }
            });
        } catch (Exception e) {
            final String m = e.getMessage();
            liveLog("Could not arm live trading: " + m);
            runOnUiThread(new Runnable() { // from class: com.neuraxon.app.MainActivity$$ExternalSyntheticLambda13
                @Override // java.lang.Runnable
                public final void run() {
                    MainActivity.this.m2lambda$armLive$11$comneuraxonappMainActivity(m);
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: lambda$armLive$10$com-neuraxon-app-MainActivity, reason: not valid java name */
    public /* synthetic */ void m1lambda$armLive$10$comneuraxonappMainActivity(boolean real, final BinanceTrader t, final String info) {
        if (!real) {
            commitArm(t, false);
            liveLog("Testnet armed. " + info);
        } else {
            final EditText box = new EditText(this);
            box.setHint("Type LIVE to confirm");
            box.setSingleLine(true);
            new AlertDialog.Builder(this).setTitle("Enable REAL-MONEY trading?").setMessage(info + "\n\nThe bot will place real market orders on Binance Spot: up to $" + this.priceFmt.format(this.maxTradeUsdt) + " per trade, at most " + MAX_OPEN_LIVE + " open positions, each with an exchange-side stop and target. New entries halt after a session loss of $" + this.priceFmt.format(this.lossHaltUsdt) + ".\n\nThis strategy is experimental with no proven edge. You can lose this money. Type LIVE to continue.").setView(box).setNegativeButton("Cancel", (DialogInterface.OnClickListener) null).setPositiveButton("Enable", new DialogInterface.OnClickListener() { // from class: com.neuraxon.app.MainActivity$$ExternalSyntheticLambda2
                @Override // android.content.DialogInterface.OnClickListener
                public final void onClick(DialogInterface dialogInterface, int i) {
                    MainActivity.this.m4lambda$armLive$9$comneuraxonappMainActivity(box, t, info, dialogInterface, i);
                }
            }).show();
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: lambda$armLive$9$com-neuraxon-app-MainActivity, reason: not valid java name */
    public /* synthetic */ void m4lambda$armLive$9$comneuraxonappMainActivity(EditText box, BinanceTrader t, String info, DialogInterface d, int w) {
        if (!"LIVE".equals(box.getText().toString().trim())) {
            Toast.makeText(this, "Not confirmed. Live trading stays off.", 1).show();
        } else {
            commitArm(t, true);
            liveLog("REAL-MONEY trading armed. " + info);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: lambda$armLive$11$com-neuraxon-app-MainActivity, reason: not valid java name */
    public /* synthetic */ void m2lambda$armLive$11$comneuraxonappMainActivity(String m) {
        Toast.makeText(this, "Could not arm live trading: " + m, 1).show();
    }

    private void commitArm(BinanceTrader t, boolean real) {
        this.trader = t;
        this.liveReal = real;
        this.liveRealized = 0.0d;
        this.liveHalted = false;
        this.liveArmed = true;
        refreshLiveViews();
    }

    private void liveLog(String s) {
        this.liveLastEvent = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date()) + "  " + s;
        runOnUiThread(new Runnable() { // from class: com.neuraxon.app.MainActivity$$ExternalSyntheticLambda12
            @Override // java.lang.Runnable
            public final void run() {
                MainActivity.this.refreshLiveViews();
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void refreshLiveViews() {
        this.modeChip.setText(!this.liveArmed ? "PAPER MODE  ▾" : this.liveReal ? "LIVE · REAL MONEY  ▾" : "LIVE · TESTNET  ▾");
        this.modeChip.setTextColor(!this.liveArmed ? this.GREEN : this.liveReal ? this.RED : this.BLUE);
        if (!this.liveArmed) {
            this.liveText.setText("Not armed. Add API keys in Settings, then pick a live mode (top right).\nLast event: " + this.liveLastEvent);
            this.liveText.setTextColor(this.MUTED);
            return;
        }
        StringBuilder b = new StringBuilder();
        b.append(this.liveReal ? "REAL MONEY" : "TESTNET (fake funds)").append(this.liveHalted ? "  ·  HALTED (no new entries)" : "  ·  ARMED").append('\n');
        b.append("Open: ").append(this.livePositions.size()).append("/").append(MAX_OPEN_LIVE).append("   Session realized: ").append(this.liveRealized >= 0.0d ? "+$" : "-$").append(this.priceFmt.format(Math.abs(this.liveRealized))).append('\n');
        b.append("Max/trade $").append(this.priceFmt.format(this.maxTradeUsdt)).append("   Loss halt $").append(this.priceFmt.format(this.lossHaltUsdt)).append('\n');
        for (LivePos p : this.livePositions.values()) {
            b.append(p.symbol).append("  ").append(p.qty.toPlainString()).append(" @ ").append(this.priceFmt.format(p.entry)).append("   SL ").append(this.priceFmt.format(p.stop)).append("   TP ").append(this.priceFmt.format(p.target)).append('\n');
        }
        b.append("Last: ").append(this.liveLastEvent);
        this.liveText.setText(b.toString());
        this.liveText.setTextColor(this.liveHalted ? this.RED : -1);
    }

    private void closeLive(BinanceTrader t, LivePos p, String why) throws Exception {
        try {
            t.cancelOco(p.symbol, p.listId);
            try {
                BinanceTrader.Fill out = t.marketSell(p.symbol, p.qty);
                double pnl = (out.quote - out.feeQuote) - p.cost;
                this.liveRealized += pnl;
                if (this.liveRisk != null) {
                    this.liveRisk.onClose(p.symbol, pnl, System.currentTimeMillis(), 0.0d);
                }
                this.livePositions.remove(p.symbol);
                liveLog(p.symbol + ": closed (" + why + ") P/L " + (pnl >= 0.0d ? "+$" : "-$") + this.priceFmt.format(Math.abs(pnl)));
                checkHalt();
            } catch (Exception e) {
                this.liveHalted = true;
                liveLog("!! " + p.symbol + ": stop/target cancelled but the market sell failed (" + e.getMessage() + "). POSITION IS UNPROTECTED. Close it on Binance.");
            }
        } catch (BinanceTrader.ApiException e2) {
            if (!"ALL_DONE".equals(t.ocoStatus(p.symbol, p.listId))) {
                throw e2;
            }
            settleFinished(t, p);
        }
    }

    private void settleFinished(BinanceTrader t, LivePos p) throws Exception {
        double[] r = t.sellProceeds(p.symbol, p.orderIds);
        this.livePositions.remove(p.symbol);
        if (r[1] == 0.0d) {
            this.liveHalted = true;
            liveLog(p.symbol + ": exit orders ended with no fills (cancelled outside the app?). The position may still be held. Halted. Check Binance.");
        } else {
            double pnl = r[0] - p.cost;
            this.liveRealized += pnl;
                if (this.liveRisk != null) {
                    this.liveRisk.onClose(p.symbol, pnl, System.currentTimeMillis(), 0.0d);
                }
            liveLog(p.symbol + ": exchange closed the position (stop/target) P/L " + (pnl >= 0.0d ? "+$" : "-$") + this.priceFmt.format(Math.abs(pnl)));
            checkHalt();
        }
    }

    private void reconcileLive() {
        BinanceTrader t = this.trader;
        if (!this.liveArmed || t == null) {
            return;
        }
        Iterator it = new ArrayList(this.livePositions.values()).iterator();
        while (it.hasNext()) {
            LivePos p = (LivePos) it.next();
            try {
                if ("ALL_DONE".equals(t.ocoStatus(p.symbol, p.listId))) {
                    settleFinished(t, p);
                }
            } catch (Exception e) {
                liveLog(p.symbol + ": status check failed: " + e.getMessage());
            }
        }
    }

    private void checkHalt() {
        if (this.liveHalted || this.liveRealized > (-this.lossHaltUsdt)) {
            return;
        }
        this.liveHalted = true;
        liveLog("Session loss limit reached. New live entries halted.");
    }

    private void confirmFlatten() {
        if (!this.liveArmed || this.trader == null) {
            Toast.makeText(this, "Live trading is not armed.", 0).show();
        } else {
            new AlertDialog.Builder(this).setTitle("Flatten live positions?").setMessage("Cancels every stop/target and sells all positions this app opened, at market. New live entries stay halted until you re-arm.").setNegativeButton("Cancel", (DialogInterface.OnClickListener) null).setPositiveButton("Flatten", new DialogInterface.OnClickListener() { // from class: com.neuraxon.app.MainActivity$$ExternalSyntheticLambda7
                @Override // android.content.DialogInterface.OnClickListener
                public final void onClick(DialogInterface dialogInterface, int i) {
                    MainActivity.this.m13lambda$confirmFlatten$14$comneuraxonappMainActivity(dialogInterface, i);
                }
            }).show();
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: lambda$confirmFlatten$14$com-neuraxon-app-MainActivity, reason: not valid java name */
    public /* synthetic */ void m13lambda$confirmFlatten$14$comneuraxonappMainActivity(DialogInterface d, int w) {
        this.io.execute(new Runnable() { // from class: com.neuraxon.app.MainActivity$$ExternalSyntheticLambda9
            @Override // java.lang.Runnable
            public final void run() {
                MainActivity.this.m12lambda$confirmFlatten$13$comneuraxonappMainActivity();
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: lambda$confirmFlatten$13$com-neuraxon-app-MainActivity, reason: not valid java name */
    public /* synthetic */ void m12lambda$confirmFlatten$13$comneuraxonappMainActivity() {
        this.liveHalted = true;
        BinanceTrader t = this.trader;
        if (t == null) {
            return;
        }
        Iterator it = new ArrayList(this.livePositions.values()).iterator();
        while (it.hasNext()) {
            LivePos p = (LivePos) it.next();
            try {
                closeLive(t, p, "flatten");
            } catch (Exception e) {
                liveLog(p.symbol + ": flatten failed: " + e.getMessage());
            }
        }
        liveLog("Flatten finished. New entries halted.");
    }

    private double clamp(double v, double lo, double hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    private double parsePositive(String s, double fallback) {
        try {
            double v = Double.parseDouble(s.trim());
            if (v > 0.0d && !Double.isNaN(v)) {
                if (!Double.isInfinite(v)) {
                    return v;
                }
            }
            return fallback;
        } catch (Exception e) {
            return fallback;
        }
    }

    private String trimNum(double v) {
        return v == Math.floor(v) ? String.valueOf((long) v) : String.valueOf(v);
    }

    private String pct(double v) {
        return String.format(Locale.US, "%+.1f%%", Double.valueOf(v));
    }

    private double pd(SharedPreferences sp, String k, double d) {
        try {
            return Double.parseDouble(sp.getString(k, String.valueOf(d)));
        } catch (Exception e) {
            return d;
        }
    }

    private void loadPrefs() {
        SharedPreferences sp = getSharedPreferences("neuraxon", 0);
        this.maxTradeUsdt = clamp(pd(sp, "maxTrade", 15.0d), 1.0d, 1000000.0d);
        this.lossHaltUsdt = clamp(pd(sp, "lossHalt", 5.0d), 0.1d, 1000000.0d);
        this.stopAtr = clamp(pd(sp, "stopAtr", 1.5d), 0.5d, 5.0d);
        this.rewardRisk = clamp(pd(sp, "rewardRisk", 2.0d), 0.5d, 5.0d);
        this.minConfidence = clamp(pd(sp, "minConf", 0.25d), 0.05d, 0.9d);
        loadRules(sp);
    }

    private void savePrefs() {
        SharedPreferences.Editor ed = getSharedPreferences("neuraxon", 0).edit().putString("maxTrade", String.valueOf(this.maxTradeUsdt)).putString("lossHalt", String.valueOf(this.lossHaltUsdt)).putString("stopAtr", String.valueOf(this.stopAtr)).putString("rewardRisk", String.valueOf(this.rewardRisk)).putString("minConf", String.valueOf(this.minConfidence));
        saveRules(ed);
        ed.apply();
    }

    private TextView label(String s) {
        return text(s, 11, -12303292, true);
    }

    private EditText numberField(double v) {
        EditText e = new EditText(this);
        e.setSingleLine(true);
        e.setInputType(8194);
        e.setText(trimNum(v));
        return e;
    }

    private String httpGet(String url) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        try {
            c.setRequestMethod("GET");
            c.setConnectTimeout(6000);
            c.setReadTimeout(10000);
            c.setRequestProperty("User-Agent", "Neuraxon-Android/1.2");
            int code = c.getResponseCode();
            if (code != 200) {
                throw new Exception("HTTP " + code);
            }
            BufferedReader br = new BufferedReader(new InputStreamReader(c.getInputStream()));
            StringBuilder body = new StringBuilder();
            while (true) {
                String line = br.readLine();
                if (line == null) {
                    br.close();
                    return body.toString();
                }
                body.append(line);
            }
        } finally {
            c.disconnect();
        }
    }

    private String klines(String symbol, int limit) throws Exception {
        return klines(symbol, limit, 0L);
    }

    private String klines(String symbol, int limit, long endTime) throws Exception {
        List<String> hosts = new ArrayList<>();
        for (int i = 0; i < DATA_HOSTS.length; i++) {
            hosts.add(DATA_HOSTS[(this.hostIdx + i) % DATA_HOSTS.length]);
        }
        if (!this.mainnetOk && this.liveArmed && !this.liveReal) {
            hosts.add(TESTNET_DATA_HOST);
        }
        String first = null;
        for (String h : hosts) {
            try {
                String body = httpGet(h + "/api/v3/klines?symbol=" + symbol + "&interval=1h&limit=" + limit + (endTime > 0 ? "&endTime=" + endTime : ""));
                if (h.equals(TESTNET_DATA_HOST)) {
                    this.dataSource = "TESTNET data (real market hosts unreachable)";
                } else {
                    for (int i2 = 0; i2 < DATA_HOSTS.length; i2++) {
                        if (DATA_HOSTS[i2].equals(h)) {
                            this.hostIdx = i2;
                        }
                    }
                    this.mainnetOk = true;
                    this.dataSource = h.replace("https://", "");
                }
                return body;
            } catch (Exception e) {
                if (first == null) {
                    first = e.getMessage();
                }
            }
        }
        throw new Exception("No Binance data host reachable (" + first + "). Try Android Settings > Network > Private DNS > dns.google, or use a VPN.");
    }

    private List<NeuraxonEngine.Candle> parseCandles(String json) throws Exception {
        JSONArray arr = new JSONArray(json);
        long now = System.currentTimeMillis();
        List<NeuraxonEngine.Candle> out = new ArrayList<>();
        for (int i = 0; i < arr.length(); i++) {
            JSONArray k = arr.getJSONArray(i);
            if (k.getLong(6) < now) {
                out.add(new NeuraxonEngine.Candle(k.getLong(0), k.getDouble(1), k.getDouble(2), k.getDouble(3), k.getDouble(4), k.getDouble(5)));
            }
        }
        return out;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: lambda$runBacktest$16$com-neuraxon-app-MainActivity, reason: not valid java name */
    public /* synthetic */ void m16lambda$runBacktest$16$comneuraxonappMainActivity(String msg) {
        new AlertDialog.Builder(this).setTitle("Backtest results").setMessage(msg).setPositiveButton("OK", (DialogInterface.OnClickListener) null).show();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: lambda$runBacktest$17$com-neuraxon-app-MainActivity, reason: not valid java name */
    public /* synthetic */ void m17lambda$runBacktest$17$comneuraxonappMainActivity(String m) {
        Toast.makeText(this, "Backtest failed: " + m, 1).show();
    }

    @Override // android.app.Activity
    protected void onDestroy() {
        this.handler.removeCallbacks(this.poller);
        this.io.shutdownNow();
        this.apiKey = "";
        this.apiSecret = "";
        this.trader = null;
        super.onDestroy();
    }

    // ===================== Strategy, brains, rules (added in 1.3.0) =====================

    private static final class Seen {
        final NeuraxonEngine.Candle c;
        final NeuraxonEngine.Result raw;
        Seen(NeuraxonEngine.Candle c, NeuraxonEngine.Result raw) { this.c = c; this.raw = raw; }
    }

    private void syncParams() {
        this.rp.stopAtr = this.stopAtr;
        this.rp.rewardRisk = this.rewardRisk;
        this.rp.minConfidence = this.minConfidence;
    }

    private String ruleSig() {
        syncParams();
        return strategy + "|" + brainMode + "|" + rp.confirmCandles + "|" + rp.trendLen + "|" + rp.maxTradesPerDay + "|"
                + rp.dayLossPct + "|" + rp.dayProfitStopPct + "|" + rp.quietAtrPct + "|" + rp.cooldownCandles + "|" + rp.trailing + "|"
                + rp.trendFast + "|" + rp.breakoutN + "|" + rp.volMult + "|" + rp.rsiLow + "|" + rp.rsiHigh + "|" + rp.rangeER + "|"
                + stopAtr + "|" + rewardRisk + "|" + minConfidence + "|" + lossHaltUsdt + "|" + maxTradeUsdt;
    }

    private double paperEquityNow() {
        PortfolioSim s = this.paperSim;
        return s == null ? 10000.0d : s.equity;
    }

    private double paperPnlNow() {
        return paperEquityNow() - 10000.0d;
    }

    private int paperOpenCount() {
        PortfolioSim s = this.paperSim;
        return s == null ? 0 : s.positions.size();
    }

    private void remember(String symbol, NeuraxonEngine.Candle c, NeuraxonEngine.Result raw) {
        List<Seen> l = this.seen.get(symbol);
        if (l == null) {
            l = new ArrayList<>();
            this.seen.put(symbol, l);
        }
        synchronized (l) {
            l.add(new Seen(c, raw));
            if (l.size() > 500) {
                l.remove(0);
            }
        }
    }

    /** Builds a fresh paper account and replays remembered candles through the new rules for history only. */
    private void rebuildSim() {
        syncParams();
        Params p = this.rp.copy();
        PortfolioSim sim = new PortfolioSim(this.strategy, this.brainMode, p, this.bpp, this.bppCal, 10000.0d, true);
        for (String s : this.symbols) {
            List<Seen> l = this.seen.get(s);
            if (l == null) {
                continue;
            }
            synchronized (l) {
                for (Seen e : l) {
                    sim.observe(s, e.c, Backtester.withMin(e.raw, p.minConfidence));
                }
            }
        }
        double refCapital = this.maxTradeUsdt * MAX_OPEN_LIVE;
        this.liveRisk = new RiskState(p, this.lossHaltUsdt, p.dayProfitStopPct > 0 ? (p.dayProfitStopPct / 100.0d) * refCapital : -1.0d);
        this.paperSim = sim;
    }

    private String readAsset(String name) throws Exception {
        BufferedReader r = new BufferedReader(new InputStreamReader(getAssets().open(name)));
        try {
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) {
                sb.append(line).append('\n');
            }
            return sb.toString();
        } finally {
            r.close();
        }
    }

    private boolean bppOosOk() {
        return this.bppOosN >= 500 && (this.bppOosHits * 100.0d) / this.bppOosN >= 54.0d;
    }

    /**
     * Loads the BPP-9000 brain and checks, on real candles inside its training window, that its published
     * alignment can be reproduced for each pair. Also counts hits since the training window ended.
     */
    private void ensureBpp() {
        if (this.bpp == null) {
            try {
                this.bpp = Bpp9000Brain.parse(readAsset("bpp9000-brain.txt"));
            } catch (Exception e) {
                this.bppStatus = "BPP-9000 file could not be loaded: " + e.getMessage();
                return;
            }
        }
        if (this.bppChecked) {
            return;
        }
        try {
            int hits = 0;
            int n = 0;
            int ok = 0;
            StringBuilder sb = new StringBuilder();
            for (String s : this.symbols) {
                List<NeuraxonEngine.Candle> inWindow = parseCandles(klines(s, 1000, this.bpp.trainEndMs() - 1));
                Bpp9000Brain.Calibration c = this.bpp.calibrate(inWindow);
                this.bppCal.put(s, c);
                if (c.verified) {
                    ok++;
                    int[] f = this.bpp.forwardHits(parseCandles(klines(s, 1000)), c);
                    hits += f[0];
                    n += f[1];
                }
                sb.append(s.replace("USDT", "")).append(c.verified ? " ok" : " no").append(String.format(Locale.US, " (%.0f%%)", c.hitPct)).append("  ");
            }
            this.bppOosHits = hits;
            this.bppOosN = n;
            this.bppChecked = true;
            this.bppStatus = "BPP-9000 alignment reproduced on " + ok + " of 5 pairs: " + sb.toString().trim()
                    + (ok == 0 ? ". It is NOT usable here; pick the original brain." : "")
                    + (n > 0 ? String.format(Locale.US, "\nSince its training ended: %.1f%% over %d hours (about 50%% means no edge).", hits * 100.0d / n, n) : "\nNo hours since its training ended yet.");
            this.paperSim = null;
        } catch (Exception e) {
            this.bppStatus = "BPP-9000 check failed (will retry): " + e.getMessage();
        }
    }

    private void fetchMarketsWork() {
        Map<String, String> lines = new ConcurrentHashMap<>();
        boolean allDown = false;
        boolean any = false;
        String error = "";
        if (this.brainMode != BrainMode.ORIGINAL) {
            ensureBpp();
        }
        if (this.paperSim == null) {
            rebuildSim();
        }
        PortfolioSim sim = this.paperSim;
        for (String symbol : this.symbols) {
            if (allDown) {
                lines.put(symbol, symbol + "   DATA ERROR: " + error);
                continue;
            }
            try {
                boolean first = !this.lastProcessed.containsKey(symbol);
                JSONArray arr = new JSONArray(klines(symbol, first ? 300 : 100));
                NeuraxonEngine engine = this.engines.get(symbol);
                long newest = first ? -1L : this.lastProcessed.get(symbol).longValue();
                boolean historicalWarmup = newest < 0;
                long now = System.currentTimeMillis();
                double lastPrice = 0.0d;
                for (int i = 0; i < arr.length(); i++) {
                    JSONArray k = arr.getJSONArray(i);
                    long openTime = k.getLong(0);
                    long closeTime = k.getLong(6);
                    double cl = k.getDouble(4);
                    lastPrice = cl;
                    if (closeTime >= now || openTime <= newest) {
                        continue;
                    }
                    NeuraxonEngine.Candle cn = new NeuraxonEngine.Candle(openTime, k.getDouble(1), k.getDouble(2), k.getDouble(3), cl, k.getDouble(5));
                    NeuraxonEngine.Result raw = engine.onClosedCandle(cn);
                    NeuraxonEngine.Result res = Backtester.withMin(raw, this.rp.minConfidence);
                    remember(symbol, cn, raw);
                    SignalGate.Decision d;
                    if (this.running && !historicalWarmup) {
                        d = sim.onCandle(symbol, cn, res);
                        liveOnSignal(symbol, cn, res, d);
                    } else {
                        d = sim.observe(symbol, cn, res);
                    }
                    this.signals.put(symbol, "WARMING UP".equals(res.signal) ? res.signal : d.brainSignal);
                    this.confidences.put(symbol, Double.valueOf(d.confidence));
                    this.whyNot.put(symbol, d.why == null ? "" : d.why);
                    this.candleCounts.put(symbol, Integer.valueOf(this.candleCounts.get(symbol).intValue() + 1));
                    this.processed++;
                    newest = openTime;
                }
                if (newest >= 0) {
                    this.lastProcessed.put(symbol, Long.valueOf(newest));
                }
                this.prices.put(symbol, Double.valueOf(lastPrice));
                String why = this.whyNot.containsKey(symbol) ? this.whyNot.get(symbol) : "";
                lines.put(symbol, symbol + "   $" + this.priceFmt.format(lastPrice) + "   " + this.signals.get(symbol) + "  conf "
                        + String.format(Locale.US, "%.2f", Double.valueOf(this.confidences.containsKey(symbol) ? this.confidences.get(symbol).doubleValue() : 0.0d))
                        + "   (" + engineCount(symbol) + " candles)" + (why.isEmpty() ? "" : "\n   " + why));
                any = true;
            } catch (Exception e) {
                error = String.valueOf(e.getMessage());
                lines.put(symbol, symbol + "   DATA ERROR: " + error);
                if (error.startsWith("No Binance data host")) {
                    allDown = true;
                }
            }
        }
        reconcileLive();
        final boolean ok = any;
        final String rendered = join(lines);
        final String err = error;
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                MainActivity.this.m14lambda$fetchMarkets$6$comneuraxonappMainActivity(ok, rendered, err);
            }
        });
    }

    private String describeSetup() {
        syncParams();
        StringBuilder b = new StringBuilder();
        b.append("Strategy: ").append(this.strategy.label).append("   Brain: ").append(this.brainMode.label).append("\n");
        b.append("Rules: confirm ").append(this.rp.confirmCandles).append(" candles, SMA ").append(this.rp.trendLen)
                .append(", max ").append(this.rp.maxTradesPerDay).append(" trades/day, day loss ").append(trimNum(this.rp.dayLossPct)).append("%")
                .append(this.rp.dayProfitStopPct > 0 ? ", profit stop " + trimNum(this.rp.dayProfitStopPct) + "%" : "")
                .append(", stop ").append(trimNum(this.stopAtr)).append("xATR").append(this.rp.trailing ? " trailing" : "")
                .append(", quiet below ").append(trimNum(this.rp.quietAtrPct)).append("% ATR, pause ").append(this.rp.cooldownCandles).append(" after a loss.\n");
        if (this.brainMode != BrainMode.ORIGINAL) {
            b.append(this.bppStatus).append("\n");
        }
        return b.toString();
    }

    private void liveOnSignal(String symbol, NeuraxonEngine.Candle c, NeuraxonEngine.Result r, SignalGate.Decision d) {
        BinanceTrader t = this.trader;
        if (!this.liveArmed || t == null || this.liveHalted) {
            return;
        }
        if (t.serverNow() - (c.time + 3600000) > MAX_CANDLE_AGE_MS) {
            liveLog(symbol + ": candle is stale, no live order.");
            return;
        }
        try {
            LivePos p = this.livePositions.get(symbol);
            if (p != null && d.exitLong) {
                closeLive(t, p, "brain flipped");
            } else if (p == null && "BUY".equals(d.entry)) {
                if (this.brainMode != BrainMode.ORIGINAL && this.liveReal && !bppOosOk()) {
                    liveLog(symbol + ": BPP-9000 has no verified out-of-sample record yet (needs 500+ hours at 54%+). Real-money entry blocked.");
                    return;
                }
                RiskState lr = this.liveRisk;
                if (lr != null) {
                    String block = lr.blockReason(symbol, System.currentTimeMillis(), 0.0d);
                    if (block != null) {
                        liveLog(symbol + ": entry blocked (" + block + ").");
                        return;
                    }
                }
                openLive(t, symbol, c, r);
                if (lr != null && this.livePositions.containsKey(symbol)) {
                    lr.onEntry(System.currentTimeMillis(), 0.0d);
                }
            }
        } catch (BinanceTrader.ApiException e) {
            liveLog(symbol + " order error: " + e.getMessage());
            if (e.unknown) {
                this.liveHalted = true;
                liveLog(symbol + ": order status UNKNOWN. New entries halted. Check Binance before re-arming.");
            }
        } catch (Exception e2) {
            liveLog(symbol + " error: " + e2);
        }
    }

    private void openLive(BinanceTrader t, String symbol, NeuraxonEngine.Candle c, NeuraxonEngine.Result r) throws Exception {
        if (this.livePositions.size() >= MAX_OPEN_LIVE) {
            liveLog(symbol + ": max open positions reached, skipped.");
            return;
        }
        if (r.atr <= 0.0d) {
            return;
        }
        double stopDist = r.atr * this.stopAtr;
        double rel = stopDist / c.close;
        if (rel < 0.002d || rel > 0.15d) {
            liveLog(symbol + ": stop distance " + this.priceFmt.format(100.0d * rel) + "% is out of range, skipped.");
            return;
        }
        BinanceTrader.Rules rules = t.rules(symbol);
        if (this.maxTradeUsdt < rules.minNotional.doubleValue() * 1.1d) {
            liveLog(symbol + ": max/trade is below the exchange minimum ($" + rules.minNotional.toPlainString() + ").");
            return;
        }
        if (t.freeBalance(rules.quoteAsset) < this.maxTradeUsdt * 1.01d) {
            liveLog(symbol + ": not enough free " + rules.quoteAsset + ".");
            return;
        }
        BinanceTrader.Fill in = t.marketBuyQuote(symbol, this.maxTradeUsdt);
        double cost = in.quote + in.feeQuote;
        double entry = in.avgPrice;
        double stop = entry - stopDist;
        double target = entry + (this.rewardRisk * stopDist);
        BigDecimal qty = rules.floorQty(in.netQty);
        if (qty.compareTo(rules.minQty) < 0) {
            this.liveHalted = true;
            liveLog(symbol + ": bought, but the quantity is below the minimum lot so no stop could be placed. Halted. Check Binance.");
            return;
        }
        try {
            BinanceTrader.Oco oco = t.placeOco(symbol, qty, BigDecimal.valueOf(target), BigDecimal.valueOf(stop));
            this.livePositions.put(symbol, new LivePos(symbol, qty, cost, entry, stop, target, oco.listId, oco.orderIds));
            liveLog(symbol + ": BOUGHT " + qty.toPlainString() + " @ " + this.priceFmt.format(entry) + " with exchange-side stop and target.");
        } catch (Exception e) {
            liveLog(symbol + ": could not place stop/target (" + e.getMessage() + "). Selling at market.");
            try {
                BinanceTrader.Fill out = t.marketSell(symbol, qty);
                double pnl = (out.quote - out.feeQuote) - cost;
                this.liveRealized += pnl;
                if (this.liveRisk != null) {
                    this.liveRisk.onClose(symbol, pnl, System.currentTimeMillis(), 0.0d);
                }
                liveLog(symbol + ": closed at market.");
            } catch (Exception e2) {
                this.liveHalted = true;
                liveLog("!! " + symbol + " is UNPROTECTED and the sell failed (" + e2.getMessage() + "). Close it manually on Binance.");
            }
            checkHalt();
        }
    }

    private List<NeuraxonEngine.Candle> history(String symbol, int total) throws Exception {
        ArrayList<NeuraxonEngine.Candle> out = new ArrayList<>();
        long end = 0L;
        while (out.size() < total) {
            List<NeuraxonEngine.Candle> page = parseCandles(klines(symbol, 1000, end));
            if (page.isEmpty()) {
                break;
            }
            out.addAll(0, page);
            end = page.get(0).time - 1;
        }
        return out.size() > total ? new ArrayList<>(out.subList(out.size() - total, out.size())) : out;
    }

    private void runBacktest() {
        Toast.makeText(this, "Downloading history, one moment…", Toast.LENGTH_SHORT).show();
        syncParams();
        final Params p = this.rp.copy();
        this.io.execute(new Runnable() {
            @Override
            public void run() {
                MainActivity.this.backtestWork(p);
            }
        });
    }

    private void backtestWork(Params p) {
        try {
            if (this.bpp == null) {
                try {
                    this.bpp = Bpp9000Brain.parse(readAsset("bpp9000-brain.txt"));
                } catch (Exception e) {
                    this.bpp = null;
                }
            }
            List<Backtester.Series> in = new ArrayList<>();
            for (String s : this.symbols) {
                Backtester.Series se = new Backtester.Series();
                se.sym = s;
                se.candles = history(s, 4000);
                in.add(se);
            }
            List<Backtester.Series> data = Backtester.align(in);
            Map<String, Bpp9000Brain.Calibration> cals = new java.util.HashMap<>();
            if (this.bpp != null) {
                for (Backtester.Series se : data) {
                    List<NeuraxonEngine.Candle> inWindow = new ArrayList<>();
                    for (NeuraxonEngine.Candle c : se.candles) {
                        if (c.time < this.bpp.trainEndMs()) {
                            inWindow.add(c);
                        }
                    }
                    cals.put(se.sym, this.bpp.calibrate(inWindow));
                }
            }
            final String msg = Backtester.report(p, data, this.bpp, cals);
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    MainActivity.this.m16lambda$runBacktest$16$comneuraxonappMainActivity(msg);
                }
            });
        } catch (Exception e2) {
            final String m = String.valueOf(e2.getMessage());
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    MainActivity.this.m17lambda$runBacktest$17$comneuraxonappMainActivity(m);
                }
            });
        }
    }

    private double parseNonNeg(String s, double fallback) {
        try {
            double v = Double.parseDouble(s.trim());
            return (v >= 0.0d && !Double.isNaN(v) && !Double.isInfinite(v)) ? v : fallback;
        } catch (Exception e) {
            return fallback;
        }
    }

    private Spinner spinner(String[] items, int sel) {
        Spinner sp = new Spinner(this);
        sp.setAdapter((android.widget.SpinnerAdapter) new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, items));
        sp.setSelection(sel);
        return sp;
    }

    private void showSettings() {
        LinearLayout box = col();
        box.setPadding(40, 20, 40, 0);
        box.addView(text("API keys stay in memory only and are cleared when the app closes. Use a trade-only key with withdrawals OFF. Testnet keys come from testnet.binance.vision and differ from real keys. The strategy values below apply to paper and live trading and are saved on this phone. Changing a rule resets the paper account.", 12, -12303292, false));
        gap(box, 10);
        box.addView(label("API KEY"));
        final EditText key = new EditText(this);
        key.setSingleLine(true);
        key.setInputType(524289);
        key.setText(this.apiKey);
        box.addView(key);
        box.addView(label("API SECRET"));
        final EditText sec = new EditText(this);
        sec.setSingleLine(true);
        sec.setInputType(129);
        sec.setText(this.apiSecret);
        box.addView(sec);
        box.addView(label("MAX PER LIVE TRADE (USDT)"));
        final EditText cap = numberField(this.maxTradeUsdt);
        box.addView(cap);
        box.addView(label("SESSION LOSS HALT (USDT): stops new live entries (also the live daily loss limit)"));
        final EditText halt = numberField(this.lossHaltUsdt);
        box.addView(halt);
        box.addView(label("RULE 5  STOP DISTANCE (x ATR, 0.5 to 5): smaller = tighter stop"));
        final EditText stp = numberField(this.stopAtr);
        box.addView(stp);
        box.addView(label("REWARD : RISK (0.5 to 5): target = stop distance x this"));
        final EditText rrf = numberField(this.rewardRisk);
        box.addView(rrf);
        box.addView(label("MIN CONFIDENCE TO TRADE (0.05 to 0.90), original brain only"));
        final EditText mcf = numberField(this.minConfidence);
        box.addView(mcf);

        box.addView(label("STRATEGY"));
        String[] sl = new String[Strategy.values().length];
        for (int i = 0; i < sl.length; i++) {
            sl[i] = Strategy.values()[i].label;
        }
        final Spinner stSp = spinner(sl, this.strategy.ordinal());
        box.addView(stSp);
        box.addView(label("BRAIN"));
        String[] bl = new String[BrainMode.values().length];
        for (int i = 0; i < bl.length; i++) {
            bl[i] = BrainMode.values()[i].label;
        }
        final Spinner brSp = spinner(bl, this.brainMode.ordinal());
        box.addView(brSp);

        final String[] names = {
            "RULE 1  BRAIN MUST REPEAT THE SAME CALL FOR (candles, 1 to 5)",
            "RULE 2  TREND SMA LENGTH (20 to 300)",
            "RULE 3  MAX NEW TRADES PER DAY (1 to 20)",
            "RULE 4  DAILY LOSS LIMIT % of equity (paper)",
            "RULE 4  DAILY PROFIT STOP % (0 = off)",
            "RULE 6  QUIET MARKET: skip if ATR % of price is below",
            "RULE 6  PAUSE AFTER A LOSS (candles, 0 to 24)",
            "STRATEGY 2  FAST EMA LENGTH (5 to 100)",
            "STRATEGY 3  BREAKOUT LOOKBACK N (5 to 100)",
            "STRATEGY 3  VOLUME x 20-CANDLE AVERAGE (0.5 to 5)",
            "STRATEGY 4  OVERSOLD RSI below (5 to 45)",
            "STRATEGY 4  OVERBOUGHT RSI above (55 to 95)",
            "STRATEGY 4  RANGING IF EFFICIENCY BELOW (0.1 to 0.6)"};
        double[] vals = {this.rp.confirmCandles, this.rp.trendLen, this.rp.maxTradesPerDay, this.rp.dayLossPct, this.rp.dayProfitStopPct,
                this.rp.quietAtrPct, this.rp.cooldownCandles, this.rp.trendFast, this.rp.breakoutN, this.rp.volMult,
                this.rp.rsiLow, this.rp.rsiHigh, this.rp.rangeER};
        final EditText[] f = new EditText[names.length];
        for (int i = 0; i < names.length; i++) {
            box.addView(label(names[i]));
            f[i] = numberField(vals[i]);
            box.addView(f[i]);
            if (i == 6) {
                final CheckBox tr = new CheckBox(this);
                tr.setText("RULE 5  TRAILING STOP (paper and backtest only; live orders keep a fixed exchange stop)");
                tr.setTextColor(-12303292);
                tr.setChecked(this.rp.trailing);
                tr.setTag("trail");
                box.addView(tr);
            }
        }
        final LinearLayout boxRef = box;
        ScrollView sv = new ScrollView(this);
        sv.addView(box);
        AlertDialog dlg = new AlertDialog.Builder(this).setTitle("Settings").setView(sv).setNegativeButton("Cancel", (DialogInterface.OnClickListener) null).setPositiveButton("Save", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int which) {
                String before = MainActivity.this.ruleSig();
                BrainMode beforeMode = MainActivity.this.brainMode;
                String nk = key.getText().toString().trim();
                String ns = sec.getText().toString().trim();
                boolean keysChanged = !(nk.equals(MainActivity.this.apiKey) && ns.equals(MainActivity.this.apiSecret));
                MainActivity.this.apiKey = nk;
                MainActivity.this.apiSecret = ns;
                MainActivity.this.maxTradeUsdt = clamp(parsePositive(cap.getText().toString(), MainActivity.this.maxTradeUsdt), 1.0d, 1000000.0d);
                MainActivity.this.lossHaltUsdt = clamp(parsePositive(halt.getText().toString(), MainActivity.this.lossHaltUsdt), 0.1d, 1000000.0d);
                MainActivity.this.stopAtr = clamp(parsePositive(stp.getText().toString(), MainActivity.this.stopAtr), 0.5d, 5.0d);
                MainActivity.this.rewardRisk = clamp(parsePositive(rrf.getText().toString(), MainActivity.this.rewardRisk), 0.5d, 5.0d);
                MainActivity.this.minConfidence = clamp(parsePositive(mcf.getText().toString(), MainActivity.this.minConfidence), 0.05d, 0.9d);
                MainActivity.this.strategy = Strategy.values()[Math.max(0, stSp.getSelectedItemPosition())];
                MainActivity.this.brainMode = BrainMode.values()[Math.max(0, brSp.getSelectedItemPosition())];
                Params q = MainActivity.this.rp;
                q.confirmCandles = (int) clamp(parseNonNeg(f[0].getText().toString(), q.confirmCandles), 1, 5);
                q.trendLen = (int) clamp(parseNonNeg(f[1].getText().toString(), q.trendLen), 20, 300);
                q.maxTradesPerDay = (int) clamp(parseNonNeg(f[2].getText().toString(), q.maxTradesPerDay), 1, 20);
                q.dayLossPct = clamp(parsePositive(f[3].getText().toString(), q.dayLossPct), 0.1d, 50.0d);
                q.dayProfitStopPct = clamp(parseNonNeg(f[4].getText().toString(), q.dayProfitStopPct), 0.0d, 100.0d);
                q.quietAtrPct = clamp(parseNonNeg(f[5].getText().toString(), q.quietAtrPct), 0.0d, 5.0d);
                q.cooldownCandles = (int) clamp(parseNonNeg(f[6].getText().toString(), q.cooldownCandles), 0, 24);
                q.trendFast = (int) clamp(parseNonNeg(f[7].getText().toString(), q.trendFast), 5, 100);
                q.breakoutN = (int) clamp(parseNonNeg(f[8].getText().toString(), q.breakoutN), 5, 100);
                q.volMult = clamp(parseNonNeg(f[9].getText().toString(), q.volMult), 0.5d, 5.0d);
                q.rsiLow = clamp(parseNonNeg(f[10].getText().toString(), q.rsiLow), 5.0d, 45.0d);
                q.rsiHigh = clamp(parseNonNeg(f[11].getText().toString(), q.rsiHigh), 55.0d, 95.0d);
                q.rangeER = clamp(parseNonNeg(f[12].getText().toString(), q.rangeER), 0.1d, 0.6d);
                View tv = boxRef.findViewWithTag("trail");
                if (tv instanceof CheckBox) {
                    q.trailing = ((CheckBox) tv).isChecked();
                }
                MainActivity.this.syncParams();
                if (!before.equals(MainActivity.this.ruleSig())) {
                    MainActivity.this.paperSim = null;
                    MainActivity.this.liveRisk = null;
                    if (beforeMode != MainActivity.this.brainMode) {
                        MainActivity.this.bppChecked = false;
                    }
                }
                MainActivity.this.savePrefs();
                MainActivity.this.refreshLiveViews();
                Toast.makeText(MainActivity.this, (keysChanged && MainActivity.this.liveArmed) ? "Saved. Re-select the live mode to use the new keys." : "Saved. Rule changes apply from the next refresh.", Toast.LENGTH_SHORT).show();
            }
        }).create();
        dlg.getWindow().addFlags(8192);
        dlg.show();
    }

    private void loadRules(SharedPreferences sp) {
        this.strategy = Strategy.fromName(sp.getString("strategy", ""), Strategy.TREND_BRAIN);
        this.brainMode = BrainMode.fromName(sp.getString("brainMode", ""), BrainMode.BOTH);
        Params q = this.rp;
        q.confirmCandles = (int) clamp(pd(sp, "confirm", 2), 1, 5);
        q.trendLen = (int) clamp(pd(sp, "trendLen", 100), 20, 300);
        q.maxTradesPerDay = (int) clamp(pd(sp, "maxTrades", 3), 1, 20);
        q.dayLossPct = clamp(pd(sp, "dayLoss", 3.0d), 0.1d, 50.0d);
        q.dayProfitStopPct = clamp(pd(sp, "dayProfit", 0.0d), 0.0d, 100.0d);
        q.quietAtrPct = clamp(pd(sp, "quiet", 0.20d), 0.0d, 5.0d);
        q.cooldownCandles = (int) clamp(pd(sp, "cooldown", 3), 0, 24);
        q.trailing = "true".equals(sp.getString("trailing", "false"));
        q.trendFast = (int) clamp(pd(sp, "trendFast", 20), 5, 100);
        q.breakoutN = (int) clamp(pd(sp, "breakN", 20), 5, 100);
        q.volMult = clamp(pd(sp, "volMult", 1.0d), 0.5d, 5.0d);
        q.rsiLow = clamp(pd(sp, "rsiLow", 30), 5.0d, 45.0d);
        q.rsiHigh = clamp(pd(sp, "rsiHigh", 70), 55.0d, 95.0d);
        q.rangeER = clamp(pd(sp, "rangeER", 0.30d), 0.1d, 0.6d);
    }

    private void saveRules(SharedPreferences.Editor e) {
        Params q = this.rp;
        e.putString("strategy", this.strategy.name()).putString("brainMode", this.brainMode.name())
                .putString("confirm", String.valueOf(q.confirmCandles)).putString("trendLen", String.valueOf(q.trendLen))
                .putString("maxTrades", String.valueOf(q.maxTradesPerDay)).putString("dayLoss", String.valueOf(q.dayLossPct))
                .putString("dayProfit", String.valueOf(q.dayProfitStopPct)).putString("quiet", String.valueOf(q.quietAtrPct))
                .putString("cooldown", String.valueOf(q.cooldownCandles)).putString("trailing", String.valueOf(q.trailing))
                .putString("trendFast", String.valueOf(q.trendFast)).putString("breakN", String.valueOf(q.breakoutN))
                .putString("volMult", String.valueOf(q.volMult)).putString("rsiLow", String.valueOf(q.rsiLow))
                .putString("rsiHigh", String.valueOf(q.rsiHigh)).putString("rangeER", String.valueOf(q.rangeER));
    }
}
