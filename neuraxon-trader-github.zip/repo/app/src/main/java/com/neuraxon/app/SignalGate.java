package com.neuraxon.app;

import java.util.ArrayList;
import java.util.List;

/**
 * Turns the brain call(s) plus price rules into an entry/exit decision for ONE pair.
 * Call onCandle() once per closed candle, in time order. It never looks at anything after
 * the candle it is given.
 *
 * Entry needs ALL of:
 *  - the strategy's own price condition gives a direction (strategy 1: the brain itself)
 *  - rule 1: the brain gave that same call for confirmCandles closed candles in a row
 *  - rule 2: trend filter (long only above the SMA, short only below)
 *  - rule 6: market is not dead (ATR as % of price above the quiet threshold)
 * Rules 3 and 4 (per-day limits) and the loss cooldown live in RiskState, rule 5 (stops) in the executor.
 */
final class SignalGate {
    static final class Decision {
        String entry;            // "BUY", "SELL" or null
        boolean exitLong;        // confirmed brain call turned to SELL
        boolean exitShort;       // confirmed brain call turned to BUY
        String brainSignal = "HOLD";
        double confidence;
        String candidate;        // what the strategy alone wanted
        String why = "";         // why no entry (or the reason for it)
    }

    private final Strategy strategy;
    private final BrainMode mode;
    private final Params p;
    private final Bpp9000Brain bpp;
    private final Bpp9000Brain.Calibration cal;   // null or unverified = BPP unavailable
    private final ArrayList<NeuraxonEngine.Candle> hist = new ArrayList<>();
    private final ArrayList<String> sigs = new ArrayList<>();

    SignalGate(Strategy strategy, BrainMode mode, Params p, Bpp9000Brain bpp, Bpp9000Brain.Calibration cal) {
        this.strategy = strategy; this.mode = mode; this.p = p; this.bpp = bpp; this.cal = cal;
    }

    boolean bppAvailable() { return bpp != null && cal != null && cal.verified; }

    /** Combine the brains into one call. HOLD when the chosen brain(s) cannot give one. */
    private String combine(NeuraxonEngine.Candle c, String origSig) {
        String b = "HOLD";
        if (bppAvailable()) {
            int call = bpp.callAfter(c.time, cal);
            b = call == 1 ? "BUY" : call == 0 ? "SELL" : "HOLD";
        }
        switch (mode) {
            case ORIGINAL: return origSig;
            case BPP9000: return b;
            default: return (!b.equals("HOLD") && b.equals(origSig)) ? b : "HOLD";
        }
    }

    Decision onCandle(NeuraxonEngine.Candle c, NeuraxonEngine.Result r) {
        hist.add(c);
        if (hist.size() > 600) hist.remove(0);
        Decision d = new Decision();
        String orig = "BUY".equals(r.signal) || "SELL".equals(r.signal) ? r.signal : "HOLD";
        String sig = combine(c, orig);
        d.brainSignal = sig;
        d.confidence = mode == BrainMode.BPP9000 ? (sig.equals("HOLD") ? 0 : 1) : r.confidence;
        sigs.add(sig);
        if (sigs.size() > 10) sigs.remove(0);

        // rule 1: same non-HOLD call for the last confirmCandles candles
        String confirmed = null;
        int need = Math.max(1, p.confirmCandles);
        if (sigs.size() >= need) {
            String last = sigs.get(sigs.size() - 1);
            boolean same = !last.equals("HOLD");
            for (int i = 1; i < need && same; i++) same = sigs.get(sigs.size() - 1 - i).equals(last);
            if (same) confirmed = last;
        }
        d.exitLong = "SELL".equals(confirmed);
        d.exitShort = "BUY".equals(confirmed);

        int need2 = Math.max(Math.max(p.trendLen, p.breakoutN + 1), Math.max(p.erLen + 1, p.volLen + 1)) + 1;
        if (hist.size() < need2 || r.atr <= 0) { d.why = "warming up"; return d; }
        if (mode != BrainMode.ORIGINAL && !bppAvailable()) { d.why = "BPP-9000 not verified for this pair"; return d; }
        if (confirmed == null) { d.why = "brain not confirmed " + need + " candles"; return d; }

        // rule 6: quiet market
        if (r.atr / c.close * 100.0 < p.quietAtrPct) { d.why = "quiet market"; return d; }

        // strategy candidate
        String cand = null;
        switch (strategy) {
            case BRAIN_ONLY:
                cand = confirmed;
                break;
            case TREND_BRAIN: {
                double s = Indicators.sma(hist, p.trendLen), f = Indicators.ema(hist, p.trendFast);
                if (c.close > s && f > s) cand = "BUY"; else if (c.close < s && f < s) cand = "SELL";
                break;
            }
            case BREAKOUT: {
                double hh = Indicators.highestBefore(hist, p.breakoutN), ll = Indicators.lowestBefore(hist, p.breakoutN);
                boolean volOk = c.volume > p.volMult * Indicators.avgVolumeBefore(hist, p.volLen);
                if (volOk && c.close > hh) cand = "BUY"; else if (volOk && c.close < ll) cand = "SELL";
                break;
            }
            case MEAN_REVERSION: {
                if (Indicators.efficiency(hist, p.erLen) < p.rangeER) {
                    double rsi = Indicators.rsi(hist, p.rsiLen);
                    if (rsi < p.rsiLow) cand = "BUY"; else if (rsi > p.rsiHigh) cand = "SELL";
                }
                break;
            }
            default: break;
        }
        d.candidate = cand;
        if (cand == null) { d.why = "no " + strategy.label + " setup"; return d; }
        if (!cand.equals(confirmed)) { d.why = "brain disagrees with setup"; return d; }

        // rule 2: trend filter
        double sma = Indicators.sma(hist, p.trendLen);
        if (cand.equals("BUY") && !(c.close > sma)) { d.why = "below trend average"; return d; }
        if (cand.equals("SELL") && !(c.close < sma)) { d.why = "above trend average"; return d; }

        d.entry = cand;
        d.why = "all rules pass";
        return d;
    }
}
