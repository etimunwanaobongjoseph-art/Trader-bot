package com.neuraxon.app;

import java.util.List;

/**
 * Qubic BPP-9000 brain: 1024 ternary neurons, each with 3 sources and a 27-entry lookup table.
 * It takes NO market input. Each tick it just steps its own state. Whenever the control neuron is
 * not 2, the output neuron is the call (0 down, 1 up or flat). Between calls the last call stands
 * (the published score counts every hour of the frame, so a call must exist for each hour).
 *
 * Because it ignores candles, its alignment to real hours (tick offset) and pair are NOT stored in
 * the file. calibrate() measures them on real candles; a brain whose alignment cannot be
 * reproduced is never used for trading.
 */
final class Bpp9000Brain {
    static final class Calibration {
        boolean verified;
        int shift;          // tick offset: call for candle k is stickyCall(k + shift)
        int rounding = -1;  // -1 none, 0 integer, 2 two decimals
        int n;
        double hitPct;
        double z;
        double declaredHitPct; // hit rate at the file's own shift (118), same rounding
        String note = "";
    }

    final String hash;
    final int control, output, declaredShift, hours;
    final long startMs;
    final double claimedPct;
    private final int n;
    private final int[] sa, sb, sc;
    private final byte[][] lut;
    private final byte[] init;
    private byte[] state;
    private byte[] sticky = new byte[4096];
    private int computed = 0;
    private byte lastCall = 2;

    private Bpp9000Brain(String hash, int control, int output, long startSec, int hours, int shift,
                         double claimed, int[] a, int[] b, int[] c, byte[][] lut, byte[] init) {
        this.hash = hash; this.control = control; this.output = output;
        this.startMs = startSec * 1000L; this.hours = hours; this.declaredShift = shift;
        this.claimedPct = claimed; this.n = init.length;
        this.sa = a; this.sb = b; this.sc = c; this.lut = lut; this.init = init;
        this.state = init.clone();
    }

    static Bpp9000Brain parse(String text) {
        String[] lines = text.split("\\r?\\n");
        if (lines.length < 10 || !lines[0].startsWith("BPP9000")) throw new IllegalArgumentException("not a BPP9000 brain file");
        String hash = ""; int control = 0, output = 0, hours = 0, shift = 0, count = 0; long start = 0; double claimed = 0;
        int i = 1;
        for (; i < lines.length; i++) {
            String[] kv = lines[i].trim().split(" ");
            if (kv.length < 2) continue;
            switch (kv[0]) {
                case "hash": hash = kv[1]; break;
                case "control": control = Integer.parseInt(kv[1]); break;
                case "output": output = Integer.parseInt(kv[1]); break;
                case "start": start = Long.parseLong(kv[1]); break;
                case "hours": hours = Integer.parseInt(kv[1]); break;
                case "shift": shift = Integer.parseInt(kv[1]); break;
                case "claimed": claimed = Double.parseDouble(kv[1]); break;
                case "nodes": count = Integer.parseInt(kv[1]); break;
                default: break;
            }
            if (kv[0].equals("nodes")) { i++; break; }
        }
        int[] a = new int[count], b = new int[count], c = new int[count];
        byte[][] lut = new byte[count][27];
        byte[] init = new byte[count];
        for (int k = 0; k < count; k++, i++) {
            String[] f = lines[i].trim().split(" ");
            init[k] = (byte) Integer.parseInt(f[0]);
            a[k] = Integer.parseInt(f[1]); b[k] = Integer.parseInt(f[2]); c[k] = Integer.parseInt(f[3]);
            for (int j = 0; j < 27; j++) lut[k][j] = (byte) (f[4].charAt(j) - '0');
        }
        return new Bpp9000Brain(hash, control, output, start, hours, shift, claimed, a, b, c, lut, init);
    }

    /** Last call at or before this tick: 0 down, 1 up/flat, 2 none yet. */
    synchronized int stickyCall(int tick) {
        if (tick < 0) return 2;
        while (computed <= tick) {
            if (computed >= sticky.length) sticky = java.util.Arrays.copyOf(sticky, sticky.length * 2);
            int ctl = state[control], out = state[output];
            if (ctl != 2 && out != 2) lastCall = (byte) out;
            sticky[computed++] = lastCall;
            byte[] next = new byte[n];
            for (int k = 0; k < n; k++) next[k] = lut[k][state[sa[k]] + 3 * state[sb[k]] + 9 * state[sc[k]]];
            state = next;
        }
        return sticky[tick];
    }

    long trainEndMs() { return startMs + hours * 3600000L; }

    /**
     * Hits of the calibrated calls on candles that open AFTER the training window ended.
     * Returns {hits, count}. This is the only honest evidence of an edge and it grows by one per hour.
     */
    int[] forwardHits(List<NeuraxonEngine.Candle> candles, Calibration cal) {
        int hit = 0, cnt = 0;
        if (cal == null) return new int[]{0, 0};
        for (int j = 1; j < candles.size(); j++) {
            NeuraxonEngine.Candle c = candles.get(j);
            if (c.time < trainEndMs()) continue;
            long t = hourIndex(c.time) + cal.shift;
            if (t < 0 || t > 5_000_000) continue;
            int call = stickyCall((int) t);
            if (call == 2) continue;
            boolean up = round(c.close, cal.rounding) - round(candles.get(j - 1).close, cal.rounding) >= 0;
            cnt++;
            if ((call == 1) == up) hit++;
        }
        return new int[]{hit, cnt};
    }

    long hourIndex(long openTimeMs) { return Math.floorDiv(openTimeMs - startMs, 3600000L); }

    /** Call for the candle AFTER the one that opened at openTimeMs: 1 up, 0 down, 2 none. */
    int callAfter(long openTimeMs, Calibration cal) {
        if (cal == null || !cal.verified) return 2;
        long tick = hourIndex(openTimeMs) + 1 + cal.shift;
        if (tick < 0 || tick > 5_000_000) return 2;
        return stickyCall((int) tick);
    }

    private static double round(double v, int mode) {
        if (mode < 0) return v;
        double m = Math.pow(10, mode);
        return Math.round(v * m) / m;
    }

    /**
     * Search shifts -300..300 and three roundings for the alignment that reproduces a hit rate far above
     * chance on real candles. Pass candles that fall inside the brain's training window. Needs a z-score
     * of 5 or more (the best of ~1800 tries on pure noise reaches about 3.5) and a hit rate of 56% or more.
     */
    Calibration calibrate(List<NeuraxonEngine.Candle> candles) {
        Calibration best = new Calibration();
        best.note = "not enough candles";
        if (candles.size() < 400) return best;
        int m = candles.size();
        int[] roundings = {-1, 0, 2};
        double bestZ = -1e9;
        for (int rd : roundings) {
            boolean[] up = new boolean[m];
            long[] k = new long[m];
            for (int j = 1; j < m; j++) {
                up[j] = round(candles.get(j).close, rd) - round(candles.get(j - 1).close, rd) >= 0;
                k[j] = hourIndex(candles.get(j).time);
            }
            for (int s = -300; s <= 300; s++) {
                int hit = 0, cnt = 0;
                for (int j = 1; j < m; j++) {
                    long t = k[j] + s;
                    if (t < 0) continue;
                    int call = stickyCall((int) t);
                    if (call == 2) continue;
                    cnt++;
                    if ((call == 1) == up[j]) hit++;
                }
                if (cnt < 300) continue;
                double z = (hit / (double) cnt - 0.5) / (0.5 / Math.sqrt(cnt));
                if (z > bestZ) {
                    bestZ = z; best.shift = s; best.rounding = rd; best.n = cnt; best.hitPct = hit * 100.0 / cnt; best.z = z;
                }
            }
        }
        // hit rate at the file's own declared shift, same rounding, for reference
        int hit = 0, cnt = 0;
        for (int j = 1; j < m; j++) {
            long t = hourIndex(candles.get(j).time) + declaredShift;
            int call = stickyCall((int) Math.max(0, t));
            if (call == 2) continue;
            cnt++;
            boolean upj = round(candles.get(j).close, best.rounding) - round(candles.get(j - 1).close, best.rounding) >= 0;
            if ((call == 1) == upj) hit++;
        }
        best.declaredHitPct = cnt == 0 ? 0 : hit * 100.0 / cnt;
        best.verified = best.n >= 300 && best.hitPct >= 56.0 && best.z >= 5.0;
        best.note = best.verified
                ? "alignment reproduced (shift " + best.shift + ")"
                : "NOT verified: best hit " + String.format(java.util.Locale.US, "%.1f", best.hitPct) + "% (z " + String.format(java.util.Locale.US, "%.1f", best.z) + ")";
        return best;
    }
}
