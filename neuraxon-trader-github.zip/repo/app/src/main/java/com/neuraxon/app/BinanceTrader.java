package com.neuraxon.app;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import org.json.JSONArray;
import org.json.JSONObject;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: classes2.dex */
public final class BinanceTrader {
    static final String LIVE_URL = "https://api.binance.com";
    static final String TESTNET_URL = "https://testnet.binance.vision";
    private final String apiKey;
    private final String baseUrl;
    private final String secret;
    private volatile long timeOffset = 0;
    private final Map<String, Rules> rulesCache = new HashMap();

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes2.dex */
    public static final class ApiException extends Exception {
        final int code;
        final int http;
        final boolean unknown;

        ApiException(int http, int code, String msg, boolean unknown) {
            super(msg);
            this.http = http;
            this.code = code;
            this.unknown = unknown;
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes2.dex */
    public static final class Rules {
        String baseAsset;
        BigDecimal minNotional;
        BigDecimal minQty;
        String quoteAsset;
        BigDecimal stepSize;
        BigDecimal tickSize;

        Rules() {
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        public BigDecimal floorQty(BigDecimal q) {
            return floorTo(q, this.stepSize);
        }

        BigDecimal floorPrice(BigDecimal p) {
            return floorTo(p, this.tickSize);
        }

        private static BigDecimal floorTo(BigDecimal v, BigDecimal step) {
            int dec = Math.max(0, BinanceTrader.stripZeros(step).scale());
            return v.divideToIntegralValue(step).multiply(step).setScale(dec, RoundingMode.DOWN);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes2.dex */
    public static final class Fill {
        double avgPrice;
        double feeQuote;
        BigDecimal netQty;
        double quote;

        Fill() {
        }
    }

    /* loaded from: classes2.dex */
    static final class Oco {
        long listId;
        final List<Long> orderIds = new ArrayList();

        Oco() {
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public BinanceTrader(String baseUrl, String apiKey, String secret) {
        this.baseUrl = baseUrl;
        this.apiKey = apiKey.trim();
        this.secret = secret.trim();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public long serverNow() {
        return System.currentTimeMillis() + this.timeOffset;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void syncTime() throws ApiException {
        try {
            JSONObject o = new JSONObject(call("GET", "/api/v3/time", new LinkedHashMap(), false));
            this.timeOffset = o.getLong("serverTime") - System.currentTimeMillis();
        } catch (ApiException e) {
            throw e;
        } catch (Exception e2) {
            throw new ApiException(0, 0, "Bad time response: " + e2.getMessage(), false);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public String verify(String symbol, double quoteUsdt) throws ApiException {
        try {
            JSONObject acct = new JSONObject(call("GET", "/api/v3/account", new LinkedHashMap(), true));
            if (!acct.optBoolean("canTrade", false)) {
                throw new ApiException(0, 0, "This account cannot trade. Enable Spot trading on the API key.", false);
            }
            Map<String, String> p = new LinkedHashMap<>();
            p.put("symbol", symbol);
            p.put("side", "BUY");
            p.put("type", "MARKET");
            p.put("quoteOrderQty", fmt(BigDecimal.valueOf(quoteUsdt).setScale(2, RoundingMode.DOWN)));
            call("POST", "/api/v3/order/test", p, true);
            int open = new JSONArray(call("GET", "/api/v3/openOrderList", new LinkedHashMap(), true)).length();
            return "Keys OK. Free USDT: " + String.format(Locale.US, "%.2f", Double.valueOf(balanceOf(acct, "USDT"))) + (open > 0 ? ". Note: " + open + " open order list(s) already exist on this account; this app does not manage them." : ".");
        } catch (ApiException e) {
            throw e;
        } catch (Exception e2) {
            throw new ApiException(0, 0, "Unexpected response: " + e2.getMessage(), false);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public double freeBalance(String asset) throws ApiException {
        try {
            return balanceOf(new JSONObject(call("GET", "/api/v3/account", new LinkedHashMap(), true)), asset);
        } catch (ApiException e) {
            throw e;
        } catch (Exception e2) {
            throw new ApiException(0, 0, "Bad account response: " + e2.getMessage(), false);
        }
    }

    private static double balanceOf(JSONObject acct, String asset) throws Exception {
        JSONArray b = acct.getJSONArray("balances");
        for (int i = 0; i < b.length(); i++) {
            JSONObject o = b.getJSONObject(i);
            if (asset.equals(o.getString("asset"))) {
                return Double.parseDouble(o.getString("free"));
            }
        }
        return 0.0d;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public Rules rules(String symbol) throws ApiException {
        Rules cached = this.rulesCache.get(symbol);
        if (cached != null) {
            return cached;
        }
        try {
            Map<String, String> p = new LinkedHashMap<>();
            p.put("symbol", symbol);
            JSONObject root = new JSONObject(call("GET", "/api/v3/exchangeInfo", p, false));
            JSONObject s = root.getJSONArray("symbols").getJSONObject(0);
            if (!"TRADING".equals(s.optString("status"))) {
                throw new ApiException(0, 0, symbol + " is not currently trading.", false);
            }
            Rules r = new Rules();
            r.baseAsset = s.getString("baseAsset");
            r.quoteAsset = s.getString("quoteAsset");
            JSONArray f = s.getJSONArray("filters");
            for (int i = 0; i < f.length(); i++) {
                JSONObject o = f.getJSONObject(i);
                String t = o.getString("filterType");
                if (t.equals("LOT_SIZE")) {
                    r.stepSize = new BigDecimal(o.getString("stepSize"));
                    r.minQty = new BigDecimal(o.getString("minQty"));
                } else if (t.equals("PRICE_FILTER")) {
                    r.tickSize = new BigDecimal(o.getString("tickSize"));
                } else if (t.equals("NOTIONAL") || t.equals("MIN_NOTIONAL")) {
                    r.minNotional = new BigDecimal(o.getString("minNotional"));
                }
            }
            if (r.stepSize == null || r.minQty == null || r.tickSize == null || r.minNotional == null || r.stepSize.signum() <= 0 || r.tickSize.signum() <= 0) {
                throw new ApiException(0, 0, "Missing trading filters for " + symbol, false);
            }
            this.rulesCache.put(symbol, r);
            return r;
        } catch (ApiException e) {
            throw e;
        } catch (Exception e2) {
            throw new ApiException(0, 0, "Bad exchange info for " + symbol + ": " + e2.getMessage(), false);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public Fill marketBuyQuote(String symbol, double quoteUsdt) throws ApiException {
        Rules r = rules(symbol);
        Map<String, String> p = new LinkedHashMap<>();
        p.put("symbol", symbol);
        p.put("side", "BUY");
        p.put("type", "MARKET");
        p.put("quoteOrderQty", fmt(BigDecimal.valueOf(quoteUsdt).setScale(2, RoundingMode.DOWN)));
        p.put("newOrderRespType", "FULL");
        return parseFill(call("POST", "/api/v3/order", p, true), r);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public Fill marketSell(String symbol, BigDecimal qty) throws ApiException {
        Rules r = rules(symbol);
        Map<String, String> p = new LinkedHashMap<>();
        p.put("symbol", symbol);
        p.put("side", "SELL");
        p.put("type", "MARKET");
        p.put("quantity", fmt(r.floorQty(qty)));
        p.put("newOrderRespType", "FULL");
        return parseFill(call("POST", "/api/v3/order", p, true), r);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public Oco placeOco(String symbol, BigDecimal qty, BigDecimal target, BigDecimal stop) throws ApiException {
        Rules r = rules(symbol);
        BigDecimal tp = r.floorPrice(target);
        BigDecimal sp = r.floorPrice(stop);
        BigDecimal sl = r.floorPrice(stop.multiply(new BigDecimal("0.998")));
        if (sl.compareTo(sp) >= 0) {
            sl = sp.subtract(r.tickSize);
        }
        BigDecimal sl2 = sl;
        if (sl2.signum() <= 0 || tp.compareTo(sp) <= 0) {
            throw new ApiException(0, 0, "Stop/target prices are not valid for " + symbol, false);
        }
        Map<String, String> p = new LinkedHashMap<>();
        p.put("symbol", symbol);
        p.put("side", "SELL");
        p.put("quantity", fmt(qty));
        p.put("aboveType", "LIMIT_MAKER");
        p.put("abovePrice", fmt(tp));
        p.put("belowType", "STOP_LOSS_LIMIT");
        p.put("belowStopPrice", fmt(sp));
        p.put("belowPrice", fmt(sl2));
        p.put("belowTimeInForce", "GTC");
        try {
            JSONObject o = new JSONObject(call("POST", "/api/v3/orderList/oco", p, true));
            Oco oco = new Oco();
            oco.listId = o.getLong("orderListId");
            JSONArray orders = o.getJSONArray("orders");
            for (int i = 0; i < orders.length(); i++) {
                oco.orderIds.add(Long.valueOf(orders.getJSONObject(i).getLong("orderId")));
            }
            return oco;
        } catch (ApiException e) {
            throw e;
        } catch (Exception e) {
            throw new ApiException(0, 0, "Unreadable OCO response: " + e.getMessage(), true);
        }
    }

    public void cancelOco(String symbol, long listId) throws ApiException {
        Map<String, String> p = new LinkedHashMap<>();
        p.put("symbol", symbol);
        p.put("orderListId", String.valueOf(listId));
        call("DELETE", "/api/v3/orderList", p, true);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public String ocoStatus(String symbol, long listId) throws ApiException {
        Map<String, String> p = new LinkedHashMap<>();
        p.put("orderListId", String.valueOf(listId));
        try {
            return new JSONObject(call("GET", "/api/v3/orderList", p, true)).getString("listOrderStatus");
        } catch (ApiException e) {
            throw e;
        } catch (Exception e2) {
            throw new ApiException(0, 0, "Bad order list response: " + e2.getMessage(), false);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public double[] sellProceeds(String symbol, List<Long> orderIds) throws ApiException {
        Rules r = rules(symbol);
        double total = 0.0d;
        int trades = 0;
        try {
            for (Long id : orderIds) {
                Map<String, String> p = new LinkedHashMap<>();
                p.put("symbol", symbol);
                p.put("orderId", String.valueOf(id));
                JSONArray arr = new JSONArray(call("GET", "/api/v3/myTrades", p, true));
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject t = arr.getJSONObject(i);
                    total += Double.parseDouble(t.getString("quoteQty"));
                    if (r.quoteAsset.equals(t.optString("commissionAsset"))) {
                        total -= Double.parseDouble(t.getString("commission"));
                    }
                    trades++;
                }
            }
            return new double[]{total, trades};
        } catch (ApiException e) {
            throw e;
        } catch (Exception e2) {
            throw new ApiException(0, 0, "Bad trades response: " + e2.getMessage(), false);
        }
    }

    private Fill parseFill(String json, Rules r) throws ApiException {
        try {
            JSONObject o = new JSONObject(json);
            BigDecimal exec = new BigDecimal(o.getString("executedQty"));
            BigDecimal quote = new BigDecimal(o.getString("cummulativeQuoteQty"));
            if (exec.signum() <= 0) {
                throw new ApiException(0, 0, "Order was not filled (status " + o.optString("status") + ").", false);
            }
            BigDecimal feeBase = BigDecimal.ZERO;
            BigDecimal feeQuote = BigDecimal.ZERO;
            JSONArray fills = o.optJSONArray("fills");
            if (fills != null) {
                for (int i = 0; i < fills.length(); i++) {
                    JSONObject f = fills.getJSONObject(i);
                    String asset = f.getString("commissionAsset");
                    BigDecimal fee = new BigDecimal(f.getString("commission"));
                    if (asset.equals(r.baseAsset)) {
                        feeBase = feeBase.add(fee);
                    } else if (asset.equals(r.quoteAsset)) {
                        feeQuote = feeQuote.add(fee);
                    }
                }
            }
            Fill f2 = new Fill();
            f2.avgPrice = quote.divide(exec, 8, RoundingMode.HALF_UP).doubleValue();
            f2.netQty = exec.subtract(feeBase);
            f2.quote = quote.doubleValue();
            f2.feeQuote = feeQuote.doubleValue();
            return f2;
        } catch (ApiException e) {
            throw e;
        } catch (Exception e2) {
            throw new ApiException(0, 0, "Unreadable order response: " + e2.getMessage(), true);
        }
    }

    static String fmt(BigDecimal v) {
        return BinanceTrader.stripZeros(v).toPlainString();
    }

    String sign(String payload) {
        try {
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(this.secret.getBytes("UTF-8"), "HmacSHA256"));
            byte[] raw = mac.doFinal(payload.getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder(raw.length * 2);
            for (byte b : raw) {
                sb.append(String.format(Locale.US, "%02x", Byte.valueOf(b)));
            }
            return sb.toString();
        } catch (Exception e) {
            throw new IllegalStateException("Could not sign request");
        }
    }

    private static String enc(String s) {
        try {
            return URLEncoder.encode(s, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            throw new IllegalStateException(e);
        }
    }

    private static String read(InputStream in) throws IOException {
        if (in == null) {
            return "";
        }
        StringBuilder sb = new StringBuilder();
        BufferedReader br = new BufferedReader(new InputStreamReader(in, "UTF-8"));
        while (true) {
            try {
                String line = br.readLine();
                if (line == null) {
                    br.close();
                    return sb.toString();
                }
                sb.append(line);
            } catch (Throwable th) {
                try {
                    br.close();
                } catch (Throwable th2) {
                    th.addSuppressed(th2);
                }
                throw th;
            }
        }
    }

    /**
     * Sends one request. Rebuilt from the original bytecode (the decompiler could not recover it):
     * signed requests carry recvWindow, timestamp and an HMAC-SHA256 signature; POST sends the query as the
     * body; a non-2xx answer throws ApiException; the "unknown" flag is true for an order-changing request
     * (POST or DELETE) whose outcome we cannot know (HTTP 5xx or a network error).
     */
    private String call(String method, String path, Map<String, String> params, boolean signed) throws ApiException {
        Map<String, String> p = new LinkedHashMap<>(params);
        if (signed) {
            p.put("recvWindow", "5000");
            p.put("timestamp", String.valueOf(serverNow()));
        }
        StringBuilder q = new StringBuilder();
        for (Map.Entry<String, String> e : p.entrySet()) {
            if (q.length() > 0) {
                q.append('&');
            }
            q.append(enc(e.getKey())).append('=').append(enc(e.getValue()));
        }
        if (signed) {
            q.append("&signature=").append(sign(q.toString()));
        }
        boolean mutating = method.equals("POST") || method.equals("DELETE");
        boolean inBody = method.equals("POST");
        java.net.HttpURLConnection c = null;
        try {
            String url = this.baseUrl + path + ((!inBody && q.length() != 0) ? "?" + q : "");
            c = (java.net.HttpURLConnection) new java.net.URL(url).openConnection();
            c.setRequestMethod(method);
            c.setConnectTimeout(12000);
            c.setReadTimeout(12000);
            c.setRequestProperty("User-Agent", "Neuraxon-Android/2.0");
            if (signed) {
                c.setRequestProperty("X-MBX-APIKEY", this.apiKey);
            }
            if (inBody) {
                byte[] body = q.toString().getBytes("UTF-8");
                c.setDoOutput(true);
                c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                c.setFixedLengthStreamingMode(body.length);
                java.io.OutputStream os = c.getOutputStream();
                try {
                    os.write(body);
                } finally {
                    os.close();
                }
            }
            int code = c.getResponseCode();
            if (code < 200 || code >= 300) {
                String text = read(c.getErrorStream());
                int bcode = 0;
                String msg = "HTTP " + code;
                try {
                    JSONObject j = new JSONObject(text);
                    bcode = j.optInt("code", 0);
                    msg = j.optString("msg", msg);
                } catch (Exception ignored) {
                    // body was not JSON: keep the plain HTTP message
                }
                throw new ApiException(code, bcode, msg + " (code " + bcode + ")", mutating && code >= 500);
            }
            return read(c.getInputStream());
        } catch (ApiException e) {
            throw e;
        } catch (IOException e) {
            throw new ApiException(0, 0, "Network error: " + e.getMessage(), mutating);
        } finally {
            if (c != null) {
                c.disconnect();
            }
        }
    }

    static java.math.BigDecimal stripZeros(java.math.BigDecimal v) {
        return v.signum() == 0 ? java.math.BigDecimal.ZERO : v.stripTrailingZeros();
    }
}
