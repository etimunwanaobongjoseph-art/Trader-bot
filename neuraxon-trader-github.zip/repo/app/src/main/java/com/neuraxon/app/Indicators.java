package com.neuraxon.app;

import java.util.List;

/** Small indicator helpers over the tail of a candle list. All use only candles up to the last one. */
final class Indicators {
    private Indicators() {}

    static double sma(List<NeuraxonEngine.Candle> h, int len) {
        int n = h.size();
        double s = 0;
        for (int i = n - len; i < n; i++) s += h.get(i).close;
        return s / len;
    }

    static double ema(List<NeuraxonEngine.Candle> h, int len) {
        int n = h.size();
        int start = Math.max(0, n - len * 4);
        double a = 2.0 / (len + 1), e = h.get(start).close;
        for (int i = start + 1; i < n; i++) e = a * h.get(i).close + (1 - a) * e;
        return e;
    }

    /** Simple RSI over the last len changes (average gain / average loss). */
    static double rsi(List<NeuraxonEngine.Candle> h, int len) {
        int n = h.size();
        double g = 0, l = 0;
        for (int i = n - len; i < n; i++) {
            double d = h.get(i).close - h.get(i - 1).close;
            if (d > 0) g += d; else l -= d;
        }
        if (l == 0) return g == 0 ? 50 : 100;
        double rs = g / l;
        return 100 - 100 / (1 + rs);
    }

    /** Kaufman efficiency ratio: near 0 = choppy/ranging, near 1 = straight trend. */
    static double efficiency(List<NeuraxonEngine.Candle> h, int len) {
        int n = h.size();
        double net = Math.abs(h.get(n - 1).close - h.get(n - 1 - len).close), path = 0;
        for (int i = n - len; i < n; i++) path += Math.abs(h.get(i).close - h.get(i - 1).close);
        return path == 0 ? 0 : net / path;
    }

    /** Highest high of the len candles BEFORE the last one. */
    static double highestBefore(List<NeuraxonEngine.Candle> h, int len) {
        int n = h.size();
        double m = -Double.MAX_VALUE;
        for (int i = n - 1 - len; i < n - 1; i++) m = Math.max(m, h.get(i).high);
        return m;
    }

    static double lowestBefore(List<NeuraxonEngine.Candle> h, int len) {
        int n = h.size();
        double m = Double.MAX_VALUE;
        for (int i = n - 1 - len; i < n - 1; i++) m = Math.min(m, h.get(i).low);
        return m;
    }

    static double avgVolumeBefore(List<NeuraxonEngine.Candle> h, int len) {
        int n = h.size();
        double s = 0;
        for (int i = n - 1 - len; i < n - 1; i++) s += h.get(i).volume;
        return s / len;
    }
}
