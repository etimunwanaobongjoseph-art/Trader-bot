package com.neuraxon.app;

import java.util.ArrayList;
import java.util.List;

/* loaded from: classes2.dex */
final class NeuraxonEngine {
    private static final int CONTROL = 90;
    private static final int INPUT = 164;
    private static final int K = 16;
    private static final int N = 1024;
    private static final int OUTPUT = 770;
    private double lastPred;
    private float[] lastSnapshot;
    private long rng;
    private final float[] x = new float[N];
    private final float[] inW = new float[INPUT];
    private final float[] weights = new float[16384];
    private final float[] readout = new float[OUTPUT];
    private final int[] links = new int[16384];
    private Double prevClose = null;
    private double prevVol = 0.001d;
    private final List<Candle> candles = new ArrayList();
    volatile double minConfidence = 0.25d;

    /* loaded from: classes2.dex */
    static final class Candle {
        double close;
        double high;
        double low;
        double open;
        long time;
        double volume;

        /* JADX INFO: Access modifiers changed from: package-private */
        public Candle(long t, double o, double h, double l, double c, double v) {
            this.time = t;
            this.open = o;
            this.high = h;
            this.low = l;
            this.close = c;
            this.volume = v;
        }
    }

    /* loaded from: classes2.dex */
    static final class Result {
        final double atr;
        final double confidence;
        final String signal;

        Result(String s, double c, double a) {
            this.signal = s;
            this.confidence = c;
            this.atr = a;
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public NeuraxonEngine(int seed) {
        this.rng = seed;
        for (int i = 0; i < N; i++) {
            for (int k = 0; k < K; k++) {
                int z = (i * K) + k;
                this.links[z] = (int) (next() * 1024.0d);
                this.weights[z] = (float) (signed() * 0.45d);
            }
        }
        for (int i2 = 0; i2 < INPUT; i2++) {
            this.inW[i2] = (float) signed();
        }
    }

    private double next() {
        this.rng = ((this.rng * 1664525) + 1013904223) & 4294967295L;
        return this.rng / 4.294967296E9d;
    }

    private double signed() {
        return (next() * 2.0d) - 1.0d;
    }

    private void learn(double target) {
        if (this.lastSnapshot == null) {
            return;
        }
        double norm = 1.0E-6d;
        for (float v : this.lastSnapshot) {
            norm += v * v;
        }
        double err = target - this.lastPred;
        for (int j = 0; j < OUTPUT; j++) {
            float[] fArr = this.readout;
            fArr[j] = fArr[j] + ((float) (((0.05d * err) * this.lastSnapshot[j]) / norm));
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public Result onClosedCandle(Candle c) {
        this.candles.add(c);
        if (this.candles.size() > 500) {
            this.candles.remove(0);
        }
        if (this.prevClose != null) {
            learn(Math.max(-1.0d, Math.min(1.0d, (((c.close - this.prevClose.doubleValue()) / this.prevClose.doubleValue()) / this.prevVol) / 2.0d)));
        }
        this.prevClose = Double.valueOf(c.close);
        if (this.candles.size() < 50) {
            return new Result("WARMING UP", 0.0d, 0.0d);
        }
        double[] closes = new double[this.candles.size()];
        for (int i = 0; i < closes.length; i++) {
            closes[i] = this.candles.get(i).close;
        }
        int i2 = closes.length;
        double last = closes[i2 - 1];
        double[] rets = new double[20];
        double mean = 0.0d;
        for (int i3 = 0; i3 < 20; i3++) {
            double a = closes[((closes.length - 20) + i3) - 1];
            double b = closes[(closes.length - 20) + i3];
            rets[i3] = (b - a) / a;
            mean += rets[i3];
        }
        double mean2 = mean / 20.0d;
        double variance = 0.0d;
        for (double r : rets) {
            variance += (r - mean2) * (r - mean2);
        }
        double vol = Math.sqrt(variance / 20.0d);
        if (vol == 0.0d || Double.isNaN(vol)) {
            vol = 1.0E-6d;
        }
        double vol2 = vol;
        this.prevVol = vol2;
        double avgVol = 0.0d;
        for (int i4 = this.candles.size() - 20; i4 < this.candles.size(); i4++) {
            avgVol += this.candles.get(i4).volume;
        }
        double avgVol2 = avgVol / 20.0d;
        if (avgVol2 == 0.0d) {
            avgVol2 = 1.0d;
        }
        double[] f = {clip(ret(closes, 1) / vol2), clip(ret(closes, 5) / (Math.sqrt(5.0d) * vol2)), clip(ret(closes, 20) / (Math.sqrt(20.0d) * vol2)), (rsi(closes) - 50.0d) / 25.0d, clip(((emaTail(closes, 12) - emaTail(closes, 26)) / last) / vol2), clip(100.0d * vol2), clip((c.volume / avgVol2) - 1.0d), 1.0d};
        float[] nx = new float[N];
        int i5 = 0;
        for (int i6 = N; i5 < i6; i6 = N) {
            double sum = 0.0d;
            int k = 0;
            while (k < K) {
                int z = (i5 * K) + k;
                sum += this.weights[z] * this.x[this.links[z]];
                k++;
                closes = closes;
            }
            double[] closes2 = closes;
            if (i5 < INPUT) {
                sum += this.inW[i5] * f[i5 % 8];
            }
            nx[i5] = (float) ((this.x[i5] * 0.7d) + (Math.tanh(sum) * 0.3d));
            i5++;
            closes = closes2;
        }
        System.arraycopy(nx, 0, this.x, 0, N);
        double out = 0.0d;
        int j = 0;
        while (j < OUTPUT) {
            out += this.readout[j] * this.x[j + 254];
            j++;
            nx = nx;
        }
        float[] nx2 = nx;
        double pred = Math.tanh(out);
        double gate = 0.0d;
        int j2 = 0;
        while (j2 < CONTROL) {
            gate += Math.abs(this.x[j2 + INPUT]);
            j2++;
            out = out;
        }
        double variance2 = variance;
        double confidence = Math.abs(pred) * ((Math.min(1.0d, (gate / 90.0d) * 2.0d) * 0.5d) + 0.5d);
        this.lastSnapshot = new float[OUTPUT];
        System.arraycopy(this.x, 254, this.lastSnapshot, 0, OUTPUT);
        this.lastPred = pred;
        double atrValue = 0.0d;
        int i7 = this.candles.size() - 14;
        while (i7 < this.candles.size()) {
            Candle q = this.candles.get(i7);
            Candle p = this.candles.get(i7 - 1);
            atrValue += Math.max(q.high - q.low, Math.max(Math.abs(q.high - p.close), Math.abs(q.low - p.close)));
            i7++;
            nx2 = nx2;
            rets = rets;
            mean2 = mean2;
            variance2 = variance2;
            pred = pred;
        }
        double atrValue2 = atrValue / 14.0d;
        String signal = confidence < this.minConfidence ? "HOLD" : pred > 0.0d ? "BUY" : "SELL";
        return new Result(signal, confidence, atrValue2);
    }

    private static double ret(double[] c, int k) {
        return (c[c.length - 1] - c[(c.length - 1) - k]) / c[(c.length - 1) - k];
    }

    private static double clip(double v) {
        return Math.max(-3.0d, Math.min(3.0d, v));
    }

    private static double emaTail(double[] a, int p) {
        int start = Math.max(0, a.length - p);
        double e = a[start];
        double alpha = 2.0d / (p + 1);
        for (int i = start + 1; i < a.length; i++) {
            e = (a[i] * alpha) + ((1.0d - alpha) * e);
        }
        return e;
    }

    private static double rsi(double[] c) {
        double g = 0.0d;
        double l = 0.0d;
        for (int i = c.length - 14; i < c.length; i++) {
            double d = c[i] - c[i - 1];
            if (d >= 0.0d) {
                g += d;
            } else {
                l -= d;
            }
        }
        if (l == 0.0d) {
            return 100.0d;
        }
        return 100.0d - (100.0d / ((g / l) + 1.0d));
    }
}
