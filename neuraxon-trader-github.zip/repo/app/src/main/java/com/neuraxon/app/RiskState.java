package com.neuraxon.app;

import java.util.HashMap;
import java.util.Map;

/** Rules 3, 4 and the loss cooldown of rule 6. Day = UTC day. Amounts are in account currency. */
final class RiskState {
    private final Params p;
    private long dayKey = Long.MIN_VALUE;
    int tradesToday;
    double dayPnl;
    double dayStartEquity;
    private final Map<String, Long> cooldownUntil = new HashMap<>();

    private double absLoss = -1, absProfit = -1;   // >0 overrides the % limits (live mode, USDT)

    RiskState(Params p) { this.p = p; }

    RiskState(Params p, double absLoss, double absProfit) { this.p = p; this.absLoss = absLoss; this.absProfit = absProfit; }

    private void roll(long timeMs, double equityNow) {
        long k = Math.floorDiv(timeMs, 86_400_000L);
        if (k != dayKey) { dayKey = k; tradesToday = 0; dayPnl = 0; dayStartEquity = equityNow; }
    }

    /** Returns null when a new entry is allowed, otherwise the reason it is not. */
    String blockReason(String sym, long timeMs, double equityNow) {
        roll(timeMs, equityNow);
        Long cd = cooldownUntil.get(sym);
        if (cd != null && timeMs < cd) return "cooling down after a loss";
        if (tradesToday >= p.maxTradesPerDay) return "max trades today";
        double lossLimit = absLoss > 0 ? absLoss : p.dayLossPct / 100.0 * dayStartEquity;
        if (dayPnl <= -lossLimit) return "daily loss limit hit";
        double profitStop = absProfit > 0 ? absProfit : (p.dayProfitStopPct > 0 ? p.dayProfitStopPct / 100.0 * dayStartEquity : -1);
        if (profitStop > 0 && dayPnl >= profitStop) return "daily profit stop hit";
        return null;
    }

    void onEntry(long timeMs, double equityNow) { roll(timeMs, equityNow); tradesToday++; }

    void onClose(String sym, double pnl, long timeMs, double equityNow) {
        roll(timeMs, equityNow);
        dayPnl += pnl;
        if (pnl < 0) cooldownUntil.put(sym, timeMs + p.cooldownCandles * 3_600_000L);
    }
}
