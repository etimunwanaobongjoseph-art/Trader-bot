package com.neuraxon.app;

/** Which brain feeds the strategies. BOTH = the two brains must agree. */
enum BrainMode {
    ORIGINAL("Original brain"),
    BPP9000("BPP-9000 brain"),
    BOTH("Both must agree");

    final String label;
    BrainMode(String label) { this.label = label; }

    static BrainMode fromName(String s, BrainMode dflt) {
        try { return valueOf(s); } catch (Exception e) { return dflt; }
    }
}
