package com.neuraxon.app;

/** The four entry strategies. Rules 1 to 6 are identical for all of them. */
enum Strategy {
    BRAIN_ONLY("1 Brain only"),
    TREND_BRAIN("2 Trend + brain"),
    BREAKOUT("3 Breakout"),
    MEAN_REVERSION("4 Mean reversion");

    final String label;
    Strategy(String label) { this.label = label; }

    static Strategy fromName(String s, Strategy dflt) {
        try { return valueOf(s); } catch (Exception e) { return dflt; }
    }
}
