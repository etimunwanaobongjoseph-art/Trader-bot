# Neuraxon 1.3.0: two brains, four strategies, six rules

Android app that watches five Binance USDT pairs on 1-hour candles. Paper mode by default; Binance testnet and real money are optional and must be armed by hand.

## What changed from 1.2.0
- **Two brains that work together.** The original learning network and the Qubic BPP-9000 network. Brain mode: *Original*, *BPP-9000*, or *Both must agree* (default).
- **Four strategies**, all behind the same six rules: 1 Brain only, 2 Trend + brain, 3 Breakout, 4 Mean reversion.
- **Walk-forward backtest** with fees and slippage: settings tuned on the first 60% of history, judged on the last 40%.
- **Self-checks** you can run anywhere with a JDK: `sh core-tests/run.sh`.

## The six rules (identical for every strategy)
| # | Rule | Setting |
|---|------|---------|
| 1 | Brain must give the same call for N closed candles in a row | default 2 |
| 2 | Long only above / short only below a long SMA | default 100 |
| 3 | Max new trades per UTC day (all pairs together) | default 3 |
| 4 | No new trades after losing X% of day-start equity; optional profit stop | 3% / off |
| 5 | Stop on every trade (ATR multiple) with reward:risk target; optional trailing stop | 1.5 x ATR, 2:1 |
| 6 | Skip quiet markets (ATR below X% of price) and pause after a loss | 0.20% / 3 candles |

Live mode uses the existing USDT session loss halt as its daily loss limit. Trailing stops work in paper and backtest only: live orders keep a fixed exchange-side stop/target (OCO).

## The BPP-9000 brain: read this
- The file is a closed 1,024-neuron ternary network. **It takes no market input.** It steps its own state and its output is a fixed up/down sequence. The file does not say which pair or which tick lines up with which hour.
- Its published 65.19% is measured **inside its own training window** (2025-11-18 07:00 to 2026-11-23 05:00 UTC). On new data a network like this should score about 50%.
- The app therefore **checks the alignment on real candles inside the training window** (it must reproduce a hit rate far above chance, z of 5 or more). A pair that fails is not traded with this brain. The result and the hit rate since training ended are shown on the main screen.
- **Real-money entries with BPP-9000 are blocked** until it has 500+ out-of-sample hours at 54% or better. Paper and testnet are not blocked.
- Backtest rows that use it over the training period are labelled IN-SAMPLE and prove nothing.

## Build
1. Create a GitHub repo, push this folder.
2. Actions > *Build APK*. It runs the core self-tests, then builds `app-debug.apk` (artifact `neuraxon-debug-apk`).
3. Or open the folder in Android Studio (Gradle 8.9, JDK 17, compileSdk 35).

## Replacing the BPP brain later
`python3 tools/convert_brain.py brains/<new>.json app/src/main/assets/bpp9000-brain.txt` and rebuild. The original learning brain is always kept and selectable.

## How this project was recovered (be aware)
Only a compiled debug APK was available. The source was decompiled with jadx; three regions did not decompile and were rewritten from the bytecode: the Binance request/signing method (`BinanceTrader.call`), the order-list placement, and the live order-opening routine. The rest is decompiler output and may contain small artifacts. Review `BinanceTrader.java` and the live code in `MainActivity.java` before arming real money. This has not been run on a device.

## Honest limits
- Fees and slippage beat many classic rules on hourly crypto candles. No strategy here is shown to be profitable.
- Twelve strategy/brain rows are compared; with that many, one will look good by chance. The report says so.
- Past results do not predict future results. Use paper mode first.
