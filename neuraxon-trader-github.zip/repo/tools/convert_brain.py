#!/usr/bin/env python3
"""Convert a Qubic BPP-9000 brain JSON (qc-bpp9000-brain-v1) into the compact
text asset the app reads. Usage: python3 tools/convert_brain.py brains/<file>.json app/src/main/assets/bpp9000-brain.txt"""
import json, sys
src, dst = sys.argv[1], sys.argv[2]
d = json.load(open(src))
assert d["format"] == "qc-bpp9000-brain-v1", "unexpected format"
nodes = sorted(d["nodes"], key=lambda n: n["id"])
assert [n["id"] for n in nodes] == list(range(len(nodes)))
with open(dst, "w") as f:
    f.write("BPP9000 1\n")
    f.write(f"hash {d['hash']}\nepoch {d['epoch']}\n")
    f.write(f"control {d['control']}\noutput {d['output']}\n")
    f.write(f"start {d['task']['start']}\nhours {d['task']['hours']}\n")
    f.write(f"shift {d['score']['shift']}\nclaimed {d['score']['accuracy']}\n")
    f.write(f"nodes {len(nodes)}\n")
    for n in nodes:
        s = n["sources"]; assert len(s) == 3 and len(n["lut"]) == 27
        f.write(f"{n['initialState']} {s[0]} {s[1]} {s[2]} {''.join(map(str, n['lut']))}\n")
print("wrote", dst, len(nodes), "nodes")
