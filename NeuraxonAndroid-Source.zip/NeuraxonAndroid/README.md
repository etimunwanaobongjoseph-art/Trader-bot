# Neuraxon Android v1.4

A phone app that watches the market, runs the **Neuraxon 1,024-neuron brain** on every closed hourly candle, and either simulates trades (paper) or places them on Binance (Testnet or real money). The brain is unchanged from earlier versions (`NeuraxonEngine.java`, with the original reference in `assets/neuraxon-mini-bot.ts`).

## How it is built (five layers)
| Layer | File | Job |
|---|---|---|
| Market Data Engine | `MarketData`, `Exchange` | Price, candles, volume and volatility from **Binance** or **MEXC**; tries several hosts |
| Neuraxon Brain | `NeuraxonEngine` | Learns candle by candle; outputs a lean up/down and a confidence |
| Signal Intelligence | `SignalEngine` | BUY / SELL / WAIT with a reason: confidence threshold, quiet-market filter, cooldown after a loss |
| Risk Management | `RiskManager` | Stop, target or trailing stop, position size, daily loss limits |
| Trading Execution | `PaperBroker`, `LiveBroker`, `BinanceTrader` | Paper account with fees; Binance Spot (long-only) with exchange-side exits |

`BotCore` connects them and lives as long as the app process, so the bot keeps running when you leave the screen. `MainActivity` only displays state.

## The screen
- **Header:** mode chip (PAPER green, TESTNET blue, LIVE red). Tap it to change mode.
- **Account card:** simulated balance, today's paper P/L, open trades, win rate.
- **START / STOP:** the active one is solid (green RUNNING, red STOPPED).
- **Toggles** (solid with a tick when on): **Trailing** stop, **Background** running, **Alerts**.
- **Tabs:** MARKETS (price, signal, confidence, ATR, volume, open trades), HISTORY (every closed trade), LIVE (arming, daily P/L, gate, FLATTEN), LOG (events and the explanations).
- **SETTINGS** and **BACKTEST** at the bottom.

## Features
- **Pair selector:** BTC/USDT only by default. Tick other pairs in Settings. Each pair keeps its own brain seed, so choosing pairs does not change a pair's brain.
- **Exchanges:** Binance (data, paper, Testnet, live). **MEXC: market data and paper only** (it has no testnet, and I have not confirmed it supports exchange-side stop orders).
- **Trade history:** entry, exit, result, reason, confidence, mode. Kept across restarts (last 300).
- **Paper fees:** 0.10% per side by default (Settings), so paper results are not flattering.
- **Paper account is kept** across restarts: balance, open trades and history. Reset it from the HISTORY tab.
- **Alerts:** a notification when a trade opens or closes or a limit is hit.
- **Background running:** a foreground service keeps the process alive. It uses the "specialUse" type because the "dataSync" type is limited to 6 hours per 24 on current Android. The app asks once to be excluded from battery optimisation. Some phone brands still stop background apps; if so, allow "autostart" / "no restrictions" for Neuraxon in the phone's settings.
- **Trailing stop (optional):** no fixed target; the stop follows the best price and never moves back. Live uses Binance's own trailing-stop order.
- **Max daily loss:** paper in % of the account, live in USDT. Resets each day.
- **Validation gate:** real money stays **locked** until paper trading or the Backtest passes your bar (default: 30+ trades, net profit, profit factor 1.3+). Testnet is never gated. You can turn the gate off in Settings.
- **Backtest:** replays about 40 days of real candles with fees, long-only (what live does) and long+short (paper), by confidence level and by exit style.
- **Live positions are remembered** across restarts. After a restart, add your API keys and arm the same mode again; the app then picks up the exchange-side exits it left behind.

## Live trading
1. Settings: paste a **trade-only** Binance API key and secret (withdrawals off). Keys live in memory only and are cleared when the app closes.
2. Tap the mode chip, pick **Testnet** first (keys from testnet.binance.vision). Real money needs the gate to be open and typing `LIVE`.
3. Spot, **long-only**: BUY opens, SELL closes a position the app opened. Every entry gets an exchange-side exit (OCO, or a trailing stop). If the exit cannot be placed, the position is sold at once.
4. Limits: max 3 open, max per trade, daily loss limit, stale-candle guard, FLATTEN button, halt if an order outcome is unknown.

## How the bot decides, in plain words
Every hour, when a candle closes, the brain gives a lean and a confidence. Below the min confidence (default 0.25) the answer is WAIT. It can sit on WAIT for a long time. That is normal. A stop-loss caps each loss; fees are about 0.1% per side.

## Limits you should know about
- **No proven edge.** On random data the same logic loses about the fees whenever it trades. A good backtest is not proof. Nothing here is financial advice.
- Exits are checked on candle closes in paper and backtest; live exits are on the exchange.
- Paper trades ignore slippage and assume fills at the candle's stop/target/close.
- A stop-limit or trailing-stop can fill worse than its level in a fast drop.
- Fees paid in BNB are not counted in live P/L.
- Binance may refuse some countries (HTTP 451). If no data host works, set Android Settings > Network > Private DNS to `dns.google`, or use a VPN.
- The app only sees positions it opened. Check Binance for anything else.

## What was tested, and what was not
Tested on a desktop JVM with stand-in Android classes and mock exchanges: request signing (including Binance's documented example), order, OCO and trailing flows, fees, daily limits, restart restore (including a bug found and fixed in replaying candles after a restart), host fallback, MEXC candle format and `60m` interval, the validation gate, the backtester (with a no-edge calibration on random data), and the screen code (every tab, button, and dialog).
**Not tested:** the real Android build, the foreground service and notifications on a real phone, and any real Binance or MEXC server (including Testnet). Treat the first Testnet run as the real test.

## Build on GitHub Actions from a phone
Upload this entire project as a ZIP named `NeuraxonAndroid-Source.zip` to the repository root. The repository's workflow extracts it and runs `gradle -p NeuraxonAndroid assembleDebug`. Download the `neuraxon-debug-apk` artifact from the Actions run. Uninstall the old app first: every build is signed with a new debug key.
