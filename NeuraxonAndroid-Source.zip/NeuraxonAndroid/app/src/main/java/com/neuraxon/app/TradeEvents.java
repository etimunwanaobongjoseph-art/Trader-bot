package com.neuraxon.app;

/** How the brokers tell the rest of the app (log, notifications, screen) what just happened. */
interface TradeEvents {
    void onTrade(String title, String text); // a trade opened/closed or a limit was hit: alert-worthy
    void onInfo(String line);                // routine event for the log
}
