package com.neuraxon.app;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.List;

/** Where market data comes from. Binance supports live trading in this app; MEXC is market data + paper only for now. */
abstract class Exchange {
    static final long CANDLE_MS = 3600000L; // 1-hour candles

    static Exchange of(String id) { return "MEXC".equals(id) ? new MexcExchange() : new BinanceExchange(); }

    abstract String id();
    abstract String label();
    abstract String[] hosts();                        // market-data hosts, tried in order (array is mutable on purpose, for tests)
    abstract String klinesUrl(String host, String symbol, int limit);
    abstract boolean liveTrading();

    /** Candle rows: [openTime, open, high, low, close, volume, closeTime, ...]. Closed = open time + 1h has passed. */
    List<NeuraxonEngine.Candle> parseClosed(String json, long now) throws Exception {
        JSONArray arr = new JSONArray(json);
        List<NeuraxonEngine.Candle> out = new ArrayList<>();
        for (int i = 0; i < arr.length(); i++) {
            JSONArray k = arr.getJSONArray(i);
            long open = k.getLong(0);
            if (open + CANDLE_MS > now) continue; // still forming
            out.add(new NeuraxonEngine.Candle(open, k.getDouble(1), k.getDouble(2), k.getDouble(3), k.getDouble(4), k.getDouble(5)));
        }
        return out;
    }

    /** Close of the newest row, even if that candle is still forming (a live price). */
    double lastPrice(String json) throws Exception {
        JSONArray arr = new JSONArray(json);
        if (arr.length() == 0) throw new Exception("empty candle list");
        return arr.getJSONArray(arr.length() - 1).getDouble(4);
    }
}

final class BinanceExchange extends Exchange {
    private final String[] hosts = {"https://data-api.binance.vision", "https://api.binance.com", "https://api1.binance.com",
            "https://api2.binance.com", "https://api3.binance.com", "https://api4.binance.com", "https://api-gcp.binance.com"};
    String id() { return "BINANCE"; }
    String label() { return "Binance"; }
    String[] hosts() { return hosts; }
    String klinesUrl(String host, String symbol, int limit) { return host + "/api/v3/klines?symbol=" + symbol + "&interval=1h&limit=" + limit; }
    boolean liveTrading() { return true; }
}

/** MEXC spot v3. Same candle layout (8 fields); the 1-hour interval is called "60m". Market data only in this build. */
final class MexcExchange extends Exchange {
    private final String[] hosts = {"https://api.mexc.com"};
    String id() { return "MEXC"; }
    String label() { return "MEXC"; }
    String[] hosts() { return hosts; }
    String klinesUrl(String host, String symbol, int limit) { return host + "/api/v3/klines?symbol=" + symbol + "&interval=60m&limit=" + limit; }
    boolean liveTrading() { return false; }
}
