package com.neuraxon.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

/**
 * The bot. It lives for the whole life of the app process (not the screen), so it keeps running when you leave the app.
 *
 *   Market Data Engine -> Neuraxon Brain -> Signal Intelligence -> Risk Management -> Trading Execution
 *   (MarketData)          (NeuraxonEngine)   (SignalEngine)         (RiskManager)      (PaperBroker / LiveBroker)
 *
 * All trading work happens on one worker thread. The screen only reads state and gets a nudge when something changes.
 */
final class BotCore implements TradeEvents {
    interface Listener { void onChanged(); }

    static final class Row {
        String symbol, action = "WAIT", reason = "", error = "";
        double price, conf, atrPct, volRatio;
    }

    static final class ArmResult {
        final boolean ok;
        final String text;
        ArmResult(boolean ok, String text) { this.ok = ok; this.text = text; }
    }

    static final class Gate {
        final boolean ok;
        final String text;
        Gate(boolean ok, String text) { this.ok = ok; this.text = text; }
    }

    interface ArmCallback { void done(ArmResult r); }
    interface TextCallback { void done(String text); }

    private static volatile BotCore instance;

    static BotCore get(Context ctx) {
        if (instance == null) {
            synchronized (BotCore.class) {
                if (instance == null) {
                    instance = new BotCore(ctx.getApplicationContext() != null ? ctx.getApplicationContext() : ctx);
                    instance.resumeIfNeeded();
                }
            }
        }
        return instance;
    }

    final Context ctx;
    final BotSettings s = new BotSettings();
    final TradeLog log = new TradeLog();
    final SignalEngine signals;
    final RiskManager risk;
    final PaperBroker paper;
    final LiveBroker live;
    final Notifier notifier;
    volatile MarketData market;

    private final Map<String, NeuraxonEngine> engines = new ConcurrentHashMap<>();
    private final Map<String, Long> lastProcessed = new ConcurrentHashMap<>();
    private final Map<String, Integer> candleCounts = new ConcurrentHashMap<>();
    private final Map<String, Row> rows = new ConcurrentHashMap<>();
    private final List<String> events = new ArrayList<>();

    volatile boolean running = false;
    volatile String dataStatus = "STOPPED";    // STOPPED, CONNECTING, CONNECTED, NO DATA
    volatile String lastError = "";
    volatile int processed = 0;
    volatile String apiKey = "", apiSecret = "";   // in memory only, never saved
    private volatile BinanceTrader pending;
    String liveUrl = BinanceTrader.LIVE_URL, testnetUrl = BinanceTrader.TESTNET_URL; // overridable in tests

    private final ScheduledExecutorService worker = Executors.newSingleThreadScheduledExecutor();
    private ScheduledFuture<?> job;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private volatile Listener listener;

    BotCore(Context ctx) {
        this.ctx = ctx;
        s.load(ctx);
        signals = new SignalEngine(s);
        risk = new RiskManager(s);
        paper = new PaperBroker(s, risk, log, signals, this);
        live = new LiveBroker(s, risk, log, signals, this);
        notifier = new Notifier(ctx);
        market = new MarketData(Exchange.of(s.exchange));
        loadState();
    }

    void setListener(Listener l) { listener = l; }

    private void changed() {
        Listener l = listener;
        if (l != null) ui.post(new Runnable() { @Override public void run() { l.onChanged(); } });
    }

    // ------------------------------------------------------------------ persistence

    private void loadState() {
        SharedPreferences sp = ctx.getSharedPreferences(BotSettings.PREFS, Context.MODE_PRIVATE);
        log.load(sp.getString("log", ""));
        try { paper.equity = Double.parseDouble(sp.getString("paperEquity", String.valueOf(PaperBroker.START))); } catch (Exception ignored) { /* keep default */ }
        paper.loadPositions(sp.getString("paperPos", ""));
        live.loadPositions(sp.getString("livePos", ""));
    }

    void save() {
        s.save(ctx);
        ctx.getSharedPreferences(BotSettings.PREFS, Context.MODE_PRIVATE).edit()
                .putString("log", log.serialize())
                .putString("paperEquity", String.valueOf(paper.equity))
                .putString("paperPos", paper.serializePositions())
                .putString("livePos", live.serializePositions()).apply();
    }

    // ------------------------------------------------------------------ events (log + alerts)

    private void addEvent(String line) {
        String stamped = new SimpleDateFormat("d MMM HH:mm:ss", Locale.getDefault()).format(new Date()) + "  " + line;
        synchronized (events) {
            events.add(0, stamped);
            while (events.size() > 80) events.remove(events.size() - 1);
        }
    }

    List<String> eventLines() { synchronized (events) { return new ArrayList<>(events); } }

    @Override public void onTrade(String title, String text) {
        addEvent(title + ": " + text);
        if (s.alerts) notifier.trade(title, text);
        changed();
    }

    @Override public void onInfo(String line) {
        addEvent(line);
        changed();
    }

    // ------------------------------------------------------------------ start / stop

    void start() {
        if (running) return;
        running = true;
        s.wasRunning = true;
        dataStatus = "CONNECTING";
        addEvent("Bot started: " + market.exchange.label() + ", " + pairsText() + ", 1h candles.");
        save();
        if (s.background) BotService.start(ctx);
        job = worker.scheduleWithFixedDelay(new Runnable() { @Override public void run() { safeTick(); } }, 0, 60, TimeUnit.SECONDS);
        changed();
    }

    void stop() {
        if (!running) return;
        running = false;
        s.wasRunning = false;
        if (job != null) job.cancel(false);
        dataStatus = "STOPPED";
        addEvent("Bot stopped.");
        save();
        BotService.stop(ctx);
        changed();
    }

    /** After Android restarted the process, carry on where we left off. */
    void resumeIfNeeded() {
        if (s.wasRunning && !running) {
            running = true;
            dataStatus = "CONNECTING";
            addEvent("Bot resumed after the app restarted.");
            job = worker.scheduleWithFixedDelay(new Runnable() { @Override public void run() { safeTick(); } }, 0, 60, TimeUnit.SECONDS);
            changed();
        }
    }

    private void safeTick() {
        try { tick(); } catch (Throwable t) { addEvent("Internal error: " + t); changed(); }
    }

    // ------------------------------------------------------------------ the cycle

    Set<String> symbolsToProcess() {
        Set<String> set = new LinkedHashSet<>(s.activeSymbols());
        set.addAll(paper.positions.keySet());   // un-ticked pairs with an open trade still need candles to be managed
        set.addAll(live.positions.keySet());
        return set;
    }

    private NeuraxonEngine engineFor(String symbol) {
        NeuraxonEngine e = engines.get(symbol);
        if (e == null) {
            e = new NeuraxonEngine(1337 + BotSettings.indexOf(symbol) * 97); // same brain and seed per pair as before
            e.minConfidence = s.minConfidence;
            engines.put(symbol, e);
        }
        return e;
    }

    /** One pass: download, feed the brain, decide, manage trades. Safe to call directly (tests do). */
    void tick() {
        if (!running) return;
        boolean any = false, allDown = false;
        String error = "";
        boolean testnetData = live.armed && !live.real;
        for (String sym : symbolsToProcess()) {
            if (allDown) { rows.put(sym, errorRow(sym, error)); continue; }
            try {
                processSnap(sym, market.fetch(sym, 100, testnetData));
                any = true;
            } catch (MarketData.DataUnavailable e) {
                error = e.getMessage();
                allDown = true;
                rows.put(sym, errorRow(sym, error));
            } catch (Exception e) {
                error = String.valueOf(e.getMessage());
                rows.put(sym, errorRow(sym, error));
            }
        }
        live.reconcile();
        dataStatus = any ? "CONNECTED" : "NO DATA";
        lastError = any ? "" : error;
        notifier.updateOngoing(summaryLine());
        save();
        changed();
    }

    private Row errorRow(String sym, String error) {
        Row r = rows.get(sym);
        Row n = new Row();
        n.symbol = sym;
        n.error = error;
        if (r != null) { n.price = r.price; n.action = r.action; n.conf = r.conf; }
        return n;
    }

    private void processSnap(String sym, MarketData.Snap snap) {
        NeuraxonEngine eng = engineFor(sym);
        eng.minConfidence = s.minConfidence;
        long newest = lastProcessed.containsKey(sym) ? lastProcessed.get(sym) : -1;
        boolean warmup = newest < 0, selected = s.pair(sym);
        long now = System.currentTimeMillis();
        Row row = rows.get(sym);
        if (row == null) { row = new Row(); row.symbol = sym; }
        for (NeuraxonEngine.Candle c : snap.closed) {
            if (c.time <= newest) continue;
            NeuraxonEngine.Result r = eng.onClosedCandle(c);
            SignalEngine.Decision d = signals.decide(sym, r, snap.atrPct, c.time);
            newest = c.time;
            processed++;
            candleCounts.put(sym, (candleCounts.containsKey(sym) ? candleCounts.get(sym) : 0) + 1);
            boolean fresh = now - (c.time + Exchange.CANDLE_MS) <= LiveBroker.MAX_CANDLE_AGE_MS; // never trade on an old candle
            paper.onCandle(sym, c, r, d, !warmup && fresh, selected);
            if (!warmup && fresh && live.armed) live.onSignal(sym, c, r, d, selected);
            row.action = "WARMING UP".equals(r.signal) ? "WARMING UP" : d.action;
            row.reason = d.reason;
            row.conf = r.confidence;
        }
        if (newest >= 0) lastProcessed.put(sym, newest);
        row.price = snap.price;
        row.atrPct = snap.atrPct;
        row.volRatio = snap.volRatio;
        row.error = "";
        rows.put(sym, row);
    }

    // ------------------------------------------------------------------ what the screen reads

    Row row(String sym) { return rows.get(sym); }
    int candles(String sym) { return candleCounts.containsKey(sym) ? candleCounts.get(sym) : 0; }
    String dataSource() { return market.source; }
    String exchangeLabel() { return market.exchange.label(); }

    String pairsText() {
        StringBuilder b = new StringBuilder();
        for (String p : s.activeSymbols()) { if (b.length() > 0) b.append(", "); b.append(p.replace("USDT", "/USDT")); }
        return b.toString();
    }

    String summaryLine() {
        return market.exchange.label() + " · " + pairsText() + " · paper today " + PaperBroker.signed(paper.todayPnl())
                + " · open " + (paper.positions.size() + live.positions.size());
    }

    List<String> openPositionLines() {
        List<String> out = new ArrayList<>();
        for (Map.Entry<String, PaperBroker.Pos> e : paper.positions.entrySet()) {
            PaperBroker.Pos p = e.getValue();
            out.add(PaperBroker.name(e.getKey()) + " " + (p.longSide ? "LONG" : "SHORT") + " (paper)  @ " + PaperBroker.money(p.entry)
                    + "  stop " + PaperBroker.money(p.stop) + (p.trailDist > 0 ? "  trailing" : "  target " + PaperBroker.money(p.target)));
        }
        for (LiveBroker.Pos p : live.positions.values()) {
            out.add(PaperBroker.name(p.symbol) + " LONG (" + (p.real ? "live" : "testnet") + ")  @ " + PaperBroker.money(p.entry)
                    + (p.trail ? "  trailing " + p.trailBips / 100.0 + "%" : "  stop " + PaperBroker.money(p.stop) + "  target " + PaperBroker.money(p.target)));
        }
        return out;
    }

    // ------------------------------------------------------------------ settings

    /** Call after the settings screen changed values in `s`. Returns a message if something had to be reverted. */
    String applySettings() {
        String msg = "";
        if ("MEXC".equals(s.exchange) && (live.armed || !live.positions.isEmpty())) {
            s.exchange = "BINANCE";
            msg = "Disarm live trading and close live positions before switching to MEXC (MEXC is data and paper only).";
        }
        if (!market.exchange.id().equals(s.exchange)) {
            market = new MarketData(Exchange.of(s.exchange));
            engines.clear();
            lastProcessed.clear();
            candleCounts.clear();
            rows.clear();
            addEvent("Exchange switched to " + market.exchange.label() + ". The brain will warm up again.");
        }
        for (NeuraxonEngine e : engines.values()) e.minConfidence = s.minConfidence;
        if (running) { if (s.background) BotService.start(ctx); else BotService.stop(ctx); }
        save();
        changed();
        return msg;
    }

    void resetPaper() {
        paper.reset();
        save();
        addEvent("Paper account reset to $" + PaperBroker.money(PaperBroker.START) + ".");
        changed();
    }

    // ------------------------------------------------------------------ live trading: validation gate and arming

    Gate gate() {
        if (!s.gateOn) return new Gate(true, "validation gate is off");
        TradeLog.Summary p = log.summary("PAPER");
        boolean paperOk = p.trades >= s.gateMinTrades && p.total > 0 && p.profitFactor() >= s.gateMinPf;
        boolean btOk = s.backtestPassAt > 0 && System.currentTimeMillis() - s.backtestPassAt < 7L * 24 * 3600 * 1000;
        if (paperOk) return new Gate(true, "paper history passed (" + p.trades + " trades, " + PaperBroker.signed(p.total) + ")");
        if (btOk) return new Gate(true, "backtest passed: " + s.backtestSummary);
        return new Gate(false, "it needs " + s.gateMinTrades + "+ trades with a net profit and profit factor of " + s.gateMinPf + " or more, from either paper trading or the Backtest. "
                + "Paper so far: " + p.trades + " trades, " + PaperBroker.signed(p.total) + ", profit factor " + pf(p.profitFactor()) + ". Backtest: not passed in the last 7 days.");
    }

    static String pf(double v) { return Double.isInfinite(v) ? "inf" : String.format(Locale.US, "%.2f", v); }

    /** Checks keys, rules and the gate without placing a real order. Runs on the worker thread; the callback runs on the screen thread. */
    void prepareArm(final boolean realMoney, final ArmCallback cb) {
        worker.execute(new Runnable() {
            @Override public void run() {
                final ArmResult res = prepareArmSync(realMoney);
                ui.post(new Runnable() { @Override public void run() { cb.done(res); } });
            }
        });
    }

    ArmResult prepareArmSync(boolean realMoney) {
        try {
            if (!market.exchange.liveTrading()) return new ArmResult(false, "Live trading is Binance only for now. Switch the exchange to Binance in Settings.");
            if (apiKey.isEmpty() || apiSecret.isEmpty()) return new ArmResult(false, "Add your Binance API key and secret in Settings first.");
            if (live.envMismatch(realMoney)) return new ArmResult(false, "Positions from the last session were opened on the other environment. Close them on Binance first.");
            if (realMoney) {
                Gate g = gate();
                if (!g.ok) return new ArmResult(false, "Real money is locked: " + g.text);
            }
            BinanceTrader t = new BinanceTrader(realMoney ? liveUrl : testnetUrl, apiKey, apiSecret);
            t.syncTime();
            String info = t.verify("BTCUSDT", s.maxTradeUsdt);
            for (String sym : symbolsToProcess()) t.rules(sym);
            pending = t;
            return new ArmResult(true, info);
        } catch (Exception e) {
            return new ArmResult(false, String.valueOf(e.getMessage()));
        }
    }

    void commitArm(final boolean realMoney) {
        BinanceTrader t = pending;
        if (t == null) return;
        pending = null;
        live.arm(t, realMoney);
        addEvent((realMoney ? "REAL-MONEY" : "Testnet") + " trading armed.");
        save();
        changed();
        worker.execute(new Runnable() { @Override public void run() { live.reconcile(); changed(); } });
    }

    /** @return false if it was refused because live positions are still open. */
    boolean disarm() {
        if (!live.positions.isEmpty()) { addEvent("Close live positions first (use FLATTEN), then switch to paper."); changed(); return false; }
        live.disarm();
        addEvent("Live trading off. Paper mode.");
        save();
        changed();
        return true;
    }

    void flatten() {
        worker.execute(new Runnable() { @Override public void run() { live.flatten(); save(); changed(); } });
    }

    // ------------------------------------------------------------------ backtest

    void runBacktest(final TextCallback cb) {
        worker.execute(new Runnable() {
            @Override public void run() {
                String out;
                try { out = backtestSync(); } catch (Exception e) { out = "Backtest failed: " + e.getMessage(); }
                final String text = out;
                ui.post(new Runnable() { @Override public void run() { cb.done(text); } });
            }
        });
    }

    String backtestSync() throws Exception {
        final double fee = 0.001;
        final double sa = s.stopAtr, rr = s.rewardRisk, mc = s.minConfidence;
        final boolean trl = s.trailing;
        List<String> syms = s.activeSymbols();
        List<List<NeuraxonEngine.Candle>> data = new ArrayList<>();
        for (String sym : syms) data.add(market.fetch(sym, 1000, false).closed);
        int n = data.get(0).size();
        StringBuilder out = new StringBuilder();
        out.append("Last ").append(n).append(" hourly candles (about ").append(n / 24).append(" days) on ").append(market.exchange.label())
                .append(": ").append(pairsText()).append(".\nThe brain learns candle by candle, as live. Fees 0.10% per side. Stop ").append(num(sa))
                .append("x ATR, ").append(trl ? "trailing stop" : "reward:risk " + num(rr)).append(", min confidence ").append(num(mc)).append(".\n");
        int liveTrades = 0;
        double liveTotal = 0, liveGw = 0, liveGl = 0;
        for (int mode = 0; mode < 2; mode++) {
            boolean longOnly = mode == 0;
            out.append(longOnly ? "\nLONG-ONLY (what live trading does)\n" : "\nLONG + SHORT (paper simulation)\n");
            int trades = 0, wins = 0;
            double sum = 0, gw = 0, gl = 0, bh = 0;
            for (int i = 0; i < syms.size(); i++) {
                Backtester.Stats st = Backtester.run(data.get(i), 1337 + BotSettings.indexOf(syms.get(i)) * 97, sa, rr, mc, fee, longOnly, trl);
                trades += st.trades; wins += st.wins; sum += st.sumPct; gw += st.grossWin; gl += st.grossLoss; bh += st.buyHoldPct;
                out.append(PaperBroker.name(syms.get(i))).append(": ").append(st.trades).append(" trades, win ").append(String.format(Locale.US, "%.0f%%", st.winRate()))
                        .append(", total ").append(pct(st.sumPct)).append(" (buy&hold ").append(pct(st.buyHoldPct)).append(")\n");
            }
            out.append("ALL: ").append(trades).append(" trades, win ").append(String.format(Locale.US, "%.0f%%", trades == 0 ? 0.0 : 100.0 * wins / trades))
                    .append(", total ").append(pct(sum)).append(", profit factor ").append(pf(gl == 0 ? (gw > 0 ? Double.POSITIVE_INFINITY : 0) : gw / gl))
                    .append("  |  buy&hold ").append(pct(bh / syms.size())).append('\n');
            if (longOnly) { liveTrades = trades; liveTotal = sum; liveGw = gw; liveGl = gl; }
        }
        out.append("\nBY MIN CONFIDENCE (long-only):\n");
        for (double th : new double[]{0.05, 0.10, 0.15, 0.25}) {
            int t = 0;
            double sm = 0, gw = 0, gl = 0;
            for (int i = 0; i < syms.size(); i++) {
                Backtester.Stats st = Backtester.run(data.get(i), 1337 + BotSettings.indexOf(syms.get(i)) * 97, sa, rr, th, fee, true, trl);
                t += st.trades; sm += st.sumPct; gw += st.grossWin; gl += st.grossLoss;
            }
            out.append(String.format(Locale.US, "%.2f", th)).append(": ").append(t).append(" trades, total ").append(pct(sm)).append(", PF ")
                    .append(pf(gl == 0 ? (gw > 0 ? Double.POSITIVE_INFINITY : 0) : gw / gl)).append('\n');
        }
        out.append("Do not just pick the best row; that only fits this one history.\n");
        out.append("\nEXIT STYLE (long-only, current settings):\n");
        for (int k = 0; k < 2; k++) {
            boolean tl = k == 1;
            int t = 0, w = 0;
            double sm = 0, gw = 0, gl = 0;
            for (int i = 0; i < syms.size(); i++) {
                Backtester.Stats st = Backtester.run(data.get(i), 1337 + BotSettings.indexOf(syms.get(i)) * 97, sa, rr, mc, fee, true, tl);
                t += st.trades; w += st.wins; sm += st.sumPct; gw += st.grossWin; gl += st.grossLoss;
            }
            out.append(tl ? "Trailing stop: " : "Fixed stop and target: ").append(t).append(" trades, win ")
                    .append(String.format(Locale.US, "%.0f%%", t == 0 ? 0.0 : 100.0 * w / t)).append(", total ").append(pct(sm)).append(", PF ")
                    .append(pf(gl == 0 ? (gw > 0 ? Double.POSITIVE_INFINITY : 0) : gw / gl)).append('\n');
        }
        double pfv = liveGl == 0 ? (liveGw > 0 ? Double.POSITIVE_INFINITY : 0) : liveGw / liveGl;
        boolean pass = liveTrades >= s.gateMinTrades && liveTotal > 0 && pfv >= s.gateMinPf;
        out.append('\n');
        if (liveTrades < 30) out.append("Too few trades to conclude anything. Lower the min confidence or add pairs.");
        else if (liveTotal <= 0) out.append("RESULT: net LOSS after fees with these settings. Do not trade real money with this.");
        else out.append("RESULT: net positive on this history. That is NOT proof it will keep working.");
        out.append("\n\nValidation gate for real money: ").append(pass ? "PASSED (valid for 7 days)." : "not passed (needs " + s.gateMinTrades + "+ trades, net profit, PF " + s.gateMinPf + "+).");
        out.append("\nTotals add up each trade's % return (not compounded). Past results do not predict future results.");
        if (pass) {
            s.backtestPassAt = System.currentTimeMillis();
            s.backtestSummary = liveTrades + " trades, " + pct(liveTotal) + ", PF " + pf(pfv);
        } else {
            s.backtestPassAt = 0;
            s.backtestSummary = "";
        }
        save();
        return out.toString();
    }

    private static String num(double v) { return v == Math.floor(v) ? String.valueOf((long) v) : String.valueOf(v); }
    private static String pct(double v) { return String.format(Locale.US, "%+.1f%%", v); }
}
