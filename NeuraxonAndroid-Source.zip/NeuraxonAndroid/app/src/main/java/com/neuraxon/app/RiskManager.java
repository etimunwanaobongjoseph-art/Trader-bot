package com.neuraxon.app;

/** Risk Management: stop-loss, take-profit, trailing distance, position size and the daily loss limits. */
final class RiskManager {
    private final BotSettings s;
    RiskManager(BotSettings s) { this.s = s; }

    double stopDist(double atr) { return atr * s.stopAtr; }

    /** Refuse stops that are absurdly tight (noise) or absurdly wide. */
    boolean stopOk(double stopDist, double price) {
        double rel = stopDist / price;
        return rel >= 0.002 && rel <= 0.15;
    }

    /** Paper size: risk a fixed % of equity on the stop distance, never more than the whole account. */
    double paperQty(double equity, double price, double stopDist) {
        return Math.min(equity * s.paperRiskPct / 100.0 / stopDist, equity / Math.max(price, 1e-9));
    }

    double target(double entry, double stopDist, boolean lng) { return entry + (lng ? 1 : -1) * stopDist * s.rewardRisk; }

    int trailBips(double stopDist, double entry, int min, int max) {
        int bips = (int) Math.round(stopDist / entry * 10000);
        return Math.max(min, Math.min(max, bips));
    }

    boolean paperDailyLimitHit(double todayPnl, double dayStartEquity) {
        return todayPnl <= -(dayStartEquity * s.dailyLossPaperPct / 100.0);
    }

    boolean liveDailyLimitHit(double todayPnl) { return todayPnl <= -s.dailyLossLiveUsdt; }
}
