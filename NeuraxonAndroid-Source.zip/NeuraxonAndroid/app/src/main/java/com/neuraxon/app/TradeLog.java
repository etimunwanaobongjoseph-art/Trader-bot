package com.neuraxon.app;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

/** Every closed trade (paper, testnet, live), kept across restarts. */
final class TradeLog {
    static final int MAX = 300;

    static final class Rec {
        final long openedAt, closedAt;
        final String symbol, side, mode, reason;   // side LONG/SHORT; mode PAPER/TESTNET/LIVE
        final double entry, exit, qty, pnl, conf;
        Rec(long openedAt, long closedAt, String symbol, String side, String mode, String reason,
            double entry, double exit, double qty, double pnl, double conf) {
            this.openedAt = openedAt; this.closedAt = closedAt; this.symbol = symbol; this.side = side; this.mode = mode;
            this.reason = reason; this.entry = entry; this.exit = exit; this.qty = qty; this.pnl = pnl; this.conf = conf;
        }
    }

    static final class Summary {
        int trades, wins;
        double total, best, worst, grossWin, grossLoss;
        double winRate() { return trades == 0 ? 0 : 100.0 * wins / trades; }
        double avg() { return trades == 0 ? 0 : total / trades; }
        double profitFactor() { return grossLoss == 0 ? (grossWin > 0 ? Double.POSITIVE_INFINITY : 0) : grossWin / grossLoss; }
    }

    private final List<Rec> recs = new ArrayList<>();

    synchronized void add(Rec r) {
        recs.add(r);
        while (recs.size() > MAX) recs.remove(0);
    }

    /** Newest first. */
    synchronized List<Rec> recent(int n) {
        List<Rec> out = new ArrayList<>();
        for (int i = recs.size() - 1; i >= 0 && out.size() < n; i--) out.add(recs.get(i));
        return out;
    }

    synchronized double todayPnl(String mode, long dayStartMs) {
        double t = 0;
        for (Rec r : recs) if (r.mode.equals(mode) && r.closedAt >= dayStartMs) t += r.pnl;
        return t;
    }

    synchronized Summary summary(String mode) {
        Summary s = new Summary();
        boolean first = true;
        for (Rec r : recs) {
            if (!r.mode.equals(mode)) continue;
            s.trades++;
            s.total += r.pnl;
            if (r.pnl > 0) { s.wins++; s.grossWin += r.pnl; } else s.grossLoss += -r.pnl;
            if (first || r.pnl > s.best) s.best = r.pnl;
            if (first || r.pnl < s.worst) s.worst = r.pnl;
            first = false;
        }
        return s;
    }

    synchronized void clearMode(String mode) {
        for (int i = recs.size() - 1; i >= 0; i--) if (recs.get(i).mode.equals(mode)) recs.remove(i);
    }

    static long dayStart(long now) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(now);
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        return c.getTimeInMillis();
    }

    private static String clean(String s) { return s.replace('|', ' ').replace('\n', ' '); }

    synchronized String serialize() {
        StringBuilder b = new StringBuilder();
        for (Rec r : recs) {
            if (b.length() > 0) b.append('\n');
            b.append(r.openedAt).append('|').append(r.closedAt).append('|').append(clean(r.symbol)).append('|').append(clean(r.side)).append('|')
                    .append(clean(r.mode)).append('|').append(clean(r.reason)).append('|').append(r.entry).append('|').append(r.exit).append('|')
                    .append(r.qty).append('|').append(r.pnl).append('|').append(r.conf);
        }
        return b.toString();
    }

    synchronized void load(String data) {
        recs.clear();
        if (data == null || data.isEmpty()) return;
        for (String line : data.split("\n")) {
            String[] f = line.split("\\|", -1);
            if (f.length < 11) continue;
            try {
                recs.add(new Rec(Long.parseLong(f[0]), Long.parseLong(f[1]), f[2], f[3], f[4], f[5], Double.parseDouble(f[6]),
                        Double.parseDouble(f[7]), Double.parseDouble(f[8]), Double.parseDouble(f[9]), Double.parseDouble(f[10])));
            } catch (Exception ignored) { /* skip a damaged line */ }
        }
    }
}
