package com.neuraxon.app;

import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/** Trading Execution (simulated): paper account with fees, optional trailing stop, daily loss limit, kept across restarts. */
final class PaperBroker {
    static final double START = 10000;

    static final class Pos {
        boolean longSide;
        double entry, qty, stop, target, trailDist, extreme, conf;
        long openedAt, openCandle, lastCandle; // lastCandle = newest candle this trade has already been checked against
    }

    private final BotSettings s;
    private final RiskManager risk;
    private final TradeLog log;
    private final SignalEngine sig;
    private final TradeEvents ev;

    volatile double equity = START;
    final Map<String, Pos> positions = new ConcurrentHashMap<>();
    private volatile long limitNotifiedDay = -1;

    PaperBroker(BotSettings s, RiskManager risk, TradeLog log, SignalEngine sig, TradeEvents ev) {
        this.s = s; this.risk = risk; this.log = log; this.sig = sig; this.ev = ev;
    }

    static String name(String symbol) { return symbol.replace("USDT", ""); }
    static String money(double v) { return String.format(Locale.US, "%,.2f", v); }
    static String signed(double v) { return (v >= 0 ? "+$" : "-$") + money(Math.abs(v)); }

    double todayPnl() { return log.todayPnl("PAPER", TradeLog.dayStart(System.currentTimeMillis())); }

    /**
     * @param allowEntry false while replaying history after a start/restart or for a stale candle
     * @param selected   false for a pair the user has since un-ticked: its open trade is still managed, but no new entries
     */
    void onCandle(String symbol, NeuraxonEngine.Candle c, NeuraxonEngine.Result r, SignalEngine.Decision d, boolean allowEntry, boolean selected) {
        Pos p = positions.get(symbol);
        if (p != null && c.time > p.lastCandle) {
            boolean stop = p.longSide ? c.low <= p.stop : c.high >= p.stop;
            boolean target = p.longSide ? c.high >= p.target : c.low <= p.target;
            boolean reverse = (p.longSide && "SELL".equals(r.signal)) || (!p.longSide && "BUY".equals(r.signal));
            if (stop || target || reverse) {
                double exit = stop ? p.stop : target ? p.target : c.close;
                String why = stop ? (p.trailDist > 0 ? "trailing stop" : "stop loss") : target ? "take profit" : "reverse signal";
                close(symbol, p, exit, why, c);
                p = null;
            } else {
                p.lastCandle = c.time;
            }
            if (p != null && p.trailDist > 0) {
                if (p.longSide) { p.extreme = Math.max(p.extreme, c.high); p.stop = Math.max(p.stop, p.extreme - p.trailDist); }
                else { p.extreme = Math.min(p.extreme, c.low); p.stop = Math.min(p.stop, p.extreme + p.trailDist); }
            }
        }
        if (p == null && allowEntry && selected && d.trade() && equity > 0) open(symbol, c, r, d);
    }

    private void close(String symbol, Pos p, double exit, String why, NeuraxonEngine.Candle c) {
        double gross = (p.longSide ? exit - p.entry : p.entry - exit) * p.qty;
        double fee = s.paperFeePct / 100.0 * (p.entry + exit) * p.qty; // charged on both legs
        double net = gross - fee;
        equity += net;
        positions.remove(symbol);
        String side = p.longSide ? "LONG" : "SHORT";
        log.add(new TradeLog.Rec(p.openedAt, c.time + Exchange.CANDLE_MS, symbol, side, "PAPER", why, p.entry, exit, p.qty, net, p.conf));
        if (net < 0) sig.noteLoss(symbol, c.time);
        ev.onTrade(name(symbol) + " " + side + " closed", signed(net) + " · " + why + " · paper (fees " + money(fee) + ")");
    }

    private void open(String symbol, NeuraxonEngine.Candle c, NeuraxonEngine.Result r, SignalEngine.Decision d) {
        long now = System.currentTimeMillis(), day = TradeLog.dayStart(now);
        double today = log.todayPnl("PAPER", day);
        if (risk.paperDailyLimitHit(today, equity - today)) {
            if (limitNotifiedDay != day) {
                limitNotifiedDay = day;
                ev.onTrade("Paper daily loss limit reached", "No new paper trades until tomorrow (today " + signed(today) + ").");
            }
            return;
        }
        double stopDist = risk.stopDist(r.atr);
        if (!risk.stopOk(stopDist, c.close)) return;
        double qty = risk.paperQty(equity, c.close, stopDist);
        double notional = 0;
        for (Pos q : positions.values()) notional += q.qty * q.entry;
        if (!(qty > 0) || !Double.isFinite(qty) || notional + qty * c.close > equity) return;

        boolean lng = "BUY".equals(d.action);
        Pos np = new Pos();
        np.longSide = lng;
        np.entry = c.close;
        np.qty = qty;
        np.stop = lng ? c.close - stopDist : c.close + stopDist;
        np.target = s.trailing ? (lng ? Double.POSITIVE_INFINITY : Double.NEGATIVE_INFINITY) : risk.target(c.close, stopDist, lng);
        if (s.trailing) { np.trailDist = stopDist; np.extreme = c.close; }
        np.conf = d.confidence;
        np.openCandle = c.time;
        np.lastCandle = c.time;
        np.openedAt = c.time + Exchange.CANDLE_MS;
        positions.put(symbol, np);
        ev.onTrade(name(symbol) + " " + (lng ? "LONG" : "SHORT") + " opened",
                "@ " + money(np.entry) + " · stop " + money(np.stop) + (s.trailing ? " · trailing" : " · target " + money(np.target)) + " · paper");
    }

    void reset() {
        equity = START;
        positions.clear();
        log.clearMode("PAPER");
        sig.clear();
        limitNotifiedDay = -1;
    }

    String serializePositions() {
        StringBuilder b = new StringBuilder();
        for (Map.Entry<String, Pos> e : positions.entrySet()) {
            Pos p = e.getValue();
            if (b.length() > 0) b.append('\n');
            b.append(e.getKey()).append('|').append(p.longSide ? 1 : 0).append('|').append(p.entry).append('|').append(p.qty).append('|')
                    .append(p.stop).append('|').append(p.target).append('|').append(p.trailDist).append('|').append(p.extreme).append('|')
                    .append(p.conf).append('|').append(p.openedAt).append('|').append(p.openCandle).append('|').append(p.lastCandle);
        }
        return b.toString();
    }

    void loadPositions(String data) {
        positions.clear();
        if (data == null || data.isEmpty()) return;
        for (String line : data.split("\n")) {
            String[] f = line.split("\\|", -1);
            if (f.length < 11) continue;
            try {
                Pos p = new Pos();
                p.longSide = "1".equals(f[1]);
                p.entry = Double.parseDouble(f[2]); p.qty = Double.parseDouble(f[3]); p.stop = Double.parseDouble(f[4]);
                p.target = Double.parseDouble(f[5]); p.trailDist = Double.parseDouble(f[6]); p.extreme = Double.parseDouble(f[7]);
                p.conf = Double.parseDouble(f[8]); p.openedAt = Long.parseLong(f[9]); p.openCandle = Long.parseLong(f[10]);
                p.lastCandle = f.length > 11 ? Long.parseLong(f[11]) : p.openCandle; // older saves have no lastCandle
                positions.put(f[0], p);
            } catch (Exception ignored) { /* skip a damaged line */ }
        }
    }
}
