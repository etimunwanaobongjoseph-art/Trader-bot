package com.neuraxon.app;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;

/**
 * Market Data Engine: live price, closed candles, volume and volatility for a pair, from the selected exchange.
 * Tries every host of the exchange and remembers the one that works.
 */
class MarketData {
    static final class DataUnavailable extends Exception {
        DataUnavailable(String m) { super(m); }
    }

    static final class Snap {
        final String symbol;
        final double price;      // newest close, even if that candle is still forming
        final double atrPct;     // average true range of the last 14 closed candles, as % of price
        final double volRatio;   // last closed candle volume / average of the 20 before it
        final List<NeuraxonEngine.Candle> closed;
        Snap(String s, double p, double a, double v, List<NeuraxonEngine.Candle> c) { symbol = s; price = p; atrPct = a; volRatio = v; closed = c; }
    }

    private static final String TESTNET_HOST = "https://testnet.binance.vision";

    final Exchange exchange;
    volatile int hostIdx = 0;
    volatile boolean mainnetOk = false;
    volatile String source = "none yet";

    MarketData(Exchange exchange) { this.exchange = exchange; }

    String httpGet(String url) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        try {
            c.setRequestMethod("GET");
            c.setConnectTimeout(6000);
            c.setReadTimeout(10000);
            c.setRequestProperty("User-Agent", "Neuraxon-Android/1.4");
            int code = c.getResponseCode();
            if (code != 200) throw new Exception("HTTP " + code);
            BufferedReader br = new BufferedReader(new InputStreamReader(c.getInputStream()));
            StringBuilder body = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) body.append(line);
            br.close();
            return body.toString();
        } finally {
            c.disconnect();
        }
    }

    /** @param allowTestnetFallback Binance only, and only while in Testnet mode with no real host reachable this session. */
    Snap fetch(String symbol, int limit, boolean allowTestnetFallback) throws DataUnavailable {
        String[] hosts = exchange.hosts();
        String first = null;
        for (int i = 0; i <= hosts.length; i++) {
            boolean testnet = i == hosts.length;
            if (testnet && !(allowTestnetFallback && !mainnetOk && "BINANCE".equals(exchange.id()))) break;
            String host = testnet ? TESTNET_HOST : hosts[(hostIdx + i) % hosts.length];
            try {
                String body = httpGet(exchange.klinesUrl(host, symbol, limit));
                List<NeuraxonEngine.Candle> closed = exchange.parseClosed(body, System.currentTimeMillis());
                double price = exchange.lastPrice(body);
                if (testnet) {
                    source = "TESTNET data (real market hosts unreachable)";
                } else {
                    hostIdx = (hostIdx + i) % hosts.length;
                    mainnetOk = true;
                    source = host.replace("https://", "").replace("http://", "");
                }
                return new Snap(symbol, price, atrPct(closed), volRatio(closed), closed);
            } catch (Exception e) {
                if (first == null) first = e.getMessage();
            }
        }
        throw new DataUnavailable("No " + exchange.label() + " data host reachable (" + first
                + "). Try Android Settings > Network > Private DNS > dns.google, or use a VPN.");
    }

    static double atrPct(List<NeuraxonEngine.Candle> c) {
        int n = c.size();
        if (n < 15) return 0;
        double sum = 0;
        for (int i = n - 14; i < n; i++) {
            NeuraxonEngine.Candle k = c.get(i), p = c.get(i - 1);
            sum += Math.max(k.high - k.low, Math.max(Math.abs(k.high - p.close), Math.abs(k.low - p.close)));
        }
        double last = c.get(n - 1).close;
        return last > 0 ? (sum / 14) / last * 100 : 0;
    }

    static double volRatio(List<NeuraxonEngine.Candle> c) {
        int n = c.size();
        if (n < 22) return 0;
        double avg = 0;
        for (int i = n - 21; i < n - 1; i++) avg += c.get(i).volume;
        avg /= 20;
        return avg > 0 ? c.get(n - 1).volume / avg : 0;
    }
}
