package com.neuraxon.app;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.Locale;

/**
 * Signal Intelligence: turns the brain's raw output into BUY / SELL / WAIT with a confidence and a reason.
 * The brain itself is untouched; this layer adds filters on top of it.
 */
final class SignalEngine {
    static final class Decision {
        final String action;       // BUY, SELL or WAIT
        final double confidence;
        final String reason;
        Decision(String a, double c, String r) { action = a; confidence = c; reason = r; }
        boolean trade() { return !"WAIT".equals(action); }
    }

    private final BotSettings s;
    private final Map<String, Long> cooldownUntil = new ConcurrentHashMap<>();

    SignalEngine(BotSettings s) { this.s = s; }

    Decision decide(String symbol, NeuraxonEngine.Result r, double atrPct, long candleOpenTime) {
        if ("WARMING UP".equals(r.signal)) return new Decision("WAIT", 0, "brain is warming up (needs 50 candles)");
        if (!"BUY".equals(r.signal) && !"SELL".equals(r.signal)) {
            return new Decision("WAIT", r.confidence, String.format(Locale.US, "confidence %.2f is below %.2f", r.confidence, s.minConfidence));
        }
        if (r.atr <= 0) return new Decision("WAIT", r.confidence, "no volatility data yet");
        if (atrPct < s.minAtrPct) {
            return new Decision("WAIT", r.confidence, String.format(Locale.US, "market too quiet (ATR %.2f%% is below %.2f%%)", atrPct, s.minAtrPct));
        }
        Long cd = cooldownUntil.get(symbol);
        if (cd != null && candleOpenTime < cd) return new Decision("WAIT", r.confidence, "cooling down after a losing trade");
        return new Decision(r.signal, r.confidence, String.format(Locale.US, "confidence %.2f", r.confidence));
    }

    /** After a losing trade, skip the next few candles on that pair. */
    void noteLoss(String symbol, long candleOpenTime) {
        if (s.cooldownCandles > 0) cooldownUntil.put(symbol, candleOpenTime + (s.cooldownCandles + 1) * Exchange.CANDLE_MS);
    }

    void clear() { cooldownUntil.clear(); }
}
