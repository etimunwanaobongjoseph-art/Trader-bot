package com.neuraxon.app;

import java.util.List;

/**
 * Walk-forward replay: a fresh engine (same seed as the app) sees the candles one at a time, learning as it goes,
 * exactly as it would have live. Trading costs are included. A position still open at the end is not counted.
 */
final class Backtester {
    static final class Stats {
        int candles, trades, wins;
        double sumPct;          // sum of per-trade returns in % (not compounded), after fees
        double grossWin, grossLoss;
        double maxDrawdownPct;  // largest peak-to-trough fall of the running sum, in %
        double buyHoldPct;      // buy-and-hold return over the same candles, in %

        double winRate() { return trades == 0 ? 0 : 100.0 * wins / trades; }
        double avgPct() { return trades == 0 ? 0 : sumPct / trades; }
        double profitFactor() { return grossLoss == 0 ? (grossWin > 0 ? Double.POSITIVE_INFINITY : 0) : grossWin / grossLoss; }
    }

    /**
     * @param longOnly true = what live spot trading does (a SELL signal only closes a long);
     *                 false = also opens shorts, like the paper simulation
     * @param feePerSide e.g. 0.001 for 0.10% per side
     */
    static Stats run(List<NeuraxonEngine.Candle> candles, int seed, double stopAtr, double rewardRisk,
                     double minConfidence, double feePerSide, boolean longOnly) {
        NeuraxonEngine eng = new NeuraxonEngine(seed);
        eng.minConfidence = minConfidence;
        Stats s = new Stats();
        s.candles = candles.size();
        if (candles.size() < 2) return s;
        s.buyHoldPct = (candles.get(candles.size() - 1).close / candles.get(0).close - 1) * 100;

        boolean open = false, lng = true;
        double entry = 0, stop = 0, target = 0, cum = 0, peak = 0;
        for (NeuraxonEngine.Candle c : candles) {
            NeuraxonEngine.Result r = eng.onClosedCandle(c);
            if (open) {
                boolean hitStop = lng ? c.low <= stop : c.high >= stop;
                boolean hitTarget = lng ? c.high >= target : c.low <= target;
                boolean reverse = (lng && "SELL".equals(r.signal)) || (!lng && "BUY".equals(r.signal));
                if (hitStop || hitTarget || reverse) {
                    double exit = hitStop ? stop : hitTarget ? target : c.close; // stop wins if both are touched in one candle
                    double pct = ((lng ? exit - entry : entry - exit) / entry) * 100 - 2 * feePerSide * 100;
                    s.trades++;
                    s.sumPct += pct;
                    if (pct > 0) { s.wins++; s.grossWin += pct; } else { s.grossLoss += -pct; }
                    cum += pct;
                    peak = Math.max(peak, cum);
                    s.maxDrawdownPct = Math.max(s.maxDrawdownPct, peak - cum);
                    open = false;
                }
            }
            if (!open && r.atr > 0 && ("BUY".equals(r.signal) || (!longOnly && "SELL".equals(r.signal)))) {
                lng = "BUY".equals(r.signal);
                double dist = r.atr * stopAtr, dir = lng ? 1 : -1;
                entry = c.close;
                stop = entry - dir * dist;
                target = entry + dir * dist * rewardRisk;
                open = true;
            }
        }
        return s;
    }
}
