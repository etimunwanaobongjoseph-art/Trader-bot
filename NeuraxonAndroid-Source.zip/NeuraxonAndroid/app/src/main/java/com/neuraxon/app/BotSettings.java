package com.neuraxon.app;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.ArrayList;
import java.util.List;

/** Every user-adjustable value. Saved on the phone. API keys are NOT part of this and are never written to disk. */
final class BotSettings {
    static final String[] SYMBOLS = {"BTCUSDT", "ETHUSDT", "BNBUSDT", "SOLUSDT", "XRPUSDT"};
    static final String PREFS = "neuraxon";

    volatile String exchange = "BINANCE";                       // BINANCE or MEXC (MEXC: data + paper only for now)
    final boolean[] pairOn = {true, false, false, false, false}; // BTC/USDT only by default

    // strategy / signal intelligence
    volatile double stopAtr = 1.5, rewardRisk = 2.0, minConfidence = 0.25, minAtrPct = 0.15;
    volatile int cooldownCandles = 2;
    volatile boolean trailing = false;

    // risk
    volatile double maxTradeUsdt = 15, dailyLossLiveUsdt = 5, dailyLossPaperPct = 3, paperRiskPct = 1.0, paperFeePct = 0.10;

    // app behaviour
    volatile boolean background = true, alerts = true, wasRunning = false;

    // validation gate for real money
    volatile boolean gateOn = true;
    volatile int gateMinTrades = 30;
    volatile double gateMinPf = 1.3;
    volatile long backtestPassAt = 0;
    volatile String backtestSummary = "";

    synchronized boolean pair(String symbol) {
        for (int i = 0; i < SYMBOLS.length; i++) if (SYMBOLS[i].equals(symbol)) return pairOn[i];
        return false;
    }

    synchronized List<String> activeSymbols() {
        List<String> out = new ArrayList<>();
        for (int i = 0; i < SYMBOLS.length; i++) if (pairOn[i]) out.add(SYMBOLS[i]);
        if (out.isEmpty()) out.add(SYMBOLS[0]); // never run with no pair
        return out;
    }

    static int indexOf(String symbol) {
        for (int i = 0; i < SYMBOLS.length; i++) if (SYMBOLS[i].equals(symbol)) return i;
        return 0;
    }

    private static double pd(SharedPreferences sp, String k, double d) {
        try { return Double.parseDouble(sp.getString(k, String.valueOf(d))); } catch (Exception e) { return d; }
    }

    private static double clamp(double v, double lo, double hi) { return Math.max(lo, Math.min(hi, v)); }

    synchronized void load(Context ctx) {
        SharedPreferences sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        exchange = "MEXC".equals(sp.getString("exchange", "BINANCE")) ? "MEXC" : "BINANCE";
        String pairs = sp.getString("pairs", "10000");
        for (int i = 0; i < SYMBOLS.length; i++) pairOn[i] = i < pairs.length() && pairs.charAt(i) == '1';
        stopAtr = clamp(pd(sp, "stopAtr", 1.5), 0.5, 5);
        rewardRisk = clamp(pd(sp, "rewardRisk", 2.0), 0.5, 5);
        minConfidence = clamp(pd(sp, "minConf", 0.25), 0.05, 0.9);
        minAtrPct = clamp(pd(sp, "minAtrPct", 0.15), 0, 5);
        cooldownCandles = (int) clamp(pd(sp, "cooldown", 2), 0, 48);
        trailing = "true".equals(sp.getString("trailing", "false"));
        maxTradeUsdt = clamp(pd(sp, "maxTrade", 15), 1, 1000000);
        // older versions stored a session limit under "lossHalt"; keep it as the starting daily limit
        dailyLossLiveUsdt = clamp(pd(sp, "dailyLossLive", pd(sp, "lossHalt", 5)), 0.1, 1000000);
        dailyLossPaperPct = clamp(pd(sp, "dailyLossPaper", 3), 0.1, 100);
        paperRiskPct = clamp(pd(sp, "paperRisk", 1.0), 0.1, 10);
        paperFeePct = clamp(pd(sp, "paperFee", 0.10), 0, 2);
        background = !"false".equals(sp.getString("background", "true"));
        alerts = !"false".equals(sp.getString("alerts", "true"));
        wasRunning = "true".equals(sp.getString("wasRunning", "false"));
        gateOn = !"false".equals(sp.getString("gateOn", "true"));
        gateMinTrades = (int) clamp(pd(sp, "gateTrades", 30), 1, 100000);
        gateMinPf = clamp(pd(sp, "gatePf", 1.3), 0.5, 20);
        backtestPassAt = (long) pd(sp, "btPassAt", 0);
        backtestSummary = sp.getString("btSummary", "");
    }

    synchronized void save(Context ctx) {
        StringBuilder pairs = new StringBuilder();
        for (boolean b : pairOn) pairs.append(b ? '1' : '0');
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putString("exchange", exchange).putString("pairs", pairs.toString())
                .putString("stopAtr", String.valueOf(stopAtr)).putString("rewardRisk", String.valueOf(rewardRisk))
                .putString("minConf", String.valueOf(minConfidence)).putString("minAtrPct", String.valueOf(minAtrPct))
                .putString("cooldown", String.valueOf(cooldownCandles)).putString("trailing", String.valueOf(trailing))
                .putString("maxTrade", String.valueOf(maxTradeUsdt)).putString("dailyLossLive", String.valueOf(dailyLossLiveUsdt))
                .putString("dailyLossPaper", String.valueOf(dailyLossPaperPct)).putString("paperRisk", String.valueOf(paperRiskPct))
                .putString("paperFee", String.valueOf(paperFeePct)).putString("background", String.valueOf(background))
                .putString("alerts", String.valueOf(alerts)).putString("wasRunning", String.valueOf(wasRunning))
                .putString("gateOn", String.valueOf(gateOn)).putString("gateTrades", String.valueOf(gateMinTrades))
                .putString("gatePf", String.valueOf(gateMinPf)).putString("btPassAt", String.valueOf(backtestPassAt))
                .putString("btSummary", backtestSummary).apply();
    }
}
