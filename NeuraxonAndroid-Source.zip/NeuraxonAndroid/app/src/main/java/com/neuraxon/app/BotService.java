package com.neuraxon.app;

import android.app.Notification;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

/**
 * Keeps the app's process alive while the bot is running, so Android does not stop it when you leave the app.
 * The bot itself lives in BotCore. This uses the "specialUse" foreground service type because the usual
 * "dataSync" type is limited to 6 hours per 24 on current Android.
 */
public class BotService extends Service {
    private PowerManager.WakeLock wake;

    static void start(Context c) {
        try {
            Intent i = new Intent(c, BotService.class);
            if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i); else c.startService(i);
        } catch (Throwable ignored) { /* the bot still runs while the app is open */ }
    }

    static void stop(Context c) {
        try { c.stopService(new Intent(c, BotService.class)); } catch (Throwable ignored) { /* nothing to stop */ }
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        try {
            BotCore core = BotCore.get(this);
            Notification n = core.notifier.ongoing("Watching the market. Tap to open.");
            if (Build.VERSION.SDK_INT >= 34) startForeground(Notifier.ONGOING_ID, n, 0x40000000); // FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            else startForeground(Notifier.ONGOING_ID, n);
            if (wake == null) {
                PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
                if (pm != null) {
                    wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "neuraxon:bot");
                    wake.setReferenceCounted(false);
                    wake.acquire();
                }
            }
            core.resumeIfNeeded();
        } catch (Throwable t) {
            stopSelf();
            return START_NOT_STICKY;
        }
        return START_STICKY;
    }

    @Override public void onDestroy() {
        try { if (wake != null && wake.isHeld()) wake.release(); } catch (Throwable ignored) { /* already released */ }
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
