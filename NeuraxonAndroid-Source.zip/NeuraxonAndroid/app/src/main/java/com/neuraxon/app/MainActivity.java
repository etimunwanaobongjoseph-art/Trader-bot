package com.neuraxon.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** The screen. It only shows what BotCore knows and forwards taps; the bot keeps running when this screen is gone. */
public class MainActivity extends Activity implements BotCore.Listener {
    private static final int BG = Color.rgb(8, 17, 31), PANEL = Color.rgb(17, 29, 47), PANEL2 = Color.rgb(25, 40, 62), LINE = Color.rgb(52, 68, 92),
            MUTED = Color.rgb(150, 166, 188), WHITE = Color.WHITE, GREEN = Color.rgb(32, 201, 151), RED = Color.rgb(255, 99, 110),
            BLUE = Color.rgb(96, 160, 245), AMBER = Color.rgb(240, 185, 70),
            GREEN_FILL = Color.rgb(16, 140, 104), RED_FILL = Color.rgb(170, 52, 66), BLUE_FILL = Color.rgb(52, 104, 190), AMBER_FILL = Color.rgb(160, 108, 20);

    private BotCore core;
    private float density = 1f;
    private int tab = 0;

    private TextView modeChip, subtitle, statusText, equityLabel, equityText, todayText, openText, winText, liveLine;
    private TextView startBtn, stopBtn, trailBtn, bgBtn, alertBtn, flattenBtn;
    private final TextView[] tabs = new TextView[4];
    private final LinearLayout[] panels = new LinearLayout[4];
    private LinearLayout marketsBox, historyBox;
    private TextView liveStatus, logText;

    // ------------------------------------------------------------------ lifecycle

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        density = getResources().getDisplayMetrics().density;
        core = BotCore.get(this);
        buildUi();
        render();
    }

    @Override protected void onStart() { super.onStart(); core.setListener(this); render(); }

    @Override protected void onStop() { core.setListener(null); super.onStop(); }

    @Override public void onChanged() { render(); }

    // ------------------------------------------------------------------ small view helpers

    private int dp(int v) { return (int) (v * density + 0.5f); }

    private GradientDrawable shape(int fill, int radius, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(dp(radius));
        if (stroke != 0) d.setStroke(dp(1), stroke);
        return d;
    }

    private TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private LinearLayout col() { LinearLayout l = new LinearLayout(this); l.setOrientation(1); return l; }

    private LinearLayout row() { LinearLayout l = new LinearLayout(this); l.setOrientation(0); l.setGravity(Gravity.CENTER_VERTICAL); return l; }

    private LinearLayout.LayoutParams weight() { return new LinearLayout.LayoutParams(0, -2, 1); }

    private void gap(LinearLayout l, int h) { l.addView(new View(this), new LinearLayout.LayoutParams(1, dp(h))); }

    private void hgap(LinearLayout l, int w) { l.addView(new View(this), new LinearLayout.LayoutParams(dp(w), 1)); }

    private LinearLayout card() {
        LinearLayout c = col();
        c.setPadding(dp(14), dp(12), dp(14), dp(12));
        c.setBackground(shape(PANEL, 16, 0));
        return c;
    }

    /** A button. Call pill() afterwards (and on every render) to colour it for its on/off state. */
    private TextView button(String label, final Runnable action) {
        final TextView t = text(label, 13, WHITE, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(8), dp(13), dp(8), dp(13));
        t.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                t.setAlpha(0.45f); // quick press flash
                t.postDelayed(new Runnable() { @Override public void run() { t.setAlpha(1f); } }, 130);
                action.run();
            }
        });
        return t;
    }

    /** On = solid colour with white text. Off = dark with a thin outline and muted text. */
    private void pill(TextView v, boolean on, int onFill) {
        v.setBackground(on ? shape(onFill, 14, 0) : shape(PANEL2, 14, LINE));
        v.setTextColor(on ? WHITE : MUTED);
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    private void message(String title, String body) {
        new AlertDialog.Builder(this).setTitle(title).setMessage(body).setPositiveButton("OK", null).show();
    }

    // ------------------------------------------------------------------ layout

    private void buildUi() {
        ScrollView sc = new ScrollView(this);
        sc.setFillViewport(true);
        final LinearLayout root = col();
        root.setPadding(dp(14), dp(14), dp(14), dp(22));
        root.setBackgroundColor(BG);
        sc.addView(root);
        setContentView(sc);
        final int padTop = dp(14), padBottom = dp(22);
        sc.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override public android.view.WindowInsets onApplyWindowInsets(View v, android.view.WindowInsets insets) {
                root.setPadding(dp(14), padTop + insets.getSystemWindowInsetTop(), dp(14), padBottom + insets.getSystemWindowInsetBottom());
                return insets;
            }
        });

        LinearLayout head = row();
        LinearLayout brand = col();
        brand.addView(text("NEURAXON", 22, WHITE, true));
        subtitle = text("", 11, MUTED, false);
        brand.addView(subtitle);
        head.addView(brand, weight());
        modeChip = text("PAPER ▾", 12, WHITE, true);
        modeChip.setPadding(dp(14), dp(9), dp(14), dp(9));
        modeChip.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { chooseMode(); } });
        head.addView(modeChip);
        root.addView(head);
        gap(root, 8);
        statusText = text("", 12, MUTED, true);
        root.addView(statusText);
        gap(root, 10);

        LinearLayout acct = card();
        equityLabel = text("PAPER ACCOUNT", 11, MUTED, true);
        acct.addView(equityLabel);
        equityText = text("$10,000.00", 28, WHITE, true);
        acct.addView(equityText);
        gap(acct, 6);
        LinearLayout stats = row();
        todayText = stat(stats, "TODAY");
        openText = stat(stats, "OPEN");
        winText = stat(stats, "WIN RATE");
        acct.addView(stats);
        liveLine = text("", 11, BLUE, true);
        acct.addView(liveLine);
        root.addView(acct);
        gap(root, 10);

        LinearLayout ctl = row();
        startBtn = button("▶ START", new Runnable() { @Override public void run() { startPressed(); } });
        stopBtn = button("■ STOP", new Runnable() { @Override public void run() { core.stop(); toast("Bot stopped. Open positions keep their stops."); } });
        ctl.addView(startBtn, weight());
        hgap(ctl, 8);
        ctl.addView(stopBtn, weight());
        root.addView(ctl);
        gap(root, 8);

        LinearLayout tg = row();
        trailBtn = button("Trailing", new Runnable() {
            @Override public void run() { core.s.trailing = !core.s.trailing; core.save(); render(); toast(core.s.trailing ? "Trailing stop ON for new trades" : "Trailing stop OFF"); }
        });
        bgBtn = button("Background", new Runnable() {
            @Override public void run() {
                core.s.background = !core.s.background;
                core.applySettings();
                render();
                if (core.s.background) askBattery();
                toast(core.s.background ? "Keeps running when you leave the app" : "Runs only while the app is open");
            }
        });
        alertBtn = button("Alerts", new Runnable() {
            @Override public void run() { core.s.alerts = !core.s.alerts; core.save(); if (core.s.alerts) askNotifications(); render(); toast(core.s.alerts ? "Trade alerts ON" : "Trade alerts OFF"); }
        });
        tg.addView(trailBtn, weight());
        hgap(tg, 6);
        tg.addView(bgBtn, weight());
        hgap(tg, 6);
        tg.addView(alertBtn, weight());
        root.addView(tg);
        gap(root, 14);

        LinearLayout tabRow = row();
        String[] names = {"MARKETS", "HISTORY", "LIVE", "LOG"};
        for (int i = 0; i < 4; i++) {
            final int idx = i;
            tabs[i] = button(names[i], new Runnable() { @Override public void run() { tab = idx; render(); } });
            tabs[i].setTextSize(12);
            tabs[i].setPadding(dp(4), dp(10), dp(4), dp(10));
            tabRow.addView(tabs[i], weight());
            if (i < 3) hgap(tabRow, 5);
        }
        root.addView(tabRow);
        gap(root, 10);

        for (int i = 0; i < 4; i++) { panels[i] = col(); root.addView(panels[i]); }
        marketsBox = panels[0];
        historyBox = panels[1];

        LinearLayout lv = panels[2];
        LinearLayout lc = card();
        liveStatus = text("", 12, WHITE, false);
        lc.addView(liveStatus);
        lv.addView(lc);
        gap(lv, 8);
        flattenBtn = button("⛔ FLATTEN LIVE POSITIONS", new Runnable() { @Override public void run() { confirmFlatten(); } });
        lv.addView(flattenBtn);

        LinearLayout lg = panels[3];
        LinearLayout logCard = card();
        logText = text("", 11, MUTED, false);
        logCard.addView(logText);
        lg.addView(logCard);

        gap(root, 14);
        LinearLayout act = row();
        TextView settings = button("⚙ SETTINGS", new Runnable() { @Override public void run() { showSettings(); } });
        TextView backtest = button("📊 BACKTEST", new Runnable() { @Override public void run() { runBacktest(); } });
        pill(settings, false, BLUE_FILL);
        pill(backtest, false, BLUE_FILL);
        act.addView(settings, weight());
        hgap(act, 8);
        act.addView(backtest, weight());
        root.addView(act);
        gap(root, 12);
        TextView foot = text("Experimental. Paper trades are simulated. Not financial advice.", 10, MUTED, false);
        foot.setGravity(Gravity.CENTER);
        root.addView(foot);
    }

    private TextView stat(LinearLayout parent, String caption) {
        LinearLayout c = col();
        c.addView(text(caption, 10, MUTED, true));
        TextView v = text("-", 16, WHITE, true);
        c.addView(v);
        parent.addView(c, weight());
        return v;
    }

    // ------------------------------------------------------------------ drawing the state

    private void render() {
        BotCore c = core;
        BotSettings s = c.s;
        boolean armed = c.live.armed;

        modeChip.setText(!armed ? "PAPER ▾" : c.live.real ? "LIVE ▾" : "TESTNET ▾");
        modeChip.setBackground(shape(!armed ? GREEN_FILL : c.live.real ? RED_FILL : BLUE_FILL, 20, 0));
        subtitle.setText(c.exchangeLabel() + " · " + c.pairsText() + " · 1h");

        if (!c.running) { statusText.setText("●  Paused"); statusText.setTextColor(MUTED); }
        else if ("CONNECTED".equals(c.dataStatus)) { statusText.setText("●  Data connected · " + c.dataSource()); statusText.setTextColor(GREEN); }
        else if ("NO DATA".equals(c.dataStatus)) { statusText.setText("●  No data. See the LOG tab"); statusText.setTextColor(RED); }
        else { statusText.setText("●  Connecting…"); statusText.setTextColor(BLUE); }

        equityLabel.setText("PAPER ACCOUNT (SIMULATED)");
        equityText.setText("$" + PaperBroker.money(c.paper.equity));
        double today = c.paper.todayPnl();
        todayText.setText(PaperBroker.signed(today));
        todayText.setTextColor(today > 0 ? GREEN : today < 0 ? RED : WHITE);
        openText.setText(String.valueOf(c.paper.positions.size() + c.live.positions.size()));
        TradeLog.Summary ps = c.log.summary("PAPER");
        winText.setText(ps.trades == 0 ? "-" : String.format(Locale.US, "%.0f%%", ps.winRate()));
        if (armed) {
            liveLine.setVisibility(View.VISIBLE);
            liveLine.setText(c.live.modeName() + " today " + PaperBroker.signed(c.live.todayPnl()) + " · " + c.live.positions.size() + " open" + (c.live.halted ? " · HALTED" : ""));
            liveLine.setTextColor(c.live.halted ? RED : BLUE);
        } else {
            liveLine.setVisibility(View.GONE);
        }

        startBtn.setText(c.running ? "● RUNNING" : "▶ START");
        stopBtn.setText(c.running ? "■ STOP" : "■ STOPPED");
        pill(startBtn, c.running, GREEN_FILL);
        pill(stopBtn, !c.running, RED_FILL);
        trailBtn.setText(s.trailing ? "✓ Trailing" : "Trailing");
        bgBtn.setText(s.background ? "✓ Background" : "Background");
        alertBtn.setText(s.alerts ? "✓ Alerts" : "Alerts");
        pill(trailBtn, s.trailing, BLUE_FILL);
        pill(bgBtn, s.background, GREEN_FILL);
        pill(alertBtn, s.alerts, AMBER_FILL);

        for (int i = 0; i < 4; i++) {
            pill(tabs[i], tab == i, BLUE_FILL);
            panels[i].setVisibility(tab == i ? View.VISIBLE : View.GONE);
        }
        pill(flattenBtn, armed, RED_FILL);

        if (tab == 0) renderMarkets();
        else if (tab == 1) renderHistory();
        else if (tab == 2) renderLive();
        else renderLog();
    }

    private void renderMarkets() {
        marketsBox.removeAllViews();
        boolean any = false;
        for (String sym : core.symbolsToProcess()) {
            BotCore.Row r = core.row(sym);
            LinearLayout c = card();
            LinearLayout top = row();
            top.addView(text(sym.replace("USDT", "/USDT"), 15, WHITE, true), weight());
            if (r != null && r.price > 0) top.addView(text("$" + PaperBroker.money(r.price), 15, WHITE, true));
            c.addView(top);
            if (r == null) {
                c.addView(text(core.running ? "Loading candles…" : "Press START to load this market.", 11, MUTED, false));
            } else if (!r.error.isEmpty()) {
                c.addView(text("Data problem (see LOG)", 11, RED, false));
            } else {
                gap(c, 4);
                LinearLayout mid = row();
                boolean idle = "WAIT".equals(r.action) || "WARMING UP".equals(r.action);
                TextView chip = text(r.action, 12, WHITE, true);
                chip.setPadding(dp(10), dp(3), dp(10), dp(3));
                chip.setBackground(shape("BUY".equals(r.action) ? GREEN_FILL : "SELL".equals(r.action) ? RED_FILL : PANEL2, 10, idle ? LINE : 0));
                mid.addView(chip);
                hgap(mid, 10);
                mid.addView(text(String.format(Locale.US, "conf %.2f", r.conf), 12, MUTED, false));
                hgap(mid, 10);
                mid.addView(text(String.format(Locale.US, "ATR %.2f%%  vol %.1fx", r.atrPct, r.volRatio), 12, MUTED, false));
                c.addView(mid);
                gap(c, 3);
                c.addView(text(r.reason, 11, MUTED, false));
            }
            marketsBox.addView(c);
            gap(marketsBox, 8);
            any = true;
        }
        List<String> open = core.openPositionLines();
        if (!open.isEmpty()) {
            marketsBox.addView(text("OPEN POSITIONS", 11, MUTED, true));
            gap(marketsBox, 4);
            for (String line : open) {
                LinearLayout c = card();
                c.addView(text(line, 12, WHITE, false));
                marketsBox.addView(c);
                gap(marketsBox, 6);
            }
        }
        if (!any) marketsBox.addView(text("Nothing to show yet.", 12, MUTED, false));
    }

    private void renderHistory() {
        historyBox.removeAllViews();
        StringBuilder sum = new StringBuilder();
        for (String mode : new String[]{"PAPER", "TESTNET", "LIVE"}) {
            TradeLog.Summary t = core.log.summary(mode);
            if (t.trades == 0 && !"PAPER".equals(mode)) continue;
            if (sum.length() > 0) sum.append("\n\n");
            sum.append(mode).append(":  ").append(t.trades).append(" trades");
            if (t.trades > 0) {
                sum.append(" · win ").append(String.format(Locale.US, "%.0f%%", t.winRate())).append(" · total ").append(PaperBroker.signed(t.total))
                        .append("\nbest ").append(PaperBroker.signed(t.best)).append(" · worst ").append(PaperBroker.signed(t.worst))
                        .append(" · profit factor ").append(BotCore.pf(t.profitFactor()));
            }
        }
        LinearLayout sc = card();
        sc.addView(text(sum.toString(), 12, WHITE, false));
        historyBox.addView(sc);
        gap(historyBox, 8);

        List<TradeLog.Rec> recent = core.log.recent(30);
        if (recent.isEmpty()) {
            historyBox.addView(text("No closed trades yet. Each one will show its entry, exit, result and why it closed.", 12, MUTED, false));
        }
        SimpleDateFormat f = new SimpleDateFormat("d MMM HH:mm", Locale.getDefault());
        for (TradeLog.Rec r : recent) {
            LinearLayout c = card();
            LinearLayout top = row();
            top.addView(text(PaperBroker.name(r.symbol) + " " + r.side + "  ·  " + r.reason, 13, WHITE, true), weight());
            top.addView(text(PaperBroker.signed(r.pnl), 14, r.pnl >= 0 ? GREEN : RED, true));
            c.addView(top);
            c.addView(text(PaperBroker.money(r.entry) + " → " + PaperBroker.money(r.exit) + " · conf " + String.format(Locale.US, "%.2f", r.conf)
                    + " · " + f.format(new Date(r.closedAt)) + " · " + r.mode, 11, MUTED, false));
            historyBox.addView(c);
            gap(historyBox, 6);
        }
        gap(historyBox, 6);
        TextView reset = button("RESET PAPER ACCOUNT", new Runnable() { @Override public void run() { confirmReset(); } });
        pill(reset, false, RED_FILL);
        historyBox.addView(reset);
    }

    private void renderLive() {
        BotCore c = core;
        StringBuilder b = new StringBuilder();
        BotCore.Gate g = c.gate();
        if (!c.live.armed) {
            b.append("Live trading is OFF. Tap the mode chip (top right) to arm Testnet (fake money) or Real money.");
            if (!c.live.positions.isEmpty()) b.append("\n\n").append(c.live.positions.size()).append(" position(s) restored from the last session. Arm the same mode to manage them.");
        } else {
            b.append(c.live.real ? "REAL MONEY" : "TESTNET (fake funds)").append(c.live.halted ? "  ·  HALTED, no new entries" : "  ·  ARMED").append('\n');
            b.append("Today ").append(PaperBroker.signed(c.live.todayPnl())).append(" · daily loss limit $").append(PaperBroker.money(c.s.dailyLossLiveUsdt))
                    .append(c.live.dailyLimitHit() ? " REACHED, resumes tomorrow" : "").append('\n');
            b.append("Max per trade $").append(PaperBroker.money(c.s.maxTradeUsdt)).append(" · up to ").append(LiveBroker.MAX_OPEN).append(" open");
        }
        b.append("\n\nReal-money gate: ").append(g.ok ? "open, " : "LOCKED, ").append(g.text);
        boolean first = true;
        for (String l : c.openPositionLines()) {
            if (!(l.contains("(live)") || l.contains("(testnet)"))) continue;
            b.append(first ? "\n\n" : "\n").append(l);
            first = false;
        }
        liveStatus.setText(b.toString());
        liveStatus.setTextColor(c.live.halted ? RED : WHITE);
    }

    private void renderLog() {
        List<String> ev = core.eventLines();
        StringBuilder b = new StringBuilder();
        if (!core.lastError.isEmpty()) b.append("DATA PROBLEM: ").append(core.lastError).append("\n\n");
        b.append("The bot decides only when an hourly candle closes, and trades only when the brain's confidence is at least ")
                .append(core.s.minConfidence).append(". Until then WAIT is normal.\n\n");
        if (ev.isEmpty()) b.append("No events yet.");
        else for (int i = 0; i < ev.size() && i < 40; i++) b.append(ev.get(i)).append("\n");
        logText.setText(b.toString());
    }

    // ------------------------------------------------------------------ actions

    private void startPressed() {
        askNotifications();
        core.start();
        if (core.s.background) askBattery();
        toast("Bot started");
    }

    private void askNotifications() {
        try {
            if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 1);
            }
        } catch (Throwable ignored) { /* alerts are optional */ }
    }

    /** Asks once to be excluded from battery optimisation so Android does not pause the bot with the screen off. */
    private void askBattery() {
        try {
            SharedPreferences sp = getSharedPreferences(BotSettings.PREFS, Context.MODE_PRIVATE);
            if ("1".equals(sp.getString("askedBattery", ""))) return;
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            if (Build.VERSION.SDK_INT >= 23 && pm != null && !pm.isIgnoringBatteryOptimizations(getPackageName())) {
                sp.edit().putString("askedBattery", "1").apply();
                Intent i = new Intent(android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
                i.setData(Uri.parse("package:" + getPackageName()));
                startActivity(i);
            }
        } catch (Throwable ignored) { /* the phone may not offer this screen */ }
    }

    private void chooseMode() {
        new AlertDialog.Builder(this).setTitle("Trading mode").setItems(new String[]{"Paper (simulated)", "Live: Binance Testnet (fake funds)", "Live: REAL MONEY"},
                new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface d, int w) {
                        if (w == 0) { if (!core.disarm()) toast("Close live positions first (FLATTEN)"); return; }
                        final boolean real = w == 2;
                        toast("Checking your keys…");
                        core.prepareArm(real, new BotCore.ArmCallback() {
                            @Override public void done(BotCore.ArmResult r) {
                                if (!r.ok) { message("Cannot arm live trading", r.text); return; }
                                if (!real) { core.commitArm(false); toast("Testnet armed"); return; }
                                confirmReal(r.text);
                            }
                        });
                    }
                }).show();
    }

    private void confirmReal(String info) {
        final EditText box = new EditText(this);
        box.setHint("Type LIVE to confirm");
        box.setSingleLine(true);
        new AlertDialog.Builder(this).setTitle("Enable REAL-MONEY trading?")
                .setMessage(info + "\n\nReal market orders on Binance Spot: up to $" + PaperBroker.money(core.s.maxTradeUsdt) + " per trade, at most " + LiveBroker.MAX_OPEN
                        + " open, each with an exchange-side exit, and no new trades after a daily loss of $" + PaperBroker.money(core.s.dailyLossLiveUsdt)
                        + ".\n\nThe signal is experimental with no proven edge. You can lose this money. Type LIVE to continue.")
                .setView(box).setNegativeButton("Cancel", null)
                .setPositiveButton("Enable", new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface d, int w) {
                        if ("LIVE".equals(box.getText().toString().trim())) { core.commitArm(true); toast("REAL-MONEY trading armed"); }
                        else toast("Not confirmed. Live trading stays off.");
                    }
                }).show();
    }

    private void confirmFlatten() {
        if (!core.live.armed) { toast("Live trading is not armed."); return; }
        new AlertDialog.Builder(this).setTitle("Flatten live positions?")
                .setMessage("Cancels every stop and sells all positions this app opened, at market. New live entries stay halted until you re-arm.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Flatten", new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface d, int w) { core.flatten(); toast("Flattening…"); }
                }).show();
    }

    private void confirmReset() {
        new AlertDialog.Builder(this).setTitle("Reset paper account?")
                .setMessage("Sets the paper balance back to $10,000, closes paper positions and clears the paper trade history. Testnet and live history are kept.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Reset", new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface d, int w) { core.resetPaper(); toast("Paper account reset"); }
                }).show();
    }

    private void runBacktest() {
        toast("Downloading history, one moment…");
        core.runBacktest(new BotCore.TextCallback() {
            @Override public void done(String text) { message("Backtest results", text); render(); }
        });
    }

    // ------------------------------------------------------------------ settings

    private TextView label(String s) { TextView t = text(s, 11, Color.DKGRAY, true); t.setPadding(0, dp(8), 0, 0); return t; }

    private TextView section(String s) { TextView t = text(s, 12, Color.rgb(40, 90, 170), true); t.setPadding(0, dp(14), 0, dp(2)); return t; }

    private EditText field(double v, boolean integer) {
        EditText e = new EditText(this);
        e.setSingleLine(true);
        e.setInputType(integer ? InputType.TYPE_CLASS_NUMBER : (InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL));
        e.setText(v == Math.floor(v) ? String.valueOf((long) v) : String.valueOf(v));
        return e;
    }

    private static double num(EditText e, double fallback) {
        try {
            double v = Double.parseDouble(e.getText().toString().trim());
            return Double.isNaN(v) || Double.isInfinite(v) ? fallback : v;
        } catch (Exception x) {
            return fallback;
        }
    }

    private static double clamp(double v, double lo, double hi) { return Math.max(lo, Math.min(hi, v)); }

    private static String exchLabel(String id) {
        return "Exchange: " + ("MEXC".equals(id) ? "MEXC (market data + paper only)" : "Binance (live trading supported)") + "   (tap to switch)";
    }

    private void showSettings() {
        final BotSettings s = core.s;
        LinearLayout box = col();
        box.setPadding(dp(18), dp(8), dp(18), 0);

        box.addView(section("EXCHANGE AND PAIRS"));
        final String[] exch = {s.exchange};
        final TextView exchBtn = text("", 14, Color.rgb(40, 90, 170), true);
        exchBtn.setPadding(0, dp(8), 0, dp(8));
        exchBtn.setText(exchLabel(exch[0]));
        exchBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { exch[0] = "BINANCE".equals(exch[0]) ? "MEXC" : "BINANCE"; exchBtn.setText(exchLabel(exch[0])); }
        });
        box.addView(exchBtn);
        final CheckBox[] pairs = new CheckBox[BotSettings.SYMBOLS.length];
        for (int i = 0; i < pairs.length; i++) {
            pairs[i] = new CheckBox(this);
            pairs[i].setText(BotSettings.SYMBOLS[i].replace("USDT", "/USDT"));
            pairs[i].setChecked(s.pairOn[i]);
            box.addView(pairs[i]);
        }

        box.addView(section("SIGNALS"));
        box.addView(label("MIN CONFIDENCE (0.05 to 0.90). Lower = more trades"));
        final EditText conf = field(s.minConfidence, false); box.addView(conf);
        box.addView(label("QUIET-MARKET FILTER: skip when ATR % is below"));
        final EditText quiet = field(s.minAtrPct, false); box.addView(quiet);
        box.addView(label("COOLDOWN AFTER A LOSS (candles, 0 = off)"));
        final EditText cool = field(s.cooldownCandles, true); box.addView(cool);

        box.addView(section("RISK"));
        box.addView(label("STOP DISTANCE (x ATR, 0.5 to 5)"));
        final EditText stop = field(s.stopAtr, false); box.addView(stop);
        box.addView(label("REWARD : RISK (0.5 to 5). Ignored when trailing is on"));
        final EditText rr = field(s.rewardRisk, false); box.addView(rr);
        box.addView(label("PAPER RISK PER TRADE (% of account)"));
        final EditText prisk = field(s.paperRiskPct, false); box.addView(prisk);
        box.addView(label("PAPER FEE (% per side)"));
        final EditText fee = field(s.paperFeePct, false); box.addView(fee);
        box.addView(label("MAX DAILY LOSS, PAPER (% of account)"));
        final EditText dpaper = field(s.dailyLossPaperPct, false); box.addView(dpaper);
        box.addView(label("MAX PER LIVE TRADE (USDT)"));
        final EditText cap = field(s.maxTradeUsdt, false); box.addView(cap);
        box.addView(label("MAX DAILY LOSS, LIVE (USDT)"));
        final EditText dlive = field(s.dailyLossLiveUsdt, false); box.addView(dlive);

        box.addView(section("REAL-MONEY GATE"));
        final CheckBox gate = new CheckBox(this);
        gate.setText("Keep real money locked until paper or backtest results pass");
        gate.setChecked(s.gateOn);
        box.addView(gate);
        box.addView(label("MIN TRADES"));
        final EditText gtr = field(s.gateMinTrades, true); box.addView(gtr);
        box.addView(label("MIN PROFIT FACTOR"));
        final EditText gpf = field(s.gateMinPf, false); box.addView(gpf);

        box.addView(section("BINANCE API KEYS (kept in memory only)"));
        final EditText key = new EditText(this);
        key.setHint("API key");
        key.setSingleLine(true);
        key.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        key.setText(core.apiKey);
        box.addView(key);
        final EditText sec = new EditText(this);
        sec.setHint("API secret");
        sec.setSingleLine(true);
        sec.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        sec.setText(core.apiSecret);
        box.addView(sec);
        box.addView(text("Use a trade-only key with withdrawals OFF. Testnet keys come from testnet.binance.vision.", 11, Color.DKGRAY, false));

        ScrollView sv = new ScrollView(this);
        sv.addView(box);
        AlertDialog dlg = new AlertDialog.Builder(this).setTitle("Settings").setView(sv).setNegativeButton("Cancel", null)
                .setPositiveButton("Save", new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface d, int w) {
                        boolean anyPair = false;
                        for (int i = 0; i < pairs.length; i++) { s.pairOn[i] = pairs[i].isChecked(); anyPair |= s.pairOn[i]; }
                        if (!anyPair) s.pairOn[0] = true; // never run with no pair
                        s.exchange = exch[0];
                        s.minConfidence = clamp(num(conf, s.minConfidence), 0.05, 0.9);
                        s.minAtrPct = clamp(num(quiet, s.minAtrPct), 0, 5);
                        s.cooldownCandles = (int) clamp(num(cool, s.cooldownCandles), 0, 48);
                        s.stopAtr = clamp(num(stop, s.stopAtr), 0.5, 5);
                        s.rewardRisk = clamp(num(rr, s.rewardRisk), 0.5, 5);
                        s.paperRiskPct = clamp(num(prisk, s.paperRiskPct), 0.1, 10);
                        s.paperFeePct = clamp(num(fee, s.paperFeePct), 0, 2);
                        s.dailyLossPaperPct = clamp(num(dpaper, s.dailyLossPaperPct), 0.1, 100);
                        s.maxTradeUsdt = clamp(num(cap, s.maxTradeUsdt), 1, 1000000);
                        s.dailyLossLiveUsdt = clamp(num(dlive, s.dailyLossLiveUsdt), 0.1, 1000000);
                        s.gateOn = gate.isChecked();
                        s.gateMinTrades = (int) clamp(num(gtr, s.gateMinTrades), 1, 100000);
                        s.gateMinPf = clamp(num(gpf, s.gateMinPf), 0.5, 20);
                        String nk = key.getText().toString().trim(), ns = sec.getText().toString().trim();
                        boolean keysChanged = !nk.equals(core.apiKey) || !ns.equals(core.apiSecret);
                        core.apiKey = nk;
                        core.apiSecret = ns;
                        String msg = core.applySettings();
                        render();
                        if (!msg.isEmpty()) message("Setting reverted", msg);
                        else toast(keysChanged && core.live.armed ? "Saved. Re-select the live mode to use the new keys." : "Saved.");
                    }
                }).create();
        dlg.getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE); // blocks screenshots while keys are on screen
        dlg.show();
    }
}
