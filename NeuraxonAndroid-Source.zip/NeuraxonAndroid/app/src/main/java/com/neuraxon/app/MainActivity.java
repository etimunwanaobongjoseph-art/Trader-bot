package com.neuraxon.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private final int BG=Color.rgb(8,17,31), PANEL=Color.rgb(17,29,47), MUTED=Color.rgb(150,166,188), WHITE=Color.WHITE, GREEN=Color.rgb(32,201,151), RED=Color.rgb(255,99,110), BLUE=Color.rgb(72,135,220);
    private final String[] symbols={"BTCUSDT","ETHUSDT","BNBUSDT","SOLUSDT","XRPUSDT"};
    private final Map<String,NeuraxonEngine> engines=new ConcurrentHashMap<>(); private final Map<String,Long> lastProcessed=new ConcurrentHashMap<>();
    private final Map<String,String> signals=new ConcurrentHashMap<>(); private final Map<String,Double> prices=new ConcurrentHashMap<>();
    private static final class PaperPosition { boolean longSide; double entry,qty,stop,target; PaperPosition(boolean l,double e,double q,double s,double t){longSide=l;entry=e;qty=q;stop=s;target=t;} }
    private final Map<String,PaperPosition> paperPositions=new ConcurrentHashMap<>(); private final Map<String,Integer> candleCounts=new ConcurrentHashMap<>(); private volatile double realizedPnl=0;
    private final Handler handler=new Handler(Looper.getMainLooper()); private final ExecutorService io=Executors.newSingleThreadExecutor();
    private TextView connectionText, botStatus, signalText, equityText, positionText, pnlText, activityText, marketText;
    private volatile boolean running=false, fetching=false; private String mode="PAPER"; private volatile double paperEquity=10000, dayStart=10000; private volatile int processed=0; private long lastUpdate=0;
    // ---- live trading state (all live orders are placed from the single IO thread)
    private static final int MAX_OPEN_LIVE=3; private static final long MAX_CANDLE_AGE_MS=15*60000L;
    private static final class LivePos { final String symbol; final BigDecimal qty; final double cost,entry,stop,target; final long listId; final List<Long> orderIds;
        LivePos(String sy,BigDecimal q,double c,double e,double s,double t,long id,List<Long> ids){symbol=sy;qty=q;cost=c;entry=e;stop=s;target=t;listId=id;orderIds=ids;} }
    private final Map<String,LivePos> livePositions=new ConcurrentHashMap<>();
    private volatile BinanceTrader trader; private volatile boolean liveArmed=false, liveHalted=false, liveReal=false;
    private volatile double liveRealized=0; private volatile String liveLastEvent="none yet";
    private volatile String apiKey="", apiSecret=""; private volatile double maxTradeUsdt=15, lossHaltUsdt=5;
    private volatile double stopAtr=1.5, rewardRisk=2.0, minConfidence=0.25;
    private final Map<String,Double> confidences=new ConcurrentHashMap<>();
    private TextView modeChip, liveText;
    private final DecimalFormat priceFmt=new DecimalFormat("#,##0.00");
    private final Runnable poller=new Runnable(){@Override public void run(){if(running)fetchMarkets();handler.postDelayed(this,60000);}};

    @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);for(int i=0;i<symbols.length;i++){engines.put(symbols[i],new NeuraxonEngine(1337+i*97));signals.put(symbols[i],"WAITING");candleCounts.put(symbols[i],0);}loadPrefs();for(NeuraxonEngine en:engines.values())en.minConfidence=minConfidence;buildUi();}
    private GradientDrawable shape(int c,int r){GradientDrawable d=new GradientDrawable();d.setColor(c);d.setCornerRadius(r);return d;}
    private TextView text(String s,int z,int c,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setTextColor(c);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;} private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(0);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);} private void gap(LinearLayout l,int h){l.addView(new View(this),lp(1,h));}
    private TextView button(String s,int c){TextView t=text(s,14,WHITE,true);t.setGravity(Gravity.CENTER);t.setPadding(12,15,12,15);t.setBackground(shape(c,18));return t;}
    private LinearLayout card(){LinearLayout c=col();c.setPadding(16,15,16,15);c.setBackground(shape(PANEL,20));return c;}
    private void buildUi(){ScrollView sc=new ScrollView(this);sc.setFillViewport(true);LinearLayout root=col();root.setPadding(18,18,18,24);root.setBackgroundColor(BG);sc.addView(root);setContentView(sc);
        LinearLayout h=row(),brand=col();brand.addView(text("NEURAXON",22,WHITE,true));brand.addView(text("MULTI-MARKET MINI TRADING SYSTEM",10,MUTED,true));h.addView(brand,new LinearLayout.LayoutParams(0,-2,1));TextView m=modeChip=text("PAPER MODE  ▾",12,GREEN,true);m.setPadding(13,10,13,10);m.setBackground(shape(Color.rgb(15,55,52),30));m.setOnClickListener(v->chooseMode());h.addView(m);root.addView(h);gap(root,18);
        connectionText=text("●  MARKET DATA: DISCONNECTED",12,RED,true);root.addView(connectionText);gap(root,12);
        LinearLayout eq=card();eq.addView(text("PAPER ACCOUNT EQUITY",11,MUTED,true));gap(eq,7);equityText=text("$10,000.00",29,WHITE,true);eq.addView(equityText);eq.addView(text("Simulated balance · no real funds",11,MUTED,false));root.addView(eq);gap(root,10);
        LinearLayout s=row();botStatus=metric("STOPPED",RED);signalText=metric("WAITING",WHITE);s.addView(metricCard("BOT STATUS",botStatus),new LinearLayout.LayoutParams(0,-2,1));s.addView(new View(this),lp(10,1));s.addView(metricCard("LATEST SIGNAL",signalText),new LinearLayout.LayoutParams(0,-2,1));root.addView(s);gap(root,10);
        LinearLayout s2=row();positionText=metric("0 open",WHITE);pnlText=metric("$0.00",WHITE);s2.addView(metricCard("OPEN POSITIONS",positionText),new LinearLayout.LayoutParams(0,-2,1));s2.addView(new View(this),lp(10,1));s2.addView(metricCard("TODAY'S REALIZED P/L",pnlText),new LinearLayout.LayoutParams(0,-2,1));root.addView(s2);gap(root,20);root.addView(text("LIVE TRADING",12,MUTED,true));gap(root,9);LinearLayout lc=card();liveText=text("",12,WHITE,false);lc.addView(liveText);root.addView(lc);gap(root,20);refreshLiveViews();
        root.addView(text("MAIN OPERATIONS",12,MUTED,true));gap(root,9);LinearLayout ops=row();TextView start=button("▶  START BOT",Color.rgb(15,125,92)),stop=button("■  STOP BOT",Color.rgb(150,49,61));ops.addView(start,new LinearLayout.LayoutParams(0,-2,1));ops.addView(new View(this),lp(10,1));ops.addView(stop,new LinearLayout.LayoutParams(0,-2,1));root.addView(ops);gap(root,10);
        TextView settings=button("⚙  SETTINGS",Color.rgb(47,62,82));root.addView(settings);gap(root,10);TextView bt=button("📊  BACKTEST ON RECENT HISTORY",Color.rgb(47,62,82));root.addView(bt);bt.setOnClickListener(v->runBacktest());gap(root,10);TextView flat=button("⛔  FLATTEN LIVE POSITIONS",Color.rgb(120,40,50));root.addView(flat);flat.setOnClickListener(v->confirmFlatten());start.setOnClickListener(v->startBot());stop.setOnClickListener(v->stopBot());settings.setOnClickListener(v->showSettings());gap(root,20);
        root.addView(text("LIVE MARKET WATCH · 1H CANDLES",12,MUTED,true));gap(root,9);LinearLayout markets=card();marketText=text("Waiting for Binance public market data…",12,WHITE,false);markets.addView(marketText);root.addView(markets);gap(root,18);
        root.addView(text("ENGINE ACTIVITY",12,MUTED,true));gap(root,9);LinearLayout log=card();activityText=text("Start the bot to download recent 1-hour candles for BTC, ETH, BNB, SOL and XRP. The engine processes only fully closed candles and simulates paper trades locally.",12,MUTED,false);log.addView(activityText);root.addView(log);gap(root,16);
        TextView warning=text("PAPER TRADING ONLY  •  LIVE ORDERS DISABLED",10,RED,true);warning.setGravity(Gravity.CENTER);root.addView(warning);
    }
    private TextView metric(String s,int c){return text(s,17,c,true);}private LinearLayout metricCard(String title,TextView v){LinearLayout c=card();c.addView(text(title,10,MUTED,true));gap(c,8);c.addView(v);return c;}
    private void startBot(){if(running)return;running=true;botStatus.setText("CONNECTING");botStatus.setTextColor(BLUE);activityText.setText("Connecting to Binance public market data. Downloading 1-hour history for five markets…");fetchMarkets();handler.removeCallbacks(poller);handler.postDelayed(poller,60000);}
    private void stopBot(){running=false;handler.removeCallbacks(poller);botStatus.setText("STOPPED");botStatus.setTextColor(RED);connectionText.setText("●  MARKET DATA: PAUSED");connectionText.setTextColor(MUTED);activityText.setText("Bot stopped. No further market candles will be processed.");Toast.makeText(this,"Neuraxon stopped.",Toast.LENGTH_SHORT).show();}
    private void fetchMarkets(){if(fetching)return;fetching=true;io.execute(()->{Map<String,String> lines=new ConcurrentHashMap<>();boolean any=false;String error="";boolean allDown=false;for(String symbol:symbols){if(allDown){lines.put(symbol,symbol+"   DATA ERROR: "+error);continue;}try{JSONArray arr=new JSONArray(klines(symbol,100));NeuraxonEngine engine=engines.get(symbol);long newest=lastProcessed.containsKey(symbol)?lastProcessed.get(symbol):-1;boolean historicalWarmup=(newest<0);long now=System.currentTimeMillis();int count=0;double lastPrice=0;
                    for(int i=0;i<arr.length();i++){JSONArray k=arr.getJSONArray(i);long openTime=k.getLong(0),closeTime=k.getLong(6);double o=k.getDouble(1),hi=k.getDouble(2),lo=k.getDouble(3),cl=k.getDouble(4),vol=k.getDouble(5);lastPrice=cl;if(closeTime>=now||openTime<=newest)continue;NeuraxonEngine.Result result=engine.onClosedCandle(new NeuraxonEngine.Candle(openTime,o,hi,lo,cl,vol));signals.put(symbol,result.signal);confidences.put(symbol,result.confidence);newest=openTime;count++;processed++;candleCounts.put(symbol,candleCounts.get(symbol)+1); if(running&&!historicalWarmup){NeuraxonEngine.Candle cn=new NeuraxonEngine.Candle(openTime,o,hi,lo,cl,vol);simulatePaper(symbol,cn,result);liveOnSignal(symbol,cn,result);}}
                    if(newest>=0)lastProcessed.put(symbol,newest);prices.put(symbol,lastPrice);lines.put(symbol,symbol+"   $"+priceFmt.format(lastPrice)+"   "+signals.get(symbol)+"  conf "+String.format(java.util.Locale.US,"%.2f",confidences.containsKey(symbol)?confidences.get(symbol):0.0)+"   ("+engineCount(symbol)+" candles)");any=true;
                }catch(Exception e){error=e.getMessage();lines.put(symbol,symbol+"   DATA ERROR: "+error);if(error!=null&&error.startsWith("No Binance data host"))allDown=true;}}
            reconcileLive();final boolean ok=any;final String rendered=join(lines);final String err=error;runOnUiThread(()->{fetching=false;refreshLiveViews();if(ok){lastUpdate=System.currentTimeMillis();connectionText.setText("●  BINANCE PUBLIC DATA: CONNECTED");connectionText.setTextColor(GREEN);botStatus.setText(running?"RUNNING":"STOPPED");botStatus.setTextColor(running?GREEN:RED);marketText.setText(rendered);signalText.setText(overallSignal());signalText.setTextColor(signalColor(overallSignal()));equityText.setText("$"+priceFmt.format(paperEquity));pnlText.setText((realizedPnl>=0?"+$":"-$")+priceFmt.format(Math.abs(realizedPnl)));positionText.setText(paperPositions.size()+" open");activityText.setText("Connected (source: "+dataSource+"). Five USDT pairs · 1-hour candles · closed candles only.\n\nThe bot only trades when an hourly candle CLOSES (next close in about "+(60-(System.currentTimeMillis()/60000L)%60)+" min) and the brain says BUY or SELL with confidence of at least "+trimNum(minConfidence)+". Until then it just watches; that is normal.\n\nLast refresh: "+new java.text.SimpleDateFormat("HH:mm:ss",java.util.Locale.getDefault()).format(new java.util.Date())+"\nClosed candles processed this session: "+processed+"\nPaper trades are simulated locally and ignore fees. Real orders are only sent when a live mode is armed.");}else{connectionText.setText("●  MARKET DATA: CONNECTION FAILED");connectionText.setTextColor(RED);botStatus.setText("NO DATA");botStatus.setTextColor(RED);activityText.setText("Could not reach Binance public market-data endpoint. Check internet access and try again.\n"+err);marketText.setText(rendered);}});
        });}
    private int engineCount(String s){return candleCounts.containsKey(s)?candleCounts.get(s):0;}
    private String join(Map<String,String> m){StringBuilder b=new StringBuilder();for(String s:symbols){if(b.length()>0)b.append("\n\n");b.append(m.containsKey(s)?m.get(s):s+"   waiting");}return b.toString();}
    private String overallSignal(){int buy=0,sell=0;for(String s:symbols){String v=signals.get(s);if("BUY".equals(v))buy++;if("SELL".equals(v))sell++;}return buy>sell&&buy>0?"BUY "+buy+"/5":sell>buy&&sell>0?"SELL "+sell+"/5":"HOLD";}
    private int signalColor(String s){return s.startsWith("BUY")?GREEN:s.startsWith("SELL")?RED:WHITE;}
    private void simulatePaper(String symbol,NeuraxonEngine.Candle c,NeuraxonEngine.Result r){
        PaperPosition p=paperPositions.get(symbol);
        if(p!=null){boolean stop=p.longSide?c.low<=p.stop:c.high>=p.stop;boolean target=p.longSide?c.high>=p.target:c.low<=p.target;boolean reverse=(p.longSide&&"SELL".equals(r.signal))||(!p.longSide&&"BUY".equals(r.signal));if(stop||target||reverse){double exit=stop?p.stop:target?p.target:c.close;double pnl=(p.longSide?exit-p.entry:p.entry-exit)*p.qty;realizedPnl+=pnl;paperEquity+=pnl;paperPositions.remove(symbol);p=null;}}
        if(p==null&&("BUY".equals(r.signal)||"SELL".equals(r.signal))&&r.atr>0&&paperEquity>0&&realizedPnl>-300){double stopDist=r.atr*stopAtr;double riskCash=paperEquity*0.01;double qty=Math.min(riskCash/stopDist,paperEquity/Math.max(c.close,1e-9));double notional=0;for(PaperPosition q:paperPositions.values())notional+=q.qty*q.entry;if(notional+qty*c.close<=paperEquity&&qty>0&&Double.isFinite(qty)){boolean lng="BUY".equals(r.signal);double dir=lng?1:-1;paperPositions.put(symbol,new PaperPosition(lng,c.close,qty,c.close-dir*stopDist,c.close+dir*stopDist*rewardRisk));}}
    }
    // ===================================================================== LIVE TRADING
    // Safety rails: testnet or typed confirmation, per-trade cap, max open positions, exchange-side stop on
    // every position (OCO), session loss halt, stale-candle guard, flatten button. Spot is long-only.
    private void chooseMode(){
        new AlertDialog.Builder(this).setTitle("Trading mode").setItems(new String[]{"Paper trading (simulated)","Live: Binance Testnet (fake funds)","Live: REAL MONEY"},(d,w)->{
            if(!livePositions.isEmpty()){Toast.makeText(this,"Close live positions first (use FLATTEN) before changing mode.",Toast.LENGTH_LONG).show();return;}
            if(w==0){liveArmed=false;liveReal=false;trader=null;liveLog("Live trading off. Paper mode.");return;}
            if(apiKey.isEmpty()||apiSecret.isEmpty()){Toast.makeText(this,"Add your API key and secret in Settings first.",Toast.LENGTH_LONG).show();return;}
            armLive(w==2);
        }).show();
    }
    private void armLive(boolean real){
        final String k=apiKey,sec=apiSecret;final double cap=maxTradeUsdt;
        io.execute(()->{
            try{
                BinanceTrader t=new BinanceTrader(real?BinanceTrader.LIVE_URL:BinanceTrader.TESTNET_URL,k,sec);
                t.syncTime();
                String info=t.verify("BTCUSDT",cap);
                for(String s:symbols)t.rules(s);
                runOnUiThread(()->{
                    if(!real){commitArm(t,false);liveLog("Testnet armed. "+info);return;}
                    EditText box=new EditText(this);box.setHint("Type LIVE to confirm");box.setSingleLine(true);
                    new AlertDialog.Builder(this).setTitle("Enable REAL-MONEY trading?")
                        .setMessage(info+"\n\nThe bot will place real market orders on Binance Spot: up to $"+priceFmt.format(maxTradeUsdt)+" per trade, at most "+MAX_OPEN_LIVE+" open positions, each with an exchange-side stop and target. New entries halt after a session loss of $"+priceFmt.format(lossHaltUsdt)+".\n\nThis strategy is experimental with no proven edge. You can lose this money. Type LIVE to continue.")
                        .setView(box).setNegativeButton("Cancel",null)
                        .setPositiveButton("Enable",(d,w)->{
                            if("LIVE".equals(box.getText().toString().trim())){commitArm(t,true);liveLog("REAL-MONEY trading armed. "+info);}
                            else Toast.makeText(this,"Not confirmed. Live trading stays off.",Toast.LENGTH_LONG).show();
                        }).show();
                });
            }catch(Exception e){
                final String m=e.getMessage();
                liveLog("Could not arm live trading: "+m);
                runOnUiThread(()->Toast.makeText(this,"Could not arm live trading: "+m,Toast.LENGTH_LONG).show());
            }
        });
    }
    private void commitArm(BinanceTrader t,boolean real){trader=t;liveReal=real;liveRealized=0;liveHalted=false;liveArmed=true;refreshLiveViews();}
    private void liveLog(String s){liveLastEvent=new java.text.SimpleDateFormat("HH:mm:ss",java.util.Locale.getDefault()).format(new java.util.Date())+"  "+s;runOnUiThread(this::refreshLiveViews);}
    private void refreshLiveViews(){
        modeChip.setText(!liveArmed?"PAPER MODE  ▾":liveReal?"LIVE · REAL MONEY  ▾":"LIVE · TESTNET  ▾");
        modeChip.setTextColor(!liveArmed?GREEN:liveReal?RED:BLUE);
        if(!liveArmed){liveText.setText("Not armed. Add API keys in Settings, then pick a live mode (top right).\nLast event: "+liveLastEvent);liveText.setTextColor(MUTED);return;}
        StringBuilder b=new StringBuilder();
        b.append(liveReal?"REAL MONEY":"TESTNET (fake funds)").append(liveHalted?"  ·  HALTED (no new entries)":"  ·  ARMED").append('\n');
        b.append("Open: ").append(livePositions.size()).append("/").append(MAX_OPEN_LIVE).append("   Session realized: ").append(liveRealized>=0?"+$":"-$").append(priceFmt.format(Math.abs(liveRealized))).append('\n');
        b.append("Max/trade $").append(priceFmt.format(maxTradeUsdt)).append("   Loss halt $").append(priceFmt.format(lossHaltUsdt)).append('\n');
        for(LivePos p:livePositions.values())b.append(p.symbol).append("  ").append(p.qty.toPlainString()).append(" @ ").append(priceFmt.format(p.entry)).append("   SL ").append(priceFmt.format(p.stop)).append("   TP ").append(priceFmt.format(p.target)).append('\n');
        b.append("Last: ").append(liveLastEvent);
        liveText.setText(b.toString());liveText.setTextColor(liveHalted?RED:WHITE);
    }
    private void liveOnSignal(String symbol,NeuraxonEngine.Candle c,NeuraxonEngine.Result r){
        BinanceTrader t=trader;
        if(!liveArmed||t==null||liveHalted)return;
        if(t.serverNow()-(c.time+3600000L)>MAX_CANDLE_AGE_MS){liveLog(symbol+": candle is stale, no live order.");return;}
        try{
            LivePos p=livePositions.get(symbol);
            if(p!=null&&"SELL".equals(r.signal))closeLive(t,p,"reverse signal");
            else if(p==null&&"BUY".equals(r.signal))openLive(t,symbol,c,r);
        }catch(BinanceTrader.ApiException e){
            liveLog(symbol+" order error: "+e.getMessage());
            if(e.unknown){liveHalted=true;liveLog(symbol+": order status UNKNOWN. New entries halted. Check Binance before re-arming.");}
        }catch(Exception e){liveLog(symbol+" error: "+e);}
    }
    private void openLive(BinanceTrader t,String symbol,NeuraxonEngine.Candle c,NeuraxonEngine.Result r) throws Exception{
        if(livePositions.size()>=MAX_OPEN_LIVE){liveLog(symbol+": max open positions reached, skipped.");return;}
        if(r.atr<=0)return;
        double stopDist=r.atr*stopAtr,rel=stopDist/c.close;
        if(rel<0.002||rel>0.15){liveLog(symbol+": stop distance "+priceFmt.format(rel*100)+"% is out of range, skipped.");return;}
        BinanceTrader.Rules rules=t.rules(symbol);
        if(maxTradeUsdt<rules.minNotional.doubleValue()*1.1){liveLog(symbol+": max/trade is below the exchange minimum ($"+rules.minNotional.toPlainString()+").");return;}
        if(t.freeBalance(rules.quoteAsset)<maxTradeUsdt*1.01){liveLog(symbol+": not enough free "+rules.quoteAsset+".");return;}
        BinanceTrader.Fill in=t.marketBuyQuote(symbol,maxTradeUsdt);
        double cost=in.quote+in.feeQuote,entry=in.avgPrice,stop=entry-stopDist,target=entry+rewardRisk*stopDist;
        BigDecimal qty=rules.floorQty(in.netQty);
        if(qty.compareTo(rules.minQty)<0){liveHalted=true;liveLog(symbol+": bought, but the quantity is below the minimum lot so no stop could be placed. Halted. Check Binance.");return;}
        try{
            BinanceTrader.Oco oco=t.placeOco(symbol,qty,BigDecimal.valueOf(target),BigDecimal.valueOf(stop));
            livePositions.put(symbol,new LivePos(symbol,qty,cost,entry,stop,target,oco.listId,oco.orderIds));
            liveLog(symbol+": BOUGHT "+qty.toPlainString()+" @ "+priceFmt.format(entry)+" with exchange-side stop and target.");
        }catch(Exception e){
            liveLog(symbol+": could not place stop/target ("+e.getMessage()+"). Selling at market.");
            try{BinanceTrader.Fill out=t.marketSell(symbol,qty);liveRealized+=out.quote-out.feeQuote-cost;liveLog(symbol+": closed at market.");}
            catch(Exception e2){liveHalted=true;liveLog("!! "+symbol+" is UNPROTECTED and the sell failed ("+e2.getMessage()+"). Close it manually on Binance.");}
            checkHalt();
        }
    }
    private void closeLive(BinanceTrader t,LivePos p,String why) throws Exception{
        try{t.cancelOco(p.symbol,p.listId);}
        catch(BinanceTrader.ApiException e){
            if("ALL_DONE".equals(t.ocoStatus(p.symbol,p.listId))){settleFinished(t,p);return;}
            throw e;
        }
        BinanceTrader.Fill out;
        try{out=t.marketSell(p.symbol,p.qty);}
        catch(Exception e){liveHalted=true;liveLog("!! "+p.symbol+": stop/target cancelled but the market sell failed ("+e.getMessage()+"). POSITION IS UNPROTECTED. Close it on Binance.");return;}
        double pnl=out.quote-out.feeQuote-p.cost;liveRealized+=pnl;livePositions.remove(p.symbol);
        liveLog(p.symbol+": closed ("+why+") P/L "+(pnl>=0?"+$":"-$")+priceFmt.format(Math.abs(pnl)));
        checkHalt();
    }
    private void settleFinished(BinanceTrader t,LivePos p) throws Exception{
        double[] r=t.sellProceeds(p.symbol,p.orderIds);
        livePositions.remove(p.symbol);
        if(r[1]==0){liveHalted=true;liveLog(p.symbol+": exit orders ended with no fills (cancelled outside the app?). The position may still be held. Halted. Check Binance.");return;}
        double pnl=r[0]-p.cost;liveRealized+=pnl;
        liveLog(p.symbol+": exchange closed the position (stop/target) P/L "+(pnl>=0?"+$":"-$")+priceFmt.format(Math.abs(pnl)));
        checkHalt();
    }
    private void reconcileLive(){
        BinanceTrader t=trader;
        if(!liveArmed||t==null)return;
        for(LivePos p:new ArrayList<>(livePositions.values())){
            try{if("ALL_DONE".equals(t.ocoStatus(p.symbol,p.listId)))settleFinished(t,p);}
            catch(Exception e){liveLog(p.symbol+": status check failed: "+e.getMessage());}
        }
    }
    private void checkHalt(){if(!liveHalted&&liveRealized<=-lossHaltUsdt){liveHalted=true;liveLog("Session loss limit reached. New live entries halted.");}}
    private void confirmFlatten(){
        if(!liveArmed||trader==null){Toast.makeText(this,"Live trading is not armed.",Toast.LENGTH_SHORT).show();return;}
        new AlertDialog.Builder(this).setTitle("Flatten live positions?")
            .setMessage("Cancels every stop/target and sells all positions this app opened, at market. New live entries stay halted until you re-arm.")
            .setNegativeButton("Cancel",null)
            .setPositiveButton("Flatten",(d,w)->io.execute(()->{
                liveHalted=true;BinanceTrader t=trader;
                if(t==null)return;
                for(LivePos p:new ArrayList<>(livePositions.values())){try{closeLive(t,p,"flatten");}catch(Exception e){liveLog(p.symbol+": flatten failed: "+e.getMessage());}}
                liveLog("Flatten finished. New entries halted.");
            })).show();
    }
    // ===================================================================== SETTINGS / DATA / BACKTEST
    private double clamp(double v,double lo,double hi){return Math.max(lo,Math.min(hi,v));}
    private double parsePositive(String s,double fallback){try{double v=Double.parseDouble(s.trim());return v>0&&!Double.isNaN(v)&&!Double.isInfinite(v)?v:fallback;}catch(Exception e){return fallback;}}
    private String trimNum(double v){return v==Math.floor(v)?String.valueOf((long)v):String.valueOf(v);}
    private String pct(double v){return String.format(java.util.Locale.US,"%+.1f%%",v);}
    private double pd(android.content.SharedPreferences sp,String k,double d){try{return Double.parseDouble(sp.getString(k,String.valueOf(d)));}catch(Exception e){return d;}}
    private void loadPrefs(){
        android.content.SharedPreferences sp=getSharedPreferences("neuraxon",MODE_PRIVATE);
        maxTradeUsdt=clamp(pd(sp,"maxTrade",15),1,1000000);lossHaltUsdt=clamp(pd(sp,"lossHalt",5),0.1,1000000);
        stopAtr=clamp(pd(sp,"stopAtr",1.5),0.5,5);rewardRisk=clamp(pd(sp,"rewardRisk",2.0),0.5,5);minConfidence=clamp(pd(sp,"minConf",0.25),0.05,0.9);
    }
    private void savePrefs(){ // strategy values only; API keys are never written to disk
        getSharedPreferences("neuraxon",MODE_PRIVATE).edit().putString("maxTrade",String.valueOf(maxTradeUsdt)).putString("lossHalt",String.valueOf(lossHaltUsdt))
            .putString("stopAtr",String.valueOf(stopAtr)).putString("rewardRisk",String.valueOf(rewardRisk)).putString("minConf",String.valueOf(minConfidence)).apply();
    }
    private TextView label(String s){return text(s,11,Color.DKGRAY,true);}
    private EditText numberField(double v){EditText e=new EditText(this);e.setSingleLine(true);e.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);e.setText(trimNum(v));return e;}
    private void showSettings(){
        LinearLayout box=col();box.setPadding(40,20,40,0);
        box.addView(text("API keys stay in memory only and are cleared when the app closes. Use a trade-only key with withdrawals OFF. Testnet keys come from testnet.binance.vision and differ from real keys. The strategy values below apply to paper and live trading and are saved on this phone.",12,Color.DKGRAY,false));gap(box,10);
        box.addView(label("API KEY"));EditText key=new EditText(this);key.setSingleLine(true);key.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);key.setText(apiKey);box.addView(key);
        box.addView(label("API SECRET"));EditText sec=new EditText(this);sec.setSingleLine(true);sec.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);sec.setText(apiSecret);box.addView(sec);
        box.addView(label("MAX PER LIVE TRADE (USDT)"));EditText cap=numberField(maxTradeUsdt);box.addView(cap);
        box.addView(label("SESSION LOSS HALT (USDT): stops new live entries"));EditText halt=numberField(lossHaltUsdt);box.addView(halt);
        box.addView(label("STOP DISTANCE (x ATR, 0.5 to 5): smaller = tighter stop"));EditText stp=numberField(stopAtr);box.addView(stp);
        box.addView(label("REWARD : RISK (0.5 to 5): target = stop distance x this"));EditText rrf=numberField(rewardRisk);box.addView(rrf);
        box.addView(label("MIN CONFIDENCE TO TRADE (0.05 to 0.90): lower = more trades"));EditText mcf=numberField(minConfidence);box.addView(mcf);
        ScrollView sv=new ScrollView(this);sv.addView(box);
        AlertDialog dlg=new AlertDialog.Builder(this).setTitle("Settings").setView(sv).setNegativeButton("Cancel",null)
            .setPositiveButton("Save",(d,w)->{
                String nk=key.getText().toString().trim(),ns=sec.getText().toString().trim();
                boolean keysChanged=!nk.equals(apiKey)||!ns.equals(apiSecret);
                apiKey=nk;apiSecret=ns;
                maxTradeUsdt=clamp(parsePositive(cap.getText().toString(),maxTradeUsdt),1,1000000);lossHaltUsdt=clamp(parsePositive(halt.getText().toString(),lossHaltUsdt),0.1,1000000);
                stopAtr=clamp(parsePositive(stp.getText().toString(),stopAtr),0.5,5);rewardRisk=clamp(parsePositive(rrf.getText().toString(),rewardRisk),0.5,5);minConfidence=clamp(parsePositive(mcf.getText().toString(),minConfidence),0.05,0.9);
                for(NeuraxonEngine en:engines.values())en.minConfidence=minConfidence;
                savePrefs();refreshLiveViews();
                Toast.makeText(this,keysChanged&&liveArmed?"Saved. Re-select the live mode to use the new keys.":"Saved.",Toast.LENGTH_SHORT).show();
            }).create();
        dlg.getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE); // blocks screenshots/recents preview while keys are on screen
        dlg.show();
    }

    // ---- market data with host fallback (some networks cannot resolve one Binance hostname)
    private static final String[] DATA_HOSTS={"https://data-api.binance.vision","https://api.binance.com","https://api1.binance.com","https://api2.binance.com","https://api3.binance.com","https://api4.binance.com","https://api-gcp.binance.com"};
    private static final String TESTNET_DATA_HOST="https://testnet.binance.vision";
    private volatile int hostIdx=0; private volatile boolean mainnetOk=false; private volatile String dataSource="none yet";
    private String httpGet(String url) throws Exception{
        HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();
        try{
            c.setRequestMethod("GET");c.setConnectTimeout(6000);c.setReadTimeout(10000);c.setRequestProperty("User-Agent","Neuraxon-Android/1.2");
            int code=c.getResponseCode();if(code!=200)throw new Exception("HTTP "+code);
            BufferedReader br=new BufferedReader(new InputStreamReader(c.getInputStream()));StringBuilder body=new StringBuilder();String line;while((line=br.readLine())!=null)body.append(line);br.close();
            return body.toString();
        }finally{c.disconnect();}
    }
    private String klines(String symbol,int limit) throws Exception{
        List<String> hosts=new ArrayList<>();
        for(int i=0;i<DATA_HOSTS.length;i++)hosts.add(DATA_HOSTS[(hostIdx+i)%DATA_HOSTS.length]);
        if(!mainnetOk&&liveArmed&&!liveReal)hosts.add(TESTNET_DATA_HOST); // demo only, and only if no real market host has worked this session
        String first=null;
        for(String h:hosts){
            try{
                String body=httpGet(h+"/api/v3/klines?symbol="+symbol+"&interval=1h&limit="+limit);
                if(h.equals(TESTNET_DATA_HOST)){dataSource="TESTNET data (real market hosts unreachable)";}
                else{for(int i=0;i<DATA_HOSTS.length;i++)if(DATA_HOSTS[i].equals(h))hostIdx=i;mainnetOk=true;dataSource=h.replace("https://","");}
                return body;
            }catch(Exception e){if(first==null)first=e.getMessage();}
        }
        throw new Exception("No Binance data host reachable ("+first+"). Try Android Settings > Network > Private DNS > dns.google, or use a VPN.");
    }
    private List<NeuraxonEngine.Candle> parseCandles(String json) throws Exception{
        JSONArray arr=new JSONArray(json);long now=System.currentTimeMillis();List<NeuraxonEngine.Candle> out=new ArrayList<>();
        for(int i=0;i<arr.length();i++){JSONArray k=arr.getJSONArray(i);if(k.getLong(6)>=now)continue;out.add(new NeuraxonEngine.Candle(k.getLong(0),k.getDouble(1),k.getDouble(2),k.getDouble(3),k.getDouble(4),k.getDouble(5)));}
        return out;
    }

    // ---- backtest: replays recent history through a fresh brain, with fees
    private void runBacktest(){
        Toast.makeText(this,"Downloading history, one moment…",Toast.LENGTH_SHORT).show();
        final double sa=stopAtr,rr=rewardRisk,mc=minConfidence,fee=0.001;
        io.execute(()->{
            try{
                List<List<NeuraxonEngine.Candle>> data=new ArrayList<>();
                for(String s:symbols)data.add(parseCandles(klines(s,1000)));
                int n=data.get(0).size();
                StringBuilder out=new StringBuilder();
                out.append("Replay of the last ").append(n).append(" hourly candles (about ").append(n/24).append(" days) per pair. The brain learns candle by candle, as it does live. Fees 0.10% per side. Stop ").append(trimNum(sa)).append("x ATR, reward:risk ").append(trimNum(rr)).append(", min confidence ").append(trimNum(mc)).append(".\n");
                double liveOnlyTotal=0;int liveOnlyTrades=0;
                for(int mode=0;mode<2;mode++){
                    boolean longOnly=mode==0;
                    out.append(longOnly?"\nLONG-ONLY (what live trading does)\n":"\nLONG + SHORT (paper simulation)\n");
                    int trades=0,wins=0;double sum=0,gw=0,gl=0,bh=0;
                    for(int i=0;i<symbols.length;i++){
                        Backtester.Stats st=Backtester.run(data.get(i),1337+i*97,sa,rr,mc,fee,longOnly);
                        trades+=st.trades;wins+=st.wins;sum+=st.sumPct;gw+=st.grossWin;gl+=st.grossLoss;bh+=st.buyHoldPct;
                        out.append(symbols[i].replace("USDT","")).append(": ").append(st.trades).append(" trades, win ").append(String.format(java.util.Locale.US,"%.0f%%",st.winRate())).append(", total ").append(pct(st.sumPct)).append(" (buy&hold ").append(pct(st.buyHoldPct)).append(")\n");
                    }
                    out.append("ALL: ").append(trades).append(" trades, win ").append(String.format(java.util.Locale.US,"%.0f%%",trades==0?0.0:100.0*wins/trades)).append(", avg/trade ").append(pct(trades==0?0:sum/trades)).append(", total ").append(pct(sum)).append(", profit factor ").append(gl==0?(gw>0?"inf":"0"):String.format(java.util.Locale.US,"%.2f",gw/gl)).append("  |  buy&hold avg ").append(pct(bh/symbols.length)).append('\n');
                    if(longOnly){liveOnlyTotal=sum;liveOnlyTrades=trades;}
                }
                out.append("\nSENSITIVITY (long-only, all pairs), by min confidence:\n");
                for(double th:new double[]{0.05,0.10,0.15,0.25}){
                    int t=0;double sm=0,gw=0,gl=0;
                    for(int i=0;i<symbols.length;i++){Backtester.Stats st=Backtester.run(data.get(i),1337+i*97,sa,rr,th,fee,true);t+=st.trades;sm+=st.sumPct;gw+=st.grossWin;gl+=st.grossLoss;}
                    out.append(String.format(java.util.Locale.US,"%.2f",th)).append(": ").append(t).append(" trades, total ").append(pct(sm)).append(", profit factor ").append(gl==0?(gw>0?"inf":"0"):String.format(java.util.Locale.US,"%.2f",gw/gl)).append('\n');
                }
                out.append("Do not just pick the best row: that only fits this one history.\n\n");
                if(liveOnlyTrades<30)out.append("Too few trades to conclude anything. Lower the min confidence in Settings or use a longer history.");
                else if(liveOnlyTotal<=0)out.append("RESULT: net LOSS after fees on this history with these settings. Do not trade real money with this.");
                else out.append("RESULT: net positive on this history. That is NOT proof it will keep working; one run of a few weeks can be luck.");
                out.append("\n\nTotals add up each trade's % return (not compounded). Past results do not predict future results.");
                final String msg=out.toString();
                runOnUiThread(()->new AlertDialog.Builder(this).setTitle("Backtest results").setMessage(msg).setPositiveButton("OK",null).show());
            }catch(Exception e){
                final String m=String.valueOf(e.getMessage());
                runOnUiThread(()->Toast.makeText(this,"Backtest failed: "+m,Toast.LENGTH_LONG).show());
            }
        });
    }
    @Override protected void onDestroy(){handler.removeCallbacks(poller);io.shutdownNow();apiKey="";apiSecret="";trader=null;super.onDestroy();}
}
