package com.neuraxon.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import java.util.concurrent.atomic.AtomicInteger;

/** Trade alerts and the "bot is running" notification. Every call is best-effort and never throws. */
final class Notifier {
    static final String CH_TRADES = "trades", CH_BOT = "bot";
    static final int ONGOING_ID = 1;

    private final Context ctx;
    private final NotificationManager nm;
    private final AtomicInteger ids = new AtomicInteger(100);

    Notifier(Context ctx) {
        this.ctx = ctx;
        NotificationManager m = null;
        try {
            m = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
            if (m != null && Build.VERSION.SDK_INT >= 26) {
                m.createNotificationChannel(new NotificationChannel(CH_TRADES, "Trade alerts", NotificationManager.IMPORTANCE_DEFAULT));
                m.createNotificationChannel(new NotificationChannel(CH_BOT, "Bot running", NotificationManager.IMPORTANCE_LOW));
            }
        } catch (Throwable ignored) { /* alerts are optional */ }
        nm = m;
    }

    private Notification.Builder builder(String channel) {
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(ctx, channel) : new Notification.Builder(ctx);
        b.setSmallIcon(android.R.drawable.ic_dialog_info);
        b.setContentIntent(PendingIntent.getActivity(ctx, 0, new Intent(ctx, MainActivity.class), PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT));
        return b;
    }

    void trade(String title, String text) {
        try {
            if (nm == null) return;
            nm.notify(ids.incrementAndGet(), builder(CH_TRADES).setContentTitle(title).setContentText(text).setAutoCancel(true).build());
        } catch (Throwable ignored) { /* no permission or no notification service: skip */ }
    }

    Notification ongoing(String text) {
        return builder(CH_BOT).setContentTitle("Neuraxon is running").setContentText(text).setOngoing(true).build();
    }

    void updateOngoing(String text) {
        try {
            if (nm != null) nm.notify(ONGOING_ID, ongoing(text));
        } catch (Throwable ignored) { /* skip */ }
    }
}
