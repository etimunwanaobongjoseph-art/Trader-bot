package com.neuraxon.app;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Trading Execution (Binance Spot, long-only). Every entry gets an exchange-side exit (OCO, or Binance's own trailing stop).
 * All methods are called from the single worker thread of BotCore.
 */
final class LiveBroker {
    static final int MAX_OPEN = 3;
    static final long MAX_CANDLE_AGE_MS = 15 * 60000L;

    static final class Pos {
        final String symbol;
        final BigDecimal qty;
        final double cost, entry, stop, target, conf;
        final long listId;           // OCO list id, or the trailing-stop order id when trail is true
        final List<Long> orderIds;
        final boolean trail, real;
        final int trailBips;
        final long openedAt;
        Pos(String symbol, BigDecimal qty, double cost, double entry, double stop, double target, double conf, long listId,
            List<Long> orderIds, boolean trail, int trailBips, boolean real, long openedAt) {
            this.symbol = symbol; this.qty = qty; this.cost = cost; this.entry = entry; this.stop = stop; this.target = target;
            this.conf = conf; this.listId = listId; this.orderIds = orderIds; this.trail = trail; this.trailBips = trailBips;
            this.real = real; this.openedAt = openedAt;
        }
    }

    private final BotSettings s;
    private final RiskManager risk;
    private final TradeLog log;
    private final SignalEngine sig;
    private final TradeEvents ev;

    final Map<String, Pos> positions = new ConcurrentHashMap<>();
    volatile BinanceTrader trader;
    volatile boolean armed = false, halted = false, real = false;
    private volatile long limitNotifiedDay = -1;

    LiveBroker(BotSettings s, RiskManager risk, TradeLog log, SignalEngine sig, TradeEvents ev) {
        this.s = s; this.risk = risk; this.log = log; this.sig = sig; this.ev = ev;
    }

    String modeName() { return real ? "LIVE" : "TESTNET"; }

    void arm(BinanceTrader t, boolean realMoney) { trader = t; real = realMoney; halted = false; armed = true; limitNotifiedDay = -1; }

    void disarm() { armed = false; trader = null; }

    /** Positions restored from the last session were opened on a different environment than the one now being armed. */
    boolean envMismatch(boolean wantReal) {
        for (Pos p : positions.values()) if (p.real != wantReal) return true;
        return false;
    }

    double todayPnl() { return log.todayPnl(modeName(), TradeLog.dayStart(System.currentTimeMillis())); }

    boolean dailyLimitHit() { return armed && risk.liveDailyLimitHit(todayPnl()); }

    void onSignal(String symbol, NeuraxonEngine.Candle c, NeuraxonEngine.Result r, SignalEngine.Decision d, boolean selected) {
        BinanceTrader t = trader;
        if (!armed || t == null || halted) return;
        if (t.serverNow() - (c.time + Exchange.CANDLE_MS) > MAX_CANDLE_AGE_MS) { ev.onInfo(symbol + ": candle is stale, no live order."); return; }
        try {
            Pos p = positions.get(symbol);
            if (p != null && "SELL".equals(r.signal)) close(t, p, "reverse signal", c.time);
            else if (p == null && selected && "BUY".equals(d.action)) open(t, symbol, c, r, d);
        } catch (BinanceTrader.ApiException e) {
            ev.onInfo(symbol + " order error: " + e.getMessage());
            if (e.unknown) { halted = true; ev.onTrade("Live trading halted", symbol + ": order status UNKNOWN. Check Binance before re-arming."); }
        } catch (Exception e) {
            ev.onInfo(symbol + " error: " + e);
        }
    }

    private void open(BinanceTrader t, String symbol, NeuraxonEngine.Candle c, NeuraxonEngine.Result r, SignalEngine.Decision d) throws Exception {
        if (positions.size() >= MAX_OPEN) { ev.onInfo(symbol + ": max open positions reached, skipped."); return; }
        long now = System.currentTimeMillis(), day = TradeLog.dayStart(now);
        if (risk.liveDailyLimitHit(todayPnl())) {
            if (limitNotifiedDay != day) { limitNotifiedDay = day; ev.onTrade("Daily loss limit reached", modeName() + ": no new trades until tomorrow."); }
            return;
        }
        double stopDist = risk.stopDist(r.atr);
        if (!risk.stopOk(stopDist, c.close)) { ev.onInfo(symbol + ": stop distance is out of range, skipped."); return; }
        BinanceTrader.Rules rules = t.rules(symbol);
        if (s.maxTradeUsdt < rules.minNotional.doubleValue() * 1.1) { ev.onInfo(symbol + ": max per trade is below the exchange minimum ($" + rules.minNotional.toPlainString() + ")."); return; }
        if (t.freeBalance(rules.quoteAsset) < s.maxTradeUsdt * 1.01) { ev.onInfo(symbol + ": not enough free " + rules.quoteAsset + "."); return; }

        BinanceTrader.Fill in = t.marketBuyQuote(symbol, s.maxTradeUsdt);
        double cost = in.quote + in.feeQuote, entry = in.avgPrice, stop = entry - stopDist, target = risk.target(entry, stopDist, true);
        BigDecimal qty = rules.floorQty(in.netQty);
        if (qty.compareTo(rules.minQty) < 0) {
            halted = true;
            ev.onTrade("Live trading halted", symbol + ": bought, but the quantity is below the minimum lot so no stop could be placed. Check Binance.");
            return;
        }
        try {
            if (s.trailing && rules.maxTrailBelow > 0) {
                int bips = risk.trailBips(stopDist, entry, rules.minTrailBelow, rules.maxTrailBelow);
                long oid = t.placeTrailingStop(symbol, qty, bips);
                List<Long> ids = new ArrayList<>();
                ids.add(oid);
                positions.put(symbol, new Pos(symbol, qty, cost, entry, stop, target, d.confidence, oid, ids, true, bips, real, now));
                ev.onTrade(PaperBroker.name(symbol) + " LONG opened (" + modeName() + ")", qty.toPlainString() + " @ " + PaperBroker.money(entry) + " · trailing stop " + bips / 100.0 + "% below the peak");
            } else {
                if (s.trailing) ev.onInfo(symbol + ": trailing stops are not supported on this pair, using a fixed stop and target.");
                BinanceTrader.Oco oco = t.placeOco(symbol, qty, BigDecimal.valueOf(target), BigDecimal.valueOf(stop));
                positions.put(symbol, new Pos(symbol, qty, cost, entry, stop, target, d.confidence, oco.listId, oco.orderIds, false, 0, real, now));
                ev.onTrade(PaperBroker.name(symbol) + " LONG opened (" + modeName() + ")", qty.toPlainString() + " @ " + PaperBroker.money(entry)
                        + " · stop " + PaperBroker.money(stop) + " · target " + PaperBroker.money(target));
            }
        } catch (Exception e) {
            ev.onInfo(symbol + ": could not place the stop/target (" + e.getMessage() + "). Selling at market.");
            try {
                BinanceTrader.Fill out = t.marketSell(symbol, qty);
                double pnl = out.quote - out.feeQuote - cost;
                record(symbol, now, entry, out.avgPrice, qty.doubleValue(), pnl, d.confidence, "no stop placed, sold");
                ev.onTrade(PaperBroker.name(symbol) + " closed (" + modeName() + ")", PaperBroker.signed(pnl) + " · no stop could be placed, sold at market");
            } catch (Exception e2) {
                halted = true;
                ev.onTrade("UNPROTECTED POSITION", symbol + " is open with no stop and the sell failed (" + e2.getMessage() + "). Close it on Binance now.");
            }
            checkDaily();
        }
    }

    private void record(String symbol, long openedAt, double entry, double exit, double qty, double pnl, double conf, String why) {
        long now = System.currentTimeMillis();
        log.add(new TradeLog.Rec(openedAt, now, symbol, "LONG", modeName(), why, entry, exit, qty, pnl, conf));
        if (pnl < 0) sig.noteLoss(symbol, now / Exchange.CANDLE_MS * Exchange.CANDLE_MS - Exchange.CANDLE_MS);
    }

    private boolean exitDone(BinanceTrader t, Pos p) throws Exception {
        if (!p.trail) return "ALL_DONE".equals(t.ocoStatus(p.symbol, p.listId));
        String st = t.orderStatus(p.symbol, p.listId);
        return !("NEW".equals(st) || "PARTIALLY_FILLED".equals(st) || "PENDING_NEW".equals(st));
    }

    private void close(BinanceTrader t, Pos p, String why, long candleOpen) throws Exception {
        try {
            if (p.trail) t.cancelOrder(p.symbol, p.listId); else t.cancelOco(p.symbol, p.listId);
        } catch (BinanceTrader.ApiException e) {
            if (exitDone(t, p)) { settle(t, p); return; }
            throw e;
        }
        BinanceTrader.Fill out;
        try {
            out = t.marketSell(p.symbol, p.qty);
        } catch (Exception e) {
            halted = true;
            ev.onTrade("UNPROTECTED POSITION", p.symbol + ": stop cancelled but the market sell failed (" + e.getMessage() + "). Close it on Binance now.");
            return;
        }
        double pnl = out.quote - out.feeQuote - p.cost;
        positions.remove(p.symbol);
        record(p.symbol, p.openedAt, p.entry, out.avgPrice, p.qty.doubleValue(), pnl, p.conf, why);
        ev.onTrade(PaperBroker.name(p.symbol) + " closed (" + modeName() + ")", PaperBroker.signed(pnl) + " · " + why);
        checkDaily();
    }

    private void settle(BinanceTrader t, Pos p) throws Exception {
        double[] r = t.sellProceeds(p.symbol, p.orderIds);
        positions.remove(p.symbol);
        if (r[1] == 0) {
            halted = true;
            ev.onTrade("Live trading halted", p.symbol + ": exit orders ended with no fills (cancelled outside the app?). The position may still be held. Check Binance.");
            return;
        }
        double pnl = r[0] - p.cost;
        record(p.symbol, p.openedAt, p.entry, r[0] / p.qty.doubleValue(), p.qty.doubleValue(), pnl, p.conf, p.trail ? "trailing stop (exchange)" : "stop/target (exchange)");
        ev.onTrade(PaperBroker.name(p.symbol) + " closed (" + modeName() + ")", PaperBroker.signed(pnl) + " · closed by the exchange stop/target");
        checkDaily();
    }

    void reconcile() {
        BinanceTrader t = trader;
        if (!armed || t == null) return;
        for (Pos p : new ArrayList<>(positions.values())) {
            try { if (exitDone(t, p)) settle(t, p); }
            catch (Exception e) { ev.onInfo(p.symbol + ": status check failed: " + e.getMessage()); }
        }
    }

    private void checkDaily() {
        long day = TradeLog.dayStart(System.currentTimeMillis());
        if (risk.liveDailyLimitHit(todayPnl()) && limitNotifiedDay != day) {
            limitNotifiedDay = day;
            ev.onTrade("Daily loss limit reached", modeName() + ": no new trades until tomorrow.");
        }
    }

    void flatten() {
        halted = true;
        BinanceTrader t = trader;
        if (t == null) return;
        for (Pos p : new ArrayList<>(positions.values())) {
            try { close(t, p, "flatten", 0); } catch (Exception e) { ev.onInfo(p.symbol + ": flatten failed: " + e.getMessage()); }
        }
        ev.onInfo("Flatten finished. New entries are halted until you re-arm.");
    }

    String serializePositions() {
        StringBuilder b = new StringBuilder();
        for (Pos p : positions.values()) {
            if (b.length() > 0) b.append('\n');
            StringBuilder ids = new StringBuilder();
            for (Long id : p.orderIds) { if (ids.length() > 0) ids.append(','); ids.append(id); }
            b.append(p.symbol).append('|').append(p.qty.toPlainString()).append('|').append(p.cost).append('|').append(p.entry).append('|')
                    .append(p.stop).append('|').append(p.target).append('|').append(p.conf).append('|').append(p.listId).append('|')
                    .append(ids).append('|').append(p.trail ? 1 : 0).append('|').append(p.trailBips).append('|').append(p.real ? 1 : 0)
                    .append('|').append(p.openedAt);
        }
        return b.toString();
    }

    void loadPositions(String data) {
        positions.clear();
        if (data == null || data.isEmpty()) return;
        for (String line : data.split("\n")) {
            String[] f = line.split("\\|", -1);
            if (f.length < 13) continue;
            try {
                List<Long> ids = new ArrayList<>();
                for (String x : f[8].split(",")) if (!x.isEmpty()) ids.add(Long.parseLong(x));
                positions.put(f[0], new Pos(f[0], new BigDecimal(f[1]), Double.parseDouble(f[2]), Double.parseDouble(f[3]), Double.parseDouble(f[4]),
                        Double.parseDouble(f[5]), Double.parseDouble(f[6]), Long.parseLong(f[7]), ids, "1".equals(f[9]), Integer.parseInt(f[10]),
                        "1".equals(f[11]), Long.parseLong(f[12])));
            } catch (Exception ignored) { /* skip a damaged line */ }
        }
    }
}
